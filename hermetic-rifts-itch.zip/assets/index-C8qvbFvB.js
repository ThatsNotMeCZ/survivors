var tl=Object.defineProperty;var sl=(e,s,t)=>s in e?tl(e,s,{enumerable:!0,configurable:!0,writable:!0,value:t}):e[s]=t;var S=(e,s,t)=>sl(e,typeof s!="symbol"?s+"":s,t);import{_ as P}from"./phaser-Bga4hU0l.js";(function(){const s=document.createElement("link").relList;if(s&&s.supports&&s.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))n(a);new MutationObserver(a=>{for(const i of a)if(i.type==="childList")for(const o of i.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&n(o)}).observe(document,{childList:!0,subtree:!0});function t(a){const i={};return a.integrity&&(i.integrity=a.integrity),a.referrerPolicy&&(i.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?i.credentials="include":a.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function n(a){if(a.ep)return;a.ep=!0;const i=t(a);fetch(a.href,i)}})();let te=null,Jn=null,ei=!1,ti=[];const no=[];function nl(e){no.push(e)}function on(){return te}function zt(){if(te)return te;const e=window.AudioContext||window.webkitAudioContext,s=new e,t=s.createGain(),n=s.createGain(),a=s.createGain();return n.connect(t),a.connect(t),t.connect(s.destination),te={ctx:s,master:t,music:n,sfx:a},Jn&&rn(Jn),te}function rn(e){if(Jn=e,!te){if(typeof window>"u")return;zt()}if(!te)return;il(te);const s=te.ctx.currentTime,t=e.muted?0:1;xn(te.master.gain,e.masterVolume*t,s),xn(te.music.gain,e.musicVolume,s),xn(te.sfx.gain,e.sfxVolume,s);for(const n of no)n(e)}function al(e){if(ti.push(e),ei)return;ei=!0;const s=()=>{const t=zt();ol(t),t.ctx.resume().then(()=>{for(const n of ti)n()})};window.addEventListener("pointerdown",s),window.addEventListener("keydown",s)}function il(e){e.ctx.state==="suspended"&&navigator.userActivation?.isActive&&e.ctx.resume()}function xn(e,s,t){e.cancelScheduledValues(t),e.setValueAtTime(s,t)}function ol(e){const s=e.ctx.createBuffer(1,1,e.ctx.sampleRate),t=e.ctx.createBufferSource();t.buffer=s,t.connect(e.ctx.destination),t.start()}const kn=1.2,Sn=.5,rl=.35;let Ce=null,ce=null,be=null,Fs="a",Le=null,Y=null,Bs=!1,as="",ct=[],ea=[],ht="",rt=[],Hs=[],Fe="",si=!1;function ll(e){Ce=e;const s=zt();si||(si=!0,nl(t=>cl(t.muted))),!ce&&(Le=s.ctx.createGain(),Le.gain.value=1,Le.connect(s.music),ce=Cn(s.ctx,Le,ni("a"),"bed-a"),be=Cn(s.ctx,Le,ni("b"),"bed-b"),Y=Cn(s.ctx,s.music,dl,"overlay"),Y.gain.gain.value=0)}function ao(e){if(!Ce||!ce)return;if((e.kind==="none"||e.kind==="menu")&&(ul(),io(!1)),e.kind==="none"){as="",ct=[],En();return}const s=e.kind==="menu"?"menu":e.kind==="boss"?`boss:${e.bossId}`:`map:${e.stageId}`;let t=e.kind==="menu"?Ce.music.menu:e.kind==="boss"?Ce.music.boss?.[e.bossId]??[]:Ce.music.maps[e.stageId]??[];if(t.length===0&&e.kind==="boss"&&e.stageId&&(t=Ce.music.maps[e.stageId]??[]),s===as&&ht){ro();return}if(t.length===0){if(e.kind==="boss")return;as="",ct=[],En();return}as=s,ct=t,ea=ya(t,null);const n=cn(ea,t,null);if(!n){En();return}lo(n,!!ht)}function io(e){if(Bs=e,!Ce||!Y||!Le)return;rt=Ce.music.overlay;const s=on();if(!s)return;const t=s.ctx.currentTime;if($s(Le.gain,e?rl:1,t,Sn),$s(Y.gain.gain,e?1:0,t,Sn),e){Fe||(Hs=ya(rt,null),Fe=cn(Hs,rt,null),Fe&&ga(Y.el,Fe,rt.length<=1)),ln(Y.el);return}window.setTimeout(()=>{Bs||Y?.el.pause()},Sn*1e3)}function oo(){ro(),Bs&&Y?.el.play().catch(()=>{})}function cl(e){ce&&(ce.el.muted=e),be&&(be.el.muted=e),Y&&(Y.el.muted=e)}function ro(){const e=co();!e||!ht||ln(e.el)}function lo(e,s){if(!ce||!be)return;const t=on();if(!t)return;const n=Fs==="a"?"b":"a",a=n==="a"?ce:be,i=n==="a"?be:ce;ga(a.el,e,ct.length<=1),ln(a.el);const o=t.ctx.currentTime;s?($s(a.gain.gain,1,o,kn),$s(i.gain.gain,0,o,kn),window.setTimeout(()=>{co()!==i&&i.el.pause()},kn*1e3)):(a.gain.gain.cancelScheduledValues(o),a.gain.gain.setValueAtTime(1,o),i.gain.gain.cancelScheduledValues(o),i.gain.gain.setValueAtTime(0,o),i.el.pause()),Fs=n,ht=e}function En(){ht="",ce?.el.pause(),be?.el.pause()}function ni(e){return()=>{if(e!==Fs||ct.length<=1)return;const s=cn(ea,ct,ht);s&&lo(s,!0)}}function dl(){if(!Bs||rt.length<=1||!Y)return;const e=cn(Hs,rt,Fe);e&&(Fe=e,ga(Y.el,e,!1),ln(Y.el))}function co(){return!ce||!be?null:Fs==="a"?ce:be}function Cn(e,s,t,n){const a=document.createElement("audio");a.preload="auto",a.crossOrigin="anonymous",a.hidden=!0,a.dataset.role=n,a.setAttribute("playsinline",""),a.addEventListener("ended",t),document.body.appendChild(a);const i=e.createGain();return i.gain.value=0,e.createMediaElementSource(a).connect(i),i.connect(s),{el:a,gain:i}}function ga(e,s,t){e.dataset.rel!==s&&(e.dataset.rel=s,e.src=fl(s)),e.loop=t}function ul(){Fe="",Hs=[],Y&&(Y.el.pause(),Y.el.removeAttribute("src"),Y.el.dataset.rel="")}function ln(e){return e.play().then(()=>{}).catch(()=>{})}function ya(e,s){const t=[...e];for(let n=t.length-1;n>0;n-=1){const a=Math.floor(Math.random()*(n+1)),i=t[n],o=t[a];i===void 0||o===void 0||(t[n]=o,t[a]=i)}if(s&&t.length>1&&t[0]===s){const n=1+Math.floor(Math.random()*(t.length-1)),a=t[0],i=t[n];a!==void 0&&i!==void 0&&(t[0]=i,t[n]=a)}return t}function cn(e,s,t){if(s.length===0)return"";if(e.length===0){const n=ya(s,t);e.push(...n)}return e.shift()??""}function $s(e,s,t,n){e.cancelScheduledValues(t),e.setValueAtTime(e.value,t),e.linearRampToValueAtTime(s,t+n)}function fl(e){return new URL(encodeURI(e),document.baseURI).href}const ml=12,hl=1e3,pl=1,gl=2,yl={hit:8,death:6,gem:10,muzzle:12},uo=new Map,Mn=new Map;let is=0,Is={};function vl(e){Is={};for(const[t,n]of Object.entries(e.sfx))Is[t]={src:n.src,volume:bl(n.volume)};const s=zt();for(const[t,n]of Object.entries(Is))kl(s.ctx,t,n.src)}function T(e){const s=on(),t=uo.get(e),n=Is[e];if(!s||!t||!n||is>=ml||!xl(e))return;const a=s.ctx.createBufferSource();a.buffer=t;const i=s.ctx.createGain();i.gain.value=n.volume,a.connect(i),i.connect(s.sfx),is+=1,a.onended=()=>{is=Math.max(0,is-1)},a.start()}function bl(e){return typeof e!="number"||!Number.isFinite(e)?pl:Math.min(gl,Math.max(0,e))}function xl(e){const s=yl[e];if(!s)return!0;const t=performance.now(),n=(Mn.get(e)??[]).filter(a=>t-a<hl);return n.length>=s?(Mn.set(e,n),!1):(n.push(t),Mn.set(e,n),!0)}async function kl(e,s,t){try{const n=new URL(encodeURI(t),document.baseURI).href,a=await fetch(n);if(!a.ok)return;const i=await a.arrayBuffer(),o=await e.decodeAudioData(i);uo.set(s,o)}catch{}}const Sl=["circle","boss","tablets","hall","archives","cover","banner"],El=new Set(["circle","boss","tablets"]);function vt(){if(typeof window>"u")return null;const e=new URLSearchParams(window.location.search).get("promo");return e&&Sl.includes(e)?e:null}function Xt(){return vt()!==null}function dt(){const e=vt();return e!==null&&El.has(e)}function Cl(){if(typeof document>"u")return;const e=vt();if(!e){delete document.documentElement.dataset.promo;return}document.documentElement.dataset.promo=e}function _s(){typeof document>"u"||(document.documentElement.dataset.promoReady="1")}const fo="survivors.settings.v1",Ds={masterVolume:.7,sfxVolume:.8,musicVolume:.6,muted:!1,screenshake:!0,reduceVfx:!1,survivorId:"runner"};let oe=null;function H(){return oe||(oe={...Ds,...Ml()},oe.masterVolume=ut(oe.masterVolume),oe.sfxVolume=ut(oe.sfxVolume??Ds.sfxVolume),oe.musicVolume=ut(oe.musicVolume??Ds.musicVolume),oe)}function De(e){const s={...H(),...e};s.masterVolume=ut(s.masterVolume),s.sfxVolume=ut(s.sfxVolume),s.musicVolume=ut(s.musicVolume),oe=s;try{localStorage.setItem(fo,JSON.stringify(s))}catch{}return va(s),rn(s),on()?.ctx.resume().then(()=>oo()),s}function va(e=H()){typeof document>"u"||(document.documentElement.dataset.muted=e.muted?"1":"0",document.documentElement.dataset.reduceVfx=e.reduceVfx?"1":"0",document.documentElement.dataset.screenshake=e.screenshake?"1":"0",document.documentElement.style.setProperty("--master-volume",String(e.masterVolume)),document.documentElement.style.setProperty("--sfx-volume",String(e.sfxVolume)),document.documentElement.style.setProperty("--music-volume",String(e.musicVolume)))}function xe(e){return typeof window>"u"?!1:new URLSearchParams(window.location.search).has(e)}function mo(){return xe("smoke")||xe("dev")||dt()}function Ml(){if(typeof localStorage>"u")return{};try{const e=localStorage.getItem(fo);if(!e)return{};const s=JSON.parse(e);return s&&typeof s=="object"?s:{}}catch{return{}}}function ut(e){return Number.isFinite(e)?Math.min(1,Math.max(0,e)):Ds.masterVolume}let ai=!1,ho={kind:"none"};function wl(){ai||(ai=!0,zt(),rn(H()),al(()=>{oo()}),Rl())}function lt(e){ho=e,ao(e)}async function Rl(){try{const e=await fetch(new URL("audio/manifest.json",document.baseURI).href);if(!e.ok)return;const s=await e.json();ll(s),vl(s),rn(H()),ao(ho)}catch{}}const po=1920,go=1080,ta=2e4,Tl=55,Al=3e3,os=256,Il=64,_e=0,we=1,Ge=2,At=3,Oe=4,ne=5,Gs=6,It=7,Dt=8,ba=9,Dl=1,Pl=[{id:"ember-mite",name:"Ember Mite",title:"Scorched Dross",lore:"Clots of ash and failed calcination that skitter out of cracked retorts. Individually brittle, they swarm any warm vessel to strip its mercury.",role:"fodder",tags:["fodder","chaser"],stats:{speed:92,maxHp:14,radius:10},contact:{dps:3},rewards:{xp:3,credits:1},ai:{type:"chase"},view:{kind:"dot",size:18,inner:"#ffe8e8",mid:"#c94a4a"}},{id:"ember-spitter",name:"Ember Spitter",title:"Slag Bile Vessel",lore:"Distended husks engorged on boiling sulfur. They circle the outer kiln perimeter, hurling globules of molten slag whenever a vessel slows its stride.",role:"fodder",tags:["fodder","ranged"],stats:{speed:68,maxHp:12,radius:11},contact:{dps:2},rewards:{xp:4,credits:1},ai:{type:"ranged",range:280,keep:200,cooldown:2.1,windup:.4,projectile:{speed:240,lifetime:1.35,radius:6,damage:5}},view:{kind:"dot",size:20,inner:"#fff0c8",mid:"#ff7a3a"}},{id:"ember-chaser",name:"Ember Warden",title:"Furnace Overseer",lore:"A heavy amalgam of cast-iron ribs and stoked furnace slag built to herd failed transmutations. It charges across the flagstones with crushing momentum.",role:"fodder",tags:["fodder","chaser"],stats:{speed:102,maxHp:52,radius:18},contact:{dps:16},rewards:{xp:8,credits:4},ai:{type:"chase"},view:{kind:"dot",size:48,inner:"#ffe8e8",mid:"#e35d5d"}},{id:"cinder-heart",name:"Cinder Heart",title:"Core of the First Kiln",lore:"The living furnace heart that consumed its own alchemists. It awakens only when the Transmutation Circle is charged, determined to melt every vessel back into raw clay.",role:"boss",tags:["boss","ranged","summoner"],stats:{speed:60,maxHp:1650,radius:36},contact:{dps:22},rewards:{xp:50,credits:0},ai:{type:"boss",keep:230,enrage:{hpPct:.5,cooldownMul:.75},attacks:[{type:"fan",name:"Slag Spray",anim:"attack-fan",cooldown:3.2,windup:.6,count:5,spread:50,projectile:{speed:230,lifetime:2,radius:9,damage:9}},{type:"meteor",name:"Falling Clinker",anim:"attack-meteor",cooldown:5,windup:.4,delay:1.2,radius:58,damage:24,pool:{duration:4,radius:50,dps:8,slowMul:.6}},{type:"summon",name:"Kiln Brood",anim:"summon",cooldown:9,windup:.35,entity:"ember-mite",count:3,maxAlive:6}]},view:{kind:"dot",size:72,inner:"#fff0c8",mid:"#ff7a3a"}},{id:"frost-mite",name:"Frost Mite",title:"Rime-Bitten Husk",lore:"Shards of alchemical salt and frozen mercury that skitter across the dockside stone. Quicker and harder than kiln mites, they hunt in tight, unforgiving packs.",role:"fodder",tags:["fodder","chaser"],stats:{speed:104,maxHp:18,radius:10},contact:{dps:4},rewards:{xp:4,credits:1},ai:{type:"chase"},view:{kind:"dot",size:18,inner:"#e8f6ff",mid:"#4aa0d4"}},{id:"frost-spitter",name:"Frost Spitter",title:"Brine Condenser",lore:"Hollowed alembic creatures that siphon freezing brine from the dock fissures and spit high-velocity needles of rime across the chamber.",role:"fodder",tags:["fodder","ranged"],stats:{speed:76,maxHp:16,radius:11},contact:{dps:2},rewards:{xp:5,credits:1},ai:{type:"ranged",range:300,keep:210,cooldown:1.9,windup:.38,projectile:{speed:260,lifetime:1.4,radius:6,damage:5}},view:{kind:"dot",size:20,inner:"#f4fbff",mid:"#7ad4ff"}},{id:"frost-warden",name:"Frost Warden",title:"Cryo-Bound Sentinel",lore:"Heavy dockside hulks armored in glacier-thick salt plate and quenched iron. Their relentless charge shatters brittle vessels that linger along the canal.",role:"fodder",tags:["fodder","chaser"],stats:{speed:90,maxHp:80,radius:20},contact:{dps:20},rewards:{xp:10,credits:5},ai:{type:"chase"},view:{kind:"dot",size:52,inner:"#e8f6ff",mid:"#3d8ad4"}},{id:"frost-sovereign",name:"Frost Sovereign",title:"Regent of the Frozen Dock",lore:"An ancient transmutation frozen mid-ascension when the sea-locks broke. Crowned in pale rime, it crushes any vessel that dares open the deeper Rift.",role:"boss",tags:["boss","ranged","summoner"],stats:{speed:66,maxHp:2100,radius:40},contact:{dps:26},rewards:{xp:75,credits:0},ai:{type:"boss",keep:260,enrage:{hpPct:.5,cooldownMul:.75},attacks:[{type:"bolt",name:"Cryo Lance",anim:"attack-bolt",cooldown:2.2,windup:.45,projectile:{speed:360,lifetime:1.8,radius:9,damage:14}},{type:"cone",name:"Glacial Sweep",anim:"attack-sweep",cooldown:6.5,windup:.75,lingering:.55,range:320,angle:75,damage:12,slowMul:.22,slowDuration:2.8},{type:"prison",name:"Rime Prison",anim:"attack-prison",cooldown:8.5,windup:.35,delay:1.15,radius:64,damage:16,rootDuration:1.6},{type:"summon",name:"Rime Brood",anim:"summon",cooldown:9,windup:.35,entity:"frost-mite",count:3,maxAlive:6}]},view:{kind:"dot",size:80,inner:"#f4fbff",mid:"#7ad4ff"}},{id:"frost-emperor",name:"Frost Emperor",title:"Monarch of Absolute Zero",lore:"Entombed at the bottom of the Great Work where heat and motion cease. It is the final seal-keeper; to shatter its glacial hull is to complete the transmutation.",role:"boss",tags:["boss","ranged","summoner"],stats:{speed:70,maxHp:2800,radius:45},contact:{dps:30},rewards:{xp:120,credits:0},ai:{type:"boss",keep:280,enrage:{hpPct:.5,cooldownMul:.72},attacks:[{type:"bolt",name:"Glacial Spear",anim:"attack-bolt",cooldown:2.4,windup:.4,projectile:{speed:400,lifetime:1.9,radius:10,damage:18}},{type:"pulse",name:"Absolute Zero Pulse",anim:"attack-pulse",cooldown:12,windup:1.8,radius:620,damage:48,slowMul:.35,slowDuration:2.5},{type:"laser",name:"Aether Laser",anim:"attack-laser",cooldown:9.5,windup:.8,duration:2.4,trackSpeed:220,hitRadius:28,dps:28,trailInterval:.22,trailPool:{duration:3.5,radius:34,dps:7,slowMul:.55}},{type:"summon",name:"Imperial Guard",anim:"summon",cooldown:10,windup:.35,entity:"frost-mite",count:3,maxAlive:6},{type:"summon",name:"Brine Retinue",anim:"summon",cooldown:14,windup:.35,entity:"frost-spitter",count:2,maxAlive:3}]},view:{kind:"dot",size:90,inner:"#ffffff",mid:"#3d8ad4"}},{id:"enemy-astral-sniper",name:"Astral Watcher",title:"Ocular of the Void",lore:"A disembodied brass-and-aether eye that drifts at the edge of sight. It traces a thin celestial sightline before lancing the arena—only solid pillars can break its gaze.",role:"fodder",tags:["fodder","sniper"],stats:{speed:36,maxHp:8,radius:10},contact:{dps:1},rewards:{xp:6,credits:2},ai:{type:"sniper",keep:480,cooldown:3.2,windup:1.5,damage:28,lineWidth:10},view:{kind:"dot",size:22,inner:"#f0e8ff",mid:"#7a3aff"}}],Ll={version:Dl,entries:Pl},Nl=1,Fl=[{id:"glass-cannon",name:"Vitriol Veins",rarity:"rare",stack:"linear",hooks:[{op:"pct",stat:"damage",value:.55},{op:"pct",stat:"maxHp",value:-.25}],lore:"Distilled volatile acid replaces your vital humors. Your strikes shatter stone with ferocious power, though your brittle shell can endure little punishment."},{id:"goat-hoof",name:"Cloven Sinew",rarity:"common",stack:"linear",hooks:[{op:"pct",stat:"speed",value:.15}],lore:"Grafted tendon from a swift sacrificial beast, woven into the vessel's stride to grant tireless speed across the arena."},{id:"brittle-plate",name:"Slag Carapace",rarity:"common",stack:"linear",hooks:[{op:"pct",stat:"armor",value:.12}],lore:"Cooled furnace dross fused directly to the ribs, absorbing kinetic blows and turning aside the fiercest enemy strikes."},{id:"hair-trigger",name:"Spasmodic Nerve",rarity:"uncommon",stack:"linear",hooks:[{op:"pct",stat:"cooldown",value:-.15}],lore:"Refined quicksilver infused along the spinal conduit, sharpening synaptic reflexes so your arts can be invoked in rapid succession."},{id:"overclock",name:"Bellows Heart",rarity:"uncommon",stack:"linear",hooks:[{op:"pct",stat:"aoeRadius",value:.22},{op:"pct",stat:"projSpeed",value:.2}],lore:"Alchemical bellows fitted to the core, stoking inner combustion to propel your rites swifter and engulf wider swaths of the horde.",unlock:{type:"boss-kill",entityId:"cinder-heart",label:"Slay the Cinder Heart"}},{id:"wax-wings",name:"Waxen Pinions",rarity:"common",stack:"linear",hooks:[{op:"pct",stat:"hazardResist",value:.35}],lore:"Feathers sealed in consecrated sealing wax that insulate the vessel from boiling brimstone pools and caustic mire."},{id:"hungry-clip",name:"Parasitic Alembic",rarity:"rare",stack:"linear",hooks:[{op:"add",stat:"hpRegen",value:1},{op:"pct",stat:"controlDuration",value:.35},{op:"pct",stat:"radius",value:.25}],lore:"A living glass vessel engorged on distilled vitae. Steadies the vessel with ceaseless regeneration and prolongs your binding rites, but swells your frame into an easier target.",unlock:{type:"elite-kills",count:10,label:"Slay 10 Noxious Elites"}},{id:"lead-core",name:"Lead Plumbum",rarity:"common",stack:"linear",hooks:[{op:"add",stat:"maxHp",value:25}],lore:"A dense sphere of alchemical lead settled in the vessel, firmly anchoring the animating humors against collapse."},{id:"mercury-vial",name:"Quicksilver Draught",rarity:"uncommon",stack:"linear",hooks:[{op:"pct",stat:"pickupRadius",value:.35},{op:"pct",stat:"xpGain",value:.15}],lore:"Purified liquid argent that resonates with spilled essence, drawing distant mercury drops to your core and transmuting them into richer insight."},{id:"calcined-lens",name:"Astrologer's Ocular",rarity:"rare",stack:"linear",hooks:[{op:"pct",stat:"critChance",value:.25},{op:"on-crit",stat:"cooldown",value:.25},{op:"pct",stat:"speed",value:-.15}],lore:"A heavy brass ocular bolted to the brow. Pinpoints fatal celestial fractures to trigger devastating critical strikes that hasten your rites, at the heavy cost of your stride.",unlock:{type:"total-kills",count:300,label:"Slay 300 Dross across workings"}},{id:"salt-ward",name:"Salt Effigy",rarity:"common",stack:"linear",hooks:[{op:"pct",stat:"radius",value:-.12}],lore:"Desiccates the vessel's silhouette into a compact, elusive form that slips cleanly between striking claws and projectiles.",unlock:{type:"stage-clear",stageId:"cinder-yard",label:"Clear the Cinder Yard"}},{id:"lunar-tithe",name:"Pale Moon Covenant",rarity:"lunar",stack:"linear",hooks:[{op:"pct",stat:"eliteDamage",value:.6},{op:"pct",stat:"critDamage",value:.75},{op:"pct",stat:"armor",value:-.25},{op:"pct",stat:"xpGain",value:-.25}],lore:"An unforgiven heresy against the Great Work. Ignites your arts with catastrophic ruin against guardians and elite horrors, but renders your shell fragile and rejects ambient insight.",unlock:{type:"stage-clear",stageId:"rime-dock",label:"Clear the Rime Dock"}},{id:"cinnabar-leech",name:"Cinnabar Leech",rarity:"common",stack:"linear",hooks:[{op:"on-kill",stat:"hp",value:.3}],lore:"A vermilion leech sealed in amber glass. It drinks the lingering humors from slain enemies and siphons their vital essence into your vessel.",unlock:{type:"total-kills",count:100,label:"Slay 100 Dross across workings"}}],Bl={version:Nl,entries:Fl},Hl=1,$l=32,_l=1.3,Gl=36,Ol=0,Vl=88,Ul=320,Wl=24,zl=6,Xl=999,Yl=128,Kl=4,jl=3,ql=70,Zl=1.4,Ql={creditRate:3,fodderCost:6,eliteCost:18,sniperCost:18,fodderInterval:1.6,eliteInterval:14,sniperInterval:9,maxSnipers:3,spawnMin:460,spawnMax:900,spawnSafeRadius:460,groupSizeMin:3,groupSizeMax:6,eliteGroupSizeMin:1,eliteGroupSizeMax:1,groupSpreadRadius:56,eliteChanceBase:.02,eliteChancePerCoeff:.12,eliteChanceMax:.4,eliteCostMul:3},Jl={hpMul:2.4,damageMul:1.5,xpMul:2.5,creditsMul:2.5,radiusMul:1.25},ec={contactSlowMul:.5,contactSlowDuration:1.1,corpseDelay:.5,popRadius:40,popDamage:8,poolDuration:6},tc={delay:5,percentHp:.3},sc={perSecond:.0032,stageBonus:0,speedPerCoeff:.035},nc={common:1,uncommon:.55,rare:.22,lunar:.08},ac={fodder:.025,elite:.25,boss:.6},ic=[{id:"cinder-yard",name:"Cinder Yard",kicker:"First Chamber · Nigredo & Calcination",lore:"The outer foundry where raw matter was burned to black ash. Obsidian kilns still vent superheated slag, and volatile brimstone urns litter the cracked flagstones.",fodder:"ember-mite",ranged:"ember-spitter",rangedChance:.22,sniper:"enemy-astral-sniper",elite:"ember-chaser",boss:"cinder-heart",firstEliteAt:25,teleporterAt:55,teleporterHold:20,teleporterRadius:160,view:{grid:"#443436",border:"#5a3020",zone:"#e35d5d",portal:"#ffb347"}},{id:"rime-dock",name:"Rime Dock",kicker:"Second Chamber · Albedo & Fixation",lore:"A subterranean canal where alchemical salts and quicksilver were quenched in freezing brine. Frozen bollards block stray bolts while pressurized rime casks threaten to shatter in a numbing frost.",fodder:"frost-mite",ranged:"frost-spitter",rangedChance:.22,sniper:"enemy-astral-sniper",elite:"frost-warden",boss:"frost-sovereign",firstEliteAt:18,teleporterAt:50,teleporterHold:22,teleporterRadius:150,view:{grid:"#142033",border:"#3a5a7a",zone:"#5ad4ff",portal:"#dff6ff"}},{id:"glacial-tomb",name:"Glacial Tomb",kicker:"Final Chamber · Rubedo & The Great Seal",lore:"The deepest vault beneath the canal, sealed in eternal permafrost to contain the Frost Emperor. Here the Transmutation Circle demands the longest vigil before the Great Work is decided.",fodder:"frost-mite",ranged:"frost-spitter",rangedChance:.28,sniper:"enemy-astral-sniper",elite:"frost-warden",boss:"frost-emperor",firstEliteAt:14,teleporterAt:50,teleporterHold:25,teleporterRadius:140,view:{grid:"#101826",border:"#2a4a6a",zone:"#4ac4ef",portal:"#cff0ff"}}],oc={version:Hl,xpBase:$l,xpGrowth:_l,gemPickup:Gl,gemMagnet:Ol,gemMagnetBonus:Vl,gemMagnetSpeed:Ul,maxFodder:Wl,maxElites:zl,maxGems:Xl,hashCell:Yl,fodderContactCap:Kl,levelChoices:jl,portalRadius:ql,portalHold:Zl,director:Ql,elite:Jl,noxious:ec,shielder:tc,difficulty:sc,rarityWeight:nc,loreDropChance:ac,stages:ic},rc=1,lc={pillar:14,hazard:8,volatile:9},cc=8,dc=160,uc=200,fc=230,mc=200,hc=190,pc=80,gc={radius:28},yc={radius:68,playerSpeedMul:.65,enemySpeedMul:.85,dps:4},vc={radius:14,hp:25,prime:.4,explosionRadius:110,enemyDamage:45,playerDamage:18,rimeSlowDuration:2,rimeSlowMul:.7},bc={"cinder-yard":{pillar:"Obsidian Kiln",hazard:"Slag Fissure",volatile:"Brimstone Urn"},"rime-dock":{pillar:"Frozen Bollard",hazard:"Brine Pool",volatile:"Pressurized Rime Cask"},"glacial-tomb":{pillar:"Glacial Monolith",hazard:"Permafrost Crevasse",volatile:"Volatile Ice Chunk"}},xc={version:rc,counts:lc,dynamicHazards:cc,borderPad:dc,playerKeepOut:uc,teleporterKeepOut:fc,volatileTeleporterKeepOut:mc,minSpacing:hc,placeRetries:pc,pillar:gc,hazard:yc,volatile:vc,biomes:bc},Re=1,kc=1,Sc=[{id:"bolt",name:"Ignis Bolt",slot:"primary",input:"hold",cooldown:.28,lore:"A needle of fire. It only flies where you point.",hook:"Fires searing bolts of flame toward your cursor.",effects:[{type:"projectile",speed:780,lifetime:.85,radius:5,damage:10}]},{id:"dash",name:"Phase Step",slot:"utility",input:"press",cooldown:2.9,lore:"The vessel slips between worlds for a breath.",hook:"Dash swiftly forward, phasing harmlessly through foes and projectiles.",effects:[{type:"dash",distance:210,duration:.16,iframe:.22}]},{id:"skill-aether-pierce",name:"Piercing Aether",slot:"secondary",input:"press",cooldown:4,lore:"A thin ray of stolen sky. Line them up or waste the breath.",hook:"Lances through every foe in a line, briefly steadying your stride.",effects:[{type:"projectile",speed:1400,lifetime:.45,radius:6,damage:22,pierce:!0},{type:"self-slow",mul:.5,duration:.25}]},{id:"skill-crucible-cull",name:"Crucible Cull",slot:"special",input:"press",cooldown:12,lore:"A hammer of the Great Work, dropped where you will it.",hook:"Calls down a concentrated alchemical strike at the cursor after a brief delay.",effects:[{type:"delayed-strike",delay:.7,radius:45,damage:95}]},{id:"skill-censer-lob",name:"Censer Lob",slot:"primary",input:"hold",cooldown:.42,lore:"Heavy glass, thrown in an arc. The air between you and the stain is empty.",hook:"Lobs a heavy censer over the horde that shatters on impact, scorching nearby foes.",effects:[{type:"projectile",speed:420,lifetime:1.1,radius:7,damage:14,flyOver:!0,impactRadius:30}]},{id:"skill-brimstone-line",name:"Brimstone Line",slot:"secondary",input:"press",cooldown:5,lore:"A seam of sulfur drawn across the yard. The small ones fear it.",hook:"Draws a burning seam of sulfur that slows lesser foes crossing it.",effects:[{type:"slow-line",length:150,width:18,duration:2.4,slowMul:.2,damage:2,fodderOnly:!0,offset:56}]},{id:"dash-ash-step",name:"Ash Step",slot:"utility",input:"press",cooldown:3,lore:"Leave a husk of ash. The mites chase the ghost.",hook:"Dash to safety while leaving an ash effigy that lures lesser foes.",effects:[{type:"dash",distance:210,duration:.16,iframe:.22,decoyDuration:1.5}]},{id:"skill-condemn-tether",name:"Condemnation Tether",slot:"special",input:"press",cooldown:15,lore:"A chain for the proud. The small are ash before the iron locks.",hook:"Pierces and incinerates lesser foes to bind the first elite or boss struck with a searing chain.",effects:[{type:"tether",speed:640,lifetime:.7,radius:10,rootDuration:2.5,fodderDamage:45,fodderContactDps:28}]}],Ec={version:kc,entries:Sc},Cc=1,Mc=[{id:"runner",name:"Homunculus",title:"The Runner",lore:"Clay and quicksilver, stolen from a failed Great Work. You kite the dross until the seal holds.",stats:{speed:280,maxHp:100,radius:14},skills:{primary:"bolt",secondary:"skill-aether-pierce",utility:"dash",special:"skill-crucible-cull"},startingItems:[],view:{kind:"chevron",size:32,inner:"#dff6ff",mid:"#5ad4ff"},crosshair:"runner"},{id:"penitent",name:"The Penitent",title:"The Caster",lore:"A monk who walked into the kiln and did not burn. He draws circles the horde must not cross.",stats:{speed:245,maxHp:135,radius:14},skills:{primary:"skill-censer-lob",secondary:"skill-brimstone-line",utility:"dash-ash-step",special:"skill-condemn-tether"},startingItems:[],view:{kind:"chevron",size:32,inner:"#f0e0c8",mid:"#c4783a"},crosshair:"penitent",unlock:{type:"boss-kill",entityId:"frost-sovereign",stageId:"rime-dock",label:"Slay the Frost Sovereign in the Rime Dock"}}],wc={version:Cc,entries:Mc},Rc=1,Tc=2560,Ac=2560,Ic=21,Dc=34,Pc=2.5,Lc=128,Nc="runner",Fc="ember-chaser",Bc={version:Rc,width:Tc,height:Ac,borderInsetX:Ic,borderInsetY:Dc,viewZoom:Pc,maxProjectiles:Lc,defaultSurvivor:Nc,defaultEnemy:Fc},Hc=new Set(["projectile","dash","self-slow","delayed-strike","slow-line","tether"]),$c=new Set(["add","pct","on-kill","on-crit"]),E=_c();function _c(){const e=Gc(Bc),s=Oc(oc),t=Vc(xc),n=ls("skills.json",rs(Ec,"skills.json")),a=ls("survivors.json",rs(wc,"survivors.json")),i=ls("entities.json",rs(Ll,"entities.json")),o=ls("items.json",rs(Bl,"items.json"));for(const l of i.values()){if(!l.lore||typeof l.lore!="string")throw new Error(`Entity "${l.id}" missing lore`);if(l.role==="boss"){if(l.ai.type!=="boss")throw new Error(`Boss "${l.id}" must use ai.type "boss"`);if(!Array.isArray(l.ai.attacks)||l.ai.attacks.length===0)throw new Error(`Boss "${l.id}" needs at least one attack`);for(const c of l.ai.attacks){if(!(c.cooldown>0))throw new Error(`Boss "${l.id}" attack "${c.type}" must have cooldown > 0`);if(c.type==="summon"){const d=i.get(c.entity);if(!d)throw new Error(`Boss "${l.id}" summon points to missing entity "${c.entity}"`);if(d.role!=="fodder")throw new Error(`Boss "${l.id}" summon "${c.entity}" must have role "fodder"`);if(!(c.count>0)||!(c.maxAlive>=c.count))throw new Error(`Boss "${l.id}" summon "${c.entity}" has invalid count/maxAlive`)}}}}for(const l of o.values()){for(const c of l.hooks){if(!$c.has(c.op))throw new Error(`Item "${l.id}" uses unimplemented hook "${c.op}"`);if(c.op==="on-kill"&&c.stat!=="hp")throw new Error(`Item "${l.id}" on-kill stat must be hp`);if(c.op==="on-crit"&&c.stat!=="cooldown")throw new Error(`Item "${l.id}" on-crit stat must be cooldown`)}l.unlock&&ii(`Item "${l.id}"`,l.unlock,s.stages,i)}for(const l of n.values())for(const c of l.effects)if(!Hc.has(c.type))throw new Error(`Skill "${l.id}" uses unimplemented effect "${c.type}"`);for(const l of a.values()){for(const c of["primary","secondary","utility","special"]){const d=l.skills[c];if(d&&!n.has(d))throw new Error(`Survivor "${l.id}" slot ${c} points to missing skill "${d}"`)}for(const c of l.startingItems)if(!o.has(c))throw new Error(`Survivor "${l.id}" starting item missing: "${c}"`);l.unlock&&ii(`Survivor "${l.id}"`,l.unlock,s.stages,i)}const r=["fodder","elite","boss"];for(const l of r){const c=s.loreDropChance?.[l];if(typeof c!="number"||c<0||c>1)throw new Error(`loop.json loreDropChance.${l} must be a number between 0 and 1`)}if(!a.has(e.defaultSurvivor))throw new Error(`world.defaultSurvivor missing: "${e.defaultSurvivor}"`);if(!i.has(e.defaultEnemy))throw new Error(`world.defaultEnemy missing: "${e.defaultEnemy}"`);if(s.stages.length<1)throw new Error("loop.json needs at least one stage");for(const l of s.stages){if(wn(i,l,"fodder"),wn(i,l,"elite"),wn(i,l,"boss"),!t.biomes[l.id])throw new Error(`obstacles.json missing biome names for stage "${l.id}"`);if(l.ranged){const c=i.get(l.ranged);if(!c)throw new Error(`Stage "${l.id}" ranged missing: "${l.ranged}"`);if(c.role!=="fodder")throw new Error(`Stage "${l.id}" ranged "${l.ranged}" has role "${c.role}"`);if(c.ai.type!=="ranged")throw new Error(`Stage "${l.id}" ranged "${l.ranged}" ai must be ranged`)}if(l.sniper){const c=i.get(l.sniper);if(!c)throw new Error(`Stage "${l.id}" sniper missing: "${l.sniper}"`);if(c.role!=="fodder")throw new Error(`Stage "${l.id}" sniper "${l.sniper}" has role "${c.role}"`);if(c.ai.type!=="sniper")throw new Error(`Stage "${l.id}" sniper "${l.sniper}" ai must be sniper`)}}return{world:e,loop:s,obstacles:t,skill:cs(n,"skill"),survivor:cs(a,"survivor"),entity:cs(i,"entity"),item:cs(o,"item"),items:[...o.values()],entities:[...i.values()],survivors:[...a.values()]}}function wn(e,s,t){const n=s[t],a=e.get(n);if(!a)throw new Error(`Stage "${s.id}" ${t} missing: "${n}"`);const i=t==="elite"?"fodder":t;if(a.role!==i)throw new Error(`Stage "${s.id}" ${t} "${n}" has role "${a.role}", expected "${i}"`)}function ii(e,s,t,n){if(!s.label||typeof s.label!="string")throw new Error(`${e} unlock missing label`);if(s.type==="stage-clear"){if(!t.some(a=>a.id===s.stageId))throw new Error(`${e} unlock references unknown stage "${s.stageId}"`);return}if(s.type==="boss-kill"){if(!n.has(s.entityId))throw new Error(`${e} unlock references unknown entity "${s.entityId}"`);if(s.stageId&&!t.some(a=>a.id===s.stageId))throw new Error(`${e} unlock references unknown stage "${s.stageId}"`);return}if(s.type==="total-kills"||s.type==="elite-kills"||s.type==="victories"){if(typeof s.count!="number"||s.count<=0)throw new Error(`${e} unlock.count must be > 0`);return}throw new Error(`${e} uses unknown unlock type "${s.type}"`)}function Gc(e){const s=e;if(s.version!==Re)throw new Error(`world.json version ${s.version}, expected ${Re}`);return s}function Oc(e){const s=e;if(s.version!==Re)throw new Error(`loop.json version ${s.version}, expected ${Re}`);if(!Array.isArray(s.stages))throw new Error("loop.json missing stages[]");const t=s.director;if(!(t.groupSizeMin>0)||!(t.groupSizeMax>=t.groupSizeMin)||!(t.eliteGroupSizeMin>0)||!(t.eliteGroupSizeMax>=t.eliteGroupSizeMin)||!(t.groupSpreadRadius>0)||!(t.eliteCostMul>=1))throw new Error("loop.json director group/elite sizing config invalid");const n=s.elite;if(!n||!(n.hpMul>0)||!(n.damageMul>0)||!(n.xpMul>0)||!(n.creditsMul>0)||!(n.radiusMul>0))throw new Error("loop.json missing valid elite multiplier config");return s}function Vc(e){const s=e;if(s.version!==Re)throw new Error(`obstacles.json version ${s.version}, expected ${Re}`);const t=["pillar","hazard","volatile"];for(const n of t)if(!(s.counts[n]>0))throw new Error(`obstacles.json counts.${n} must be > 0`);if(!(s.dynamicHazards>=0))throw new Error("obstacles.json dynamicHazards must be >= 0");return s}function rs(e,s){if(e.version!==Re)throw new Error(`${s} version ${e.version}, expected ${Re}`);if(!Array.isArray(e.entries))throw new Error(`${s} missing entries[]`);return e.entries}function ls(e,s){const t=new Map;for(const n of s){if(!n.id)throw new Error(`${e} entry missing id`);if(t.has(n.id))throw new Error(`${e} duplicate id "${n.id}"`);t.set(n.id,n)}return t}function cs(e,s){return t=>{const n=e.get(t);if(!n)throw new Error(`Unknown ${s} "${t}"`);return n}}function q(e,s,t,n,a,i){const o=e-n,r=s-a,l=t+i;return o*o+r*r<=l*l}function Ue(e,s,t,n,a,i){return Math.abs(e-n)<=t+i&&Math.abs(s-a)<=t+i}function V(e,s,t){return Math.max(s,Math.min(t,e))}function Uc(e,s,t,n,a,i,o,r){const l=e-n,c=s-a;let d=Math.hypot(l,c);const u=t+i;if(d>=u)return{ax:e,ay:s,bx:n,by:a};if(d<1e-4)return{ax:e+u*o,ay:s,bx:n-u*r,by:a};const f=u-d,m=l/d,h=c/d;return{ax:e+m*f*o,ay:s+h*f*o,bx:n-m*f*r,by:a-h*f*r}}function Wc(e,s,t,n,a,i){const o=a-t,r=i-n,l=o*o+r*r;if(l===0)return Math.hypot(e-t,s-n);let c=((e-t)*o+(s-n)*r)/l;return c=Math.max(0,Math.min(1,c)),Math.hypot(e-(t+c*o),s-(n+c*r))}function zc(e=Il){return{cap:e,count:0,kind:new Uint8Array(e),x:new Float32Array(e),y:new Float32Array(e),tint:new Uint32Array(e),radius:new Float32Array(e)}}function F(e,s,t,n,a,i=0){if(e.count>=e.cap)return;const o=e.count;e.kind[o]=s,e.x[o]=t,e.y[o]=n,e.tint[o]=a,e.radius[o]=i,e.count+=1}function Xc(e){e.count=0}function Yc(e,s){s<=0||(e.rootRemain=Math.max(e.rootRemain,s))}function Kc(e,s){e.rootRemain>0&&(e.rootRemain=Math.max(0,e.rootRemain-s))}function Be(e,s,t){t<=0||s>=1||(e.slowRemain<=0||s<=e.slowMul)&&(e.slowMul=s,e.slowRemain=Math.max(e.slowRemain,t))}function jc(e,s){if(e.slowRemain<=0){e.slowMul=1;return}e.slowRemain=Math.max(0,e.slowRemain-s),e.slowRemain<=0&&(e.slowMul=1)}function yo(e,s,t,n){n<=0||t>=1||(e.slowRemain[s]<=0||t<=e.slowMul[s])&&(e.slowMul[s]=t,e.slowRemain[s]=Math.max(e.slowRemain[s],n))}function qc(e,s,t){if(e.slowRemain[s]<=0){e.slowMul[s]=1;return}e.slowRemain[s]=Math.max(0,e.slowRemain[s]-t),e.slowRemain[s]<=0&&(e.slowMul[s]=1)}function Zc(e){const{eliteChanceBase:s,eliteChancePerCoeff:t,eliteChanceMax:n}=e.catalog.loop.director,a=s+Math.max(0,e.coefficient-1)*t;return V(a,0,n)}function Qc(e,s){if(e.bossSpawned||e.bossDefeated)return;const{loop:t}=e.catalog,n=t.stages[e.stageIndex];e.credits+=t.director.creditRate*e.coefficient*s,Jc(e),ed(e),e.stageTime>=n.firstEliteAt&&td(e)}function Jc(e){const{loop:s}=e.catalog,t=s.stages[e.stageIndex];if(e.stageTime-e.lastFodderAt<s.director.fodderInterval)return;const n=t.ranged,i=!!n&&Math.random()<(t.rangedChance??0)&&n?n:t.fodder,o=e.catalog.entity(i);xa(e,o,s.director.fodderCost)&&(e.lastFodderAt=e.stageTime)}function ed(e){const{loop:s}=e.catalog,t=s.stages[e.stageIndex];if(!t.sniper)return;const n=$u(e);if(n>=s.director.maxSnipers||e.stageTime-e.lastSniperAt<s.director.sniperInterval)return;const a=s.director.maxSnipers-n,i=e.catalog.entity(t.sniper);xa(e,i,s.director.sniperCost,a)&&(e.lastSniperAt=e.stageTime)}function td(e){const{loop:s}=e.catalog,t=s.stages[e.stageIndex];if(e.stageTime-e.lastEliteAt<s.director.eliteInterval)return;const n=e.catalog.entity(t.elite);xa(e,n,s.director.eliteCost)&&(e.lastEliteAt=e.stageTime)}function xa(e,s,t,n){const{loop:a}=e.catalog,i=a.stages[e.stageIndex],o=a.director,r=e.teleporter.state==="hidden"?1:a.maxElites,l=t*o.eliteCostMul;if(e.stageTime>=i.firstEliteAt&&e.counts.elite<r&&e.credits>=l&&Math.random()<Zc(e)){const p=r-e.counts.elite;let g=oi(o.eliteGroupSizeMin,o.eliteGroupSizeMax);n!==void 0&&(g=Math.min(g,n)),g=Math.min(g,p);const v=Math.floor(e.credits/l);if(g=Math.min(g,v),g<=0)return!1;const y=hi(e,s,g,!0);return y<=0?!1:(e.credits-=y*l,!0)}if(e.counts.fodder>=a.maxFodder||e.credits<t)return!1;const u=a.maxFodder-e.counts.fodder;let f=oi(o.groupSizeMin,o.groupSizeMax);n!==void 0&&(f=Math.min(f,n)),f=Math.min(f,u);const m=Math.floor(e.credits/t);if(f=Math.min(f,m),f<=0)return!1;const h=hi(e,s,f,!1);return h<=0?!1:(e.credits-=h*t,!0)}function oi(e,s){return e+Math.floor(Math.random()*(s-e+1))}const vo=.5,bo=2,ri={speed:0,maxHp:0,radius:0,damage:0,cooldown:0,critChance:0,critDamage:0,armor:0,hazardResist:0,hpRegen:0,pickupRadius:0,xpGain:0,aoeRadius:0,projSpeed:0,controlDuration:0,eliteDamage:0};function xo(e,s,t){const n={...ri},a={...ri};for(const d of s){const u=t(d.id),f=u.stack==="none"?1:Math.max(1,d.stacks);for(const m of u.hooks){if(m.op==="on-kill"||m.op==="on-crit")continue;const h=m.value*f;m.op==="add"?n[m.stat]+=h:a[m.stat]+=h}}const i=e.radius||14,o=(e.radius+n.radius)*(1+a.radius),r=Math.max(1,i*vo),l=Math.max(r,i*bo),c=Math.max(r,Math.min(l,o));return{speed:(e.speed+n.speed)*(1+a.speed),maxHp:(e.maxHp+n.maxHp)*(1+a.maxHp),radius:c,damageMul:(1+n.damage)*(1+a.damage),cooldownMul:(1+n.cooldown)*(1+a.cooldown),critChance:Math.max(0,Math.min(1,(e.critChance??.05)+n.critChance+a.critChance)),critMul:Math.max(1,(e.critDamage??2)+n.critDamage+a.critDamage),armor:Math.max(-1,Math.min(.75,n.armor+a.armor)),hazardResist:Math.max(0,Math.min(.85,n.hazardResist+a.hazardResist)),hpRegen:Math.max(0,n.hpRegen*(1+a.hpRegen)),pickupRadiusMul:Math.max(.25,(1+n.pickupRadius)*(1+a.pickupRadius)),xpMul:Math.max(.1,(1+n.xpGain)*(1+a.xpGain)),aoeRadiusMul:Math.max(.25,(1+n.aoeRadius)*(1+a.aoeRadius)),projSpeedMul:Math.max(.25,(1+n.projSpeed)*(1+a.projSpeed)),controlDurationMul:Math.max(.25,(1+n.controlDuration)*(1+a.controlDuration)),eliteDamageMul:Math.max(.25,(1+n.eliteDamage)*(1+a.eliteDamage))}}function sd(e,s){let t=0;for(const n of e){const a=s(n.id),i=a.stack==="none"?1:Math.max(1,n.stacks);for(const o of a.hooks)o.op==="on-kill"&&o.stat==="hp"&&(t+=o.value*i)}return t}function nd(e,s){let t=0;for(const n of e){const a=s(n.id),i=a.stack==="none"?1:Math.max(1,n.stacks);for(const o of a.hooks)o.op==="on-crit"&&o.stat==="cooldown"&&(t+=o.value*i)}return t}function ka(e,s,t){return Math.round(e*s**(t-1))}function ko(e,s){if(s<=0)return;const{loop:t}=e.catalog;for(e.xp+=s;e.xp>=e.xpNeed;)e.xp-=e.xpNeed,e.level+=1,e.pendingLevels+=1,e.xpNeed=ka(t.xpBase,t.xpGrowth,e.level);e.pendingLevels>0&&e.phase==="play"&&(e.phase="levelup",e.offer=So(e))}function So(e){const s=e.catalog.loop.levelChoices,t=new Set(e.inventory.filter(r=>e.catalog.item(r.id).stack==="none").map(r=>r.id)),n=e.catalog.items.filter(r=>e.unlockedItems.has(r.id)&&!t.has(r.id)),a=n.length>0?n:e.catalog.items.filter(r=>!t.has(r.id)),i=[],o=new Set;for(let r=0;r<s;r+=1){const l=od(a.filter(c=>!o.has(c.id)),e.catalog.loop.rarityWeight);if(!l)break;o.add(l.id),i.push(l)}return i}function ad(e,s){if(e.phase!=="levelup"||!e.offer)return!1;const t=e.offer[s];return t?(id(e,t.id),Eo(e),e.pendingLevels=Math.max(0,e.pendingLevels-1),e.pendingLevels>0?(e.offer=So(e),!0):(e.offer=null,e.phase=e.won?"victory":"play",!0)):!1}function Eo(e){const s=e.player.maxHp;e.stats=xo(e.survivor.stats,e.inventory,e.catalog.item);const t=e.stats.maxHp;e.player.maxHp=t,e.player.radius=e.stats.radius,e.player.speed=e.stats.speed,e.player.hp=Math.min(t,Math.max(1,e.player.hp+(t-s)))}function id(e,s){const t=e.catalog.item(s),n=e.inventory.find(a=>a.id===s);if(n&&t.stack==="linear"){n.stacks+=1;return}n||e.inventory.push({id:s,stacks:1})}function od(e,s){if(e.length===0)return null;let t=0;for(const a of e)t+=s[a.rarity]??1;let n=Math.random()*t;for(const a of e)if(n-=s[a.rarity]??1,n<=0)return a;return e[e.length-1]}const Sa=8;function rd(e){return{cap:e,alive:new Uint8Array(e),x:new Float32Array(e),y:new Float32Array(e),xp:new Float32Array(e)}}function ld(e=Sa){return{cap:e,alive:new Uint8Array(e),x:new Float32Array(e),y:new Float32Array(e),entityId:new Array(e).fill(null)}}function cd(e,s,t,n){for(let a=0;a<e.cap;a+=1)if(e.alive[a]===0)return e.alive[a]=1,e.x[a]=s,e.y[a]=t,e.xp[a]=n,!0;return!1}function Co(e,s){for(let t=0;t<e.cap;t+=1)if(e.alive[t]!==0&&e.entityId[t]===s)return!0;return!1}function dd(e,s,t,n){if(Co(e,n))return!1;for(let a=0;a<e.cap;a+=1)if(e.alive[a]===0)return e.alive[a]=1,e.x[a]=s,e.y[a]=t,e.entityId[a]=n,!0;return!1}function ud(e){e.alive.fill(0)}function fd(e){e.alive.fill(0),e.entityId.fill(null)}function md(e,s){const{gems:t,player:n}=e,{gemPickup:a,gemMagnet:i,gemMagnetBonus:o=88,gemMagnetSpeed:r}=e.catalog.loop,l=a*e.stats.pickupRadiusMul,d=(e.stats.pickupRadiusMul>1?o:i)*e.stats.pickupRadiusMul,u=r*Math.max(1,e.stats.pickupRadiusMul);for(let f=0;f<t.cap;f+=1){if(t.alive[f]===0)continue;const m=n.x-t.x[f],h=n.y-t.y[f],p=Math.hypot(m,h);if(p<=l){t.alive[f]=0,e.gemsCollected+=1,F(e.fx,Gs,t.x[f],t.y[f],8969727),ko(e,t.xp[f]*e.stats.xpMul);continue}if(p<d&&p>.001){const g=u*s/p;t.x[f]+=m*g,t.y[f]+=h*g}}}function hd(e,s){const{lores:t,player:n}=e,{gemPickup:a,gemMagnet:i,gemMagnetBonus:o=88,gemMagnetSpeed:r}=e.catalog.loop,l=a*e.stats.pickupRadiusMul,d=(e.stats.pickupRadiusMul>1?o:i)*e.stats.pickupRadiusMul,u=r*Math.max(1,e.stats.pickupRadiusMul);for(let f=0;f<t.cap;f+=1){if(t.alive[f]===0)continue;const m=n.x-t.x[f],h=n.y-t.y[f],p=Math.hypot(m,h);if(p<=l){const g=t.entityId[f];t.alive[f]=0,t.entityId[f]=null,F(e.fx,Gs,t.x[f],t.y[f],16765786),g&&!e.collectedLores.has(g)&&(e.collectedLores.add(g),e.newlyCollectedLores.push(g));continue}if(p<d&&p>.001){const g=u*s/p;t.x[f]+=m*g,t.y[f]+=h*g}}}function li(){return{primary:!1,secondary:!1,utility:!1,special:!1}}function pd(){return{primary:0,secondary:0,utility:0,special:0}}function gd(){return{moveX:0,moveY:0,aimX:0,aimY:0,held:li(),pressed:li()}}const pt=0,We=1,dn=1,Os=2,Yt=4,Kt=8;function yd(e){return{alive:new Uint8Array(e),team:new Uint8Array(e),flags:new Uint8Array(e),x:new Float32Array(e),y:new Float32Array(e),vx:new Float32Array(e),vy:new Float32Array(e),life:new Float32Array(e),radius:new Float32Array(e),damage:new Float32Array(e),destX:new Float32Array(e),destY:new Float32Array(e),impactRadius:new Float32Array(e),rootDuration:new Float32Array(e),tetherDps:new Float32Array(e),pierceHit0:new Uint32Array(e),pierceHit1:new Uint32Array(e)}}function Ht(e,s){for(let t=0;t<e.alive.length;t+=1)if(e.alive[t]===0)return e.alive[t]=1,e.team[t]=s.team,e.flags[t]=s.flags??0,e.x[t]=s.x,e.y[t]=s.y,e.vx[t]=s.dirX*s.speed,e.vy[t]=s.dirY*s.speed,e.life[t]=s.lifetime,e.radius[t]=s.radius,e.damage[t]=s.damage,e.destX[t]=s.destX??s.x,e.destY[t]=s.destY??s.y,e.impactRadius[t]=s.impactRadius??0,e.rootDuration[t]=s.rootDuration??0,e.tetherDps[t]=s.tetherDps??0,e.pierceHit0[t]=0,e.pierceHit1[t]=0,!0;return!1}function vd(e,s){for(let t=0;t<e.alive.length;t+=1)e.alive[t]!==0&&(e.x[t]+=e.vx[t]*s,e.y[t]+=e.vy[t]*s,e.life[t]-=s,!(e.life[t]>0)&&(e.flags[t]&Kt)===0&&(e.alive[t]=0))}function ci(e,s,t){const n=1<<(t&31);return t<32?(e.pierceHit0[s]&n)!==0:(e.pierceHit1[s]&n)!==0}function bd(e,s,t){const n=1<<(t&31);t<32?e.pierceHit0[s]|=n:e.pierceHit1[s]|=n}function $t(e,s){e.alive[s]=0}function xd(e){e.alive.fill(0)}function Mo(e){let s=2166136261;for(let t=0;t<e.length;t+=1)s^=e.charCodeAt(t),s=Math.imul(s,16777619);return s>>>0}function wo(e){let s=e>>>0;return()=>{s|=0,s=s+1831565813|0;let t=Math.imul(s^s>>>15,1|s);return t=t+Math.imul(t^t>>>7,61|t)^t,((t^t>>>14)>>>0)/4294967296}}function Ro(e){return{cell:e,buckets:new Map,pool:[],poolUsed:0}}function un(e){e.buckets.clear(),e.poolUsed=0}function Ea(e,s,t,n){const a=Math.floor(s/e.cell),i=Math.floor(t/e.cell),o=To(a,i);let r=e.buckets.get(o);r||(r=e.pool[e.poolUsed],r?r.length=0:(r=[],e.pool[e.poolUsed]=r),e.poolUsed+=1,e.buckets.set(o,r)),r.push(n)}function Ke(e,s,t,n,a){const{cell:i}=e,o=Math.floor((s-n)/i),r=Math.floor((s+n)/i),l=Math.floor((t-n)/i),c=Math.floor((t+n)/i);let d=0;for(let u=l;u<=c;u+=1)for(let f=o;f<=r;f+=1){const m=e.buckets.get(To(f,u));if(m)for(let h=0;h<m.length;h+=1){if(d>=a.length)return d;a[d]=m[h],d+=1}}return d}function To(e,s){return e+4096&8191|(s+4096&8191)<<13}function kd(e,s=0){return e.pillar+e.hazard+e.volatile+s}function Sd(e,s){const t=[];for(let n=0;n<e;n+=1)t.push(Dd());return{cap:e,alive:new Uint8Array(e),items:t,hash:Ro(s),scratch:new Array(Math.max(e,8)).fill(0),nextId:1}}function Ao(e){e.alive.fill(0),un(e.hash)}function Io(e){return e.player.dashRemain>0||e.player.iframeRemain>0}function Do(e){let s=e.player.slowMul;if(!Io(e)&&Lo(e,e.player.x,e.player.y,e.player.radius)){const n=1-(1-e.catalog.obstacles.hazard.playerSpeedMul)*(1-e.stats.hazardResist);s*=n}return s}function Ed(e){const s=e.catalog.obstacles;Ao(e.obstacles);const t=e.catalog.loop.stages[e.stageIndex],n=s.biomes[t.id],a=wo(Mo(t.id)^(e.stageIndex+1)*2654435769^e.stageGen*2246822507),i=[...Rn("pillar",s.counts.pillar),...Rn("hazard",s.counts.hazard),...Rn("volatile",s.counts.volatile)],o=[];for(const r of i){const l=Ad(e,r,a,o);l&&(No(e,r,l.x,l.y,n[r]),o.push(l))}Ma(e)}function Cd(e){const{obstacles:s,player:t,enemies:n}=e;for(let a=0;a<s.cap;a+=1){if(s.alive[a]===0)continue;const i=s.items[a];if(i.type!=="hazard"){di(t.x,t.y,t.radius,i,(o,r)=>{t.x=o,t.y=r});for(let o=0;o<n.cap;o+=1)n.alive[o]!==0&&di(n.x[o],n.y[o],n.radius[o],i,(r,l)=>{n.x[o]=r,n.y[o]=l})}}}function Md(e){const{projectiles:s,obstacles:t}=e,n=56;for(let a=0;a<s.alive.length;a+=1){if(s.alive[a]===0)continue;const i=Ke(t.hash,s.x[a],s.y[a],s.radius[a]+n,t.scratch);let o=-1,r=1/0;for(let l=0;l<i;l+=1){const c=t.scratch[l];if(t.alive[c]===0)continue;const d=t.items[c];if(d.type==="hazard"||!Ue(s.x[a],s.y[a],s.radius[a],d.x,d.y,d.radius)||!q(s.x[a],s.y[a],s.radius[a],d.x,d.y,d.radius))continue;const u=(d.x-s.x[a])**2+(d.y-s.y[a])**2;u<r&&(r=u,o=c)}if(!(o<0)&&(s.flags[a]&Os)===0){if(F(e.fx,_e,s.x[a],s.y[a],16774344),s.team[a]===pt){const l=s.damage[a]>0?s.damage[a]:s.tetherDps[a];l>0&&Ca(e,o,l)}$t(s,a)}}}function Ca(e,s,t){const n=e.obstacles.items[s];return n.type!=="volatile"||n.state!=="intact"?!1:(n.hp-=t,n.hp<=0&&(n.hp=0,n.state="primed",n.timer=e.catalog.obstacles.volatile.prime),!0)}function Po(e,s,t,n,a){const{obstacles:i}=e,r=Ke(i.hash,s,t,n+56,i.scratch);for(let l=0;l<r;l+=1){const c=i.scratch[l];if(i.alive[c]===0)continue;const d=i.items[c];d.type!=="volatile"||d.state!=="intact"||q(s,t,n,d.x,d.y,d.radius)&&Ca(e,c,a)}}function wd(e,s,t){const n=e.catalog.loop.noxious.poolDuration??6;No(e,"hazard",s,t,"Caustic Acid Pool",n),Ma(e)}function Rd(e,s){const{player:t,obstacles:n}=e;if(jc(t,s),Kc(t,s),!Io(e)&&Lo(e,t.x,t.y,t.radius)){const i=e.catalog.obstacles.hazard.dps*e.coefficient*s;se(e,i,!0)}let a=!1;for(let i=0;i<n.cap;i+=1){if(n.alive[i]===0)continue;const o=n.items[i];if(o.type==="hazard"&&o.timer>0){o.timer-=s,o.timer<=0&&(o.timer=0,n.alive[i]=0,a=!0);continue}o.type!=="volatile"||o.state!=="primed"||(o.timer-=s,!(o.timer>0)&&(Td(e,i),a=!0))}a&&Ma(e)}function Lo(e,s,t,n){const{obstacles:a}=e,i=Ke(a.hash,s,t,n+e.catalog.obstacles.hazard.radius,a.scratch);for(let o=0;o<i;o+=1){const r=a.scratch[o];if(a.alive[r]===0)continue;const l=a.items[r];if(l.type==="hazard"&&q(s,t,n,l.x,l.y,l.radius))return!0}return!1}function Td(e,s){const t=e.catalog.obstacles.volatile,n=e.obstacles.items[s],a=e.catalog.loop.stages[e.stageIndex].id==="rime-dock",i=t.explosionRadius,o=t.enemyDamage*e.coefficient;F(e.fx,we,n.x,n.y,16746564);const{enemies:r}=e;for(let c=0;c<r.cap;c+=1)r.alive[c]!==0&&q(n.x,n.y,i,r.x[c],r.y[c],r.radius[c])&&(ze(e,c,o),a&&yo(r,c,t.rimeSlowMul,t.rimeSlowDuration));const{player:l}=e;q(n.x,n.y,i,l.x,l.y,l.radius)&&(l.iframeRemain<=0&&(F(e.fx,ne,l.x,l.y,16724821),se(e,t.playerDamage)),a&&Be(l,t.rimeSlowMul,t.rimeSlowDuration)),n.state="detonated",n.timer=0,e.obstacles.alive[s]=0}function di(e,s,t,n,a){if(!q(e,s,t,n.x,n.y,n.radius))return;const i=Uc(e,s,t,n.x,n.y,n.radius,1,0);a(i.ax,i.ay)}function No(e,s,t,n,a,i=0){const{obstacles:o}=e;let r=-1;for(let f=0;f<o.cap;f+=1)if(o.alive[f]===0){r=f;break}if(r<0&&i>0){let f=1/0;for(let m=0;m<o.cap;m+=1)o.alive[m]!==0&&o.items[m].type==="hazard"&&o.items[m].timer>0&&o.items[m].timer<f&&(f=o.items[m].timer,r=m)}if(r<0)return;const l=e.catalog.obstacles,c=s==="pillar"?l.pillar.radius:s==="hazard"?l.hazard.radius:l.volatile.radius,d=s==="volatile"?l.volatile.hp*e.coefficient:0,u=o.items[r];u.id=o.nextId,o.nextId+=1,u.type=s,u.x=t,u.y=n,u.radius=c,u.hp=d,u.maxHp=d,u.state="intact",u.timer=i,u.biomeVariant=a,o.alive[r]=1}function Ad(e,s,t,n){const a=e.catalog.obstacles,{width:i,height:o}=e.catalog.world,r=s==="volatile"?a.volatileTeleporterKeepOut:a.teleporterKeepOut;for(let l=0;l<a.placeRetries;l+=1){const c=a.borderPad+t()*(i-a.borderPad*2),d=a.borderPad+t()*(o-a.borderPad*2);if(Math.hypot(c-e.player.x,d-e.player.y)<a.playerKeepOut||Math.hypot(c-e.teleporter.x,d-e.teleporter.y)<r)continue;let u=!1;for(let f=0;f<n.length;f+=1)if(Math.hypot(c-n[f].x,d-n[f].y)<a.minSpacing){u=!0;break}if(!u)return{x:c,y:d}}return null}function Ma(e){const{obstacles:s}=e;un(s.hash);for(let t=0;t<s.cap;t+=1)s.alive[t]!==0&&Ea(s.hash,s.items[t].x,s.items[t].y,t)}function Rn(e,s){const t=[];for(let n=0;n<s;n+=1)Id(t,e);return t}function Id(e,s){e.push(s)}function Dd(){return{id:0,type:"pillar",x:0,y:0,radius:0,hp:0,maxHp:0,state:"detonated",timer:0,biomeVariant:""}}const gt=0,fn=1;function Pd(e=8){return{cap:e,alive:new Uint8Array(e),kind:new Uint8Array(e),x:new Float32Array(e),y:new Float32Array(e),dirX:new Float32Array(e),dirY:new Float32Array(e),length:new Float32Array(e),width:new Float32Array(e),radius:new Float32Array(e),remain:new Float32Array(e),duration:new Float32Array(e),damage:new Float32Array(e),slowMul:new Float32Array(e),fodderOnly:new Uint8Array(e)}}function Ld(){return{active:!1,x:0,y:0,remain:0}}function Nd(e,s,t,n){n<=0||(e.active=!0,e.x=s,e.y=t,e.remain=n)}function Fd(e,s){const t=Fo(e);return t<0?!1:(e.alive[t]=1,e.kind[t]=gt,e.x[t]=s.x,e.y[t]=s.y,e.dirX[t]=s.dirX,e.dirY[t]=s.dirY,e.length[t]=s.length,e.width[t]=s.width,e.radius[t]=0,e.remain[t]=s.duration,e.duration[t]=s.duration,e.damage[t]=s.damage,e.slowMul[t]=s.slowMul,e.fodderOnly[t]=s.fodderOnly?1:0,!0)}function Bd(e,s){const t=Fo(e);return t<0?!1:(e.alive[t]=1,e.kind[t]=fn,e.x[t]=s.x,e.y[t]=s.y,e.dirX[t]=0,e.dirY[t]=0,e.length[t]=0,e.width[t]=0,e.radius[t]=s.radius,e.remain[t]=s.delay,e.duration[t]=s.delay,e.damage[t]=s.damage,e.slowMul[t]=1,e.fodderOnly[t]=0,!0)}function Hd(e){e.alive.fill(0)}function $d(e,s){const{zones:t,decoy:n}=e;n.active&&(n.remain-=s,n.remain<=0&&(n.active=!1,n.remain=0));for(let a=0;a<t.cap;a+=1)if(t.alive[a]!==0){if(t.remain[a]-=s,t.kind[a]===gt){_d(e,a,s),t.remain[a]<=0&&(t.alive[a]=0);continue}t.remain[a]<=0&&(Gd(e,a),t.alive[a]=0)}}function _d(e,s,t){const{zones:n,enemies:a}=e,i=n.length[s]*.5,o=n.width[s]*.5,r=n.fodderOnly[s]!==0,l=n.damage[s];for(let c=0;c<a.cap;c+=1)a.alive[c]!==0&&(r&&a.role[c]!==pe||ui(n,s,a.x[c],a.y[c],a.radius[c]+o,i)&&(yo(a,c,n.slowMul[s],.2),l>0&&ze(e,c,l*t)));if(l>0){const{obstacles:c}=e;for(let d=0;d<c.cap;d+=1){if(c.alive[d]===0)continue;const u=c.items[d];u.type!=="volatile"||u.state!=="intact"||ui(n,s,u.x,u.y,u.radius+o,i)&&Ca(e,d,l*t)}}}function Gd(e,s){const{zones:t,enemies:n}=e,a=t.x[s],i=t.y[s],o=t.radius[s],r=Math.random()<e.stats.critChance,l=r?t.damage[s]*e.stats.critMul:t.damage[s];F(e.fx,Dt,a,i,r?16729122:16760944,o);let c=!1;for(let d=0;d<n.cap;d+=1)n.alive[d]!==0&&q(a,i,o,n.x[d],n.y[d],n.radius[d])&&(F(e.fx,_e,n.x[d],n.y[d],r?16729122:16774344),ze(e,d,l),c=!0);r&&c&&Vs(e),Po(e,a,i,o,l)}function ui(e,s,t,n,a,i){const o=t-e.x[s],r=n-e.y[s],l=o*e.dirX[s]+r*e.dirY[s];if(l<-i||l>i)return!1;const c=o-l*e.dirX[s],d=r-l*e.dirY[s];return c*c+d*d<=a*a}function Fo(e){for(let s=0;s<e.cap;s+=1)if(e.alive[s]===0)return s;return-1}function K(e){return e.catalog.loop.stages[e.stageIndex]}function Tn(e){if(e.portal.open){const t=e.catalog.loop.portalHold;return{kind:"portal",remaining:0,pct:t>0?Math.min(1,e.portal.hold/t):0,targetX:e.portal.x,targetY:e.portal.y,hasTarget:!0,name:""}}if(e.bossSpawned&&e.counts.boss>0){const{enemies:t}=e;for(let n=0;n<t.cap;n+=1){if(t.alive[n]===0||t.role[n]!==j)continue;const a=t.maxHp[n]>0?t.maxHp[n]:1,i=t.defId[n];return{kind:"boss",remaining:0,pct:Math.max(0,t.hp[n]/a),targetX:t.x[n],targetY:t.y[n],hasTarget:!0,name:i?e.catalog.entity(i).name:"Boss"}}}if(e.teleporter.state==="charging"){const t=e.teleporter.hold;return{kind:"hold",remaining:0,pct:t>0?Math.min(1,e.teleporter.charge/t):0,targetX:e.teleporter.x,targetY:e.teleporter.y,hasTarget:!0,name:""}}const s=K(e);return{kind:"wait",remaining:Math.max(0,s.teleporterAt-e.stageTime),pct:s.teleporterAt>0?Math.min(1,e.stageTime/s.teleporterAt):0,targetX:0,targetY:0,hasTarget:!1,name:""}}function Bo(e,s){const t=e.catalog.loop.stages[s];e.stageIndex=s,e.stageTime=0,e.stageGen+=1,e.bossSpawned=!1,e.bossDefeated=!1,e.lastFodderAt=-99,e.lastEliteAt=-99,e.lastSniperAt=-99,e.credits=0,e.teleporter.state="hidden",e.teleporter.charge=0,e.teleporter.hold=t.teleporterHold,e.teleporter.radius=t.teleporterRadius,e.portal.open=!1,e.portal.hold=0,e.portal.x=0,e.portal.y=0,Fu(e),ud(e.gems),fd(e.lores),xd(e.projectiles),Ao(e.obstacles),e.player.x=e.catalog.world.width*.5,e.player.y=e.catalog.world.height*.5,e.player.hp=e.stats.maxHp,e.player.dashRemain=0,e.player.iframeRemain=0,e.player.slowRemain=0,e.player.slowMul=1,e.player.rootRemain=0,e.decoy.active=!1,e.decoy.remain=0,Hd(e.zones),Oo(e.bossHazards),Vo(e.boss),Xd(e),Ed(e)}function Od(e,s){Vd(e),Ud(e,s),zd(e,s),Yd(e),e.player.hp<=0&&!e.won&&(e.phase="defeat")}function Vd(e){const{perSecond:s,stageBonus:t}=e.catalog.loop.difficulty;e.coefficient=1+e.runTime*s+e.stageIndex*(t||0)}function Ud(e,s){const t=K(e);if(e.teleporter.state==="hidden"&&e.stageTime>=t.teleporterAt&&(e.teleporter.state="charging",e.teleporter.charge=0),e.teleporter.state!=="charging")return;Math.hypot(e.player.x-e.teleporter.x,e.player.y-e.teleporter.y)<=e.teleporter.radius&&(e.teleporter.charge+=s),e.teleporter.charge>=e.teleporter.hold&&(e.teleporter.state="done",Wd(e))}function Wd(e){if(e.bossSpawned)return;const s=K(e),t=e.catalog.entity(s.boss),n=Xu(e,e.teleporter.x,e.teleporter.y,t.stats.radius),a=le(e,t,n.x,n.y);a<0||(t.ai.type==="boss"&&Da(e,a,t.ai),e.bossSpawned=!0)}function zd(e,s){if((e.bossDefeated||e.bossSpawned&&e.counts.boss===0)&&!e.portal.open&&!e.won){if(e.stageIndex>=e.catalog.loop.stages.length-1){for(let o=0;o<e.lores.cap;o+=1){if(e.lores.alive[o]===0)continue;const r=e.lores.entityId[o];e.lores.alive[o]=0,e.lores.entityId[o]=null,r&&!e.collectedLores.has(r)&&(e.collectedLores.add(r),e.newlyCollectedLores.push(r))}e.won=!0,e.stagesCleared+=1,e.phase==="play"&&(e.phase="victory");return}e.portal.open=!0,e.portal.hold=0,e.portal.x===0&&e.portal.y===0&&(e.portal.x=e.teleporter.x,e.portal.y=e.teleporter.y)}if(!e.portal.open)return;const{portalRadius:t,portalHold:n}=e.catalog.loop;Math.hypot(e.player.x-e.portal.x,e.player.y-e.portal.y)<=t?(e.portal.hold+=s,e.portal.hold>=n&&(e.stagesCleared+=1,Bo(e,e.stageIndex+1))):e.portal.hold=0}function Xd(e){const s=K(e),t=wo(Mo(s.id)^(e.stageIndex+3)*2654435769^e.stageGen*668265261),n=e.catalog.world,a=s.teleporterRadius+48,i=e.player.x,o=e.player.y;for(let r=0;r<24;r+=1){const l=480+t()*320,c=t()*Math.PI*2,d=V(i+Math.cos(c)*l,a,n.width-a),u=V(o+Math.sin(c)*l,a,n.height-a);if(Math.hypot(d-i,u-o)>=360){e.teleporter.x=d,e.teleporter.y=u;return}}e.teleporter.x=V(i+520,a,n.width-a),e.teleporter.y=V(o,a,n.height-a)}function Yd(e){const{enemies:s}=e;e.focus.kind="none",e.focus.hp=0,e.focus.maxHp=0,e.focus.name="";let t=-1;for(let n=0;n<s.cap;n+=1)if(s.alive[n]!==0){if(s.role[n]===j){e.focus.kind="boss",e.focus.hp=s.hp[n],e.focus.maxHp=s.maxHp[n];const a=s.defId[n];e.focus.name=a?e.catalog.entity(a).name:"Boss";return}t<0&&s.role[n]===O&&(t=n)}if(t>=0){const n=s.defId[t];e.focus.kind="elite",e.focus.hp=s.hp[t],e.focus.maxHp=s.maxHp[t];const a=n?e.catalog.entity(n).name:"Elite";e.focus.name=a.startsWith("Elite ")?a:`Elite ${a}`}}const Kd=2,jd=.35,qd=.65;function Zd(e){for(let s=0;s<Kd;s+=1)Qd(e),Jd(e),e.player.dashRemain<=0&&eu(e),Cd(e),tu(e)}function Qd(e){un(e.hash);const{enemies:s}=e;for(let t=0;t<s.cap;t+=1)s.alive[t]!==0&&Ea(e.hash,s.x[t],s.y[t],t)}function Jd(e){const{enemies:s,hash:t,scratch:n}=e;for(let a=0;a<s.cap;a+=1){if(s.alive[a]===0)continue;const i=Ke(t,s.x[a],s.y[a],s.radius[a]+48,n);for(let o=0;o<i;o+=1){const r=n[o];if(r<=a||s.alive[r]===0||s.corpseRemain[a]>0||s.corpseRemain[r]>0||!Ue(s.x[a],s.y[a],s.radius[a],s.x[r],s.y[r],s.radius[r]))continue;const l=s.role[a]===j,c=s.role[r]===j;let d=.5,u=.5;l&&!c?(d=0,u=1):c&&!l&&(d=1,u=0);const f=Ho(s.x[a],s.y[a],s.radius[a],s.x[r],s.y[r],s.radius[r],d,u);s.x[a]=f.ax,s.y[a]=f.ay,s.x[r]=f.bx,s.y[r]=f.by}}}function eu(e){const{player:s,enemies:t,hash:n,scratch:a}=e,i=Ke(n,s.x,s.y,s.radius+48,a);for(let o=0;o<i;o+=1){const r=a[o];if(t.alive[r]===0||t.corpseRemain[r]>0||!Ue(s.x,s.y,s.radius,t.x[r],t.y[r],t.radius[r]))continue;const l=Ho(s.x,s.y,s.radius,t.x[r],t.y[r],t.radius[r],jd,qd);s.x=l.ax,s.y=l.ay,t.x[r]=l.bx,t.y[r]=l.by}}function tu(e){const s=e.catalog.world,{player:t,enemies:n}=e,a=s.borderInsetX??0,i=s.borderInsetY??0,o=a+t.radius,r=i+t.radius;t.x=V(t.x,o,s.width-o),t.y=V(t.y,r,s.height-r);for(let l=0;l<n.cap;l+=1){if(n.alive[l]===0)continue;const c=a+n.radius[l]+8,d=i+n.radius[l]+8;n.x[l]=V(n.x[l],c,s.width-c),n.y[l]=V(n.y[l],d,s.height-d)}}function Ho(e,s,t,n,a,i,o,r){const l=t+i-Math.abs(e-n),c=t+i-Math.abs(s-a);if(l<=0||c<=0)return{ax:e,ay:s,bx:n,by:a};if(l<c){const u=e>=n?1:-1;return{ax:e+l*o*u,ay:s,bx:n-l*r*u,by:a}}const d=s>=a?1:-1;return{ax:e,ay:s+c*o*d,bx:n,by:a-c*r*d}}const $o=["primary","secondary","utility","special"];function su(e,s){for(const t of $o)e.player.skillCd[t]=Math.max(0,e.player.skillCd[t]-s)}function nu(e,s){for(const t of $o){const n=e.survivor.skills[t];if(!n)continue;const a=e.catalog.skill(n);if(!(!(a.input==="hold"?s.held[t]:s.pressed[t])||e.player.skillCd[t]>0)&&!(t==="utility"&&e.player.dashRemain>0)){for(const o of a.effects)au(e,s,o);e.player.skillCd[t]=a.cooldown*e.stats.cooldownMul}}}function au(e,s,t){switch(t.type){case"projectile":iu(e,t);return;case"dash":lu(e,s,t);return;case"self-slow":Be(e.player,t.mul,t.duration);return;case"delayed-strike":Bd(e.zones,{x:e.aimX,y:e.aimY,radius:t.radius*e.stats.aoeRadiusMul,delay:t.delay,damage:t.damage*e.stats.damageMul});return;case"slow-line":ru(e,t);return;case"tether":ou(e,t);return}}function iu(e,s){const t=wa(e);if(!t)return;const n=e.player.radius+8;let a=0;s.pierce&&(a|=dn),s.flyOver&&(a|=Os);const i=(s.impactRadius??0)*e.stats.aoeRadiusMul;i>0&&(a|=Kt|Os),Ht(e.projectiles,{x:e.player.x+t.x*n,y:e.player.y+t.y*n,dirX:t.x,dirY:t.y,speed:s.speed*e.stats.projSpeedMul,lifetime:s.lifetime,radius:s.radius,damage:s.damage*e.stats.damageMul,team:pt,flags:a,destX:e.aimX,destY:e.aimY,impactRadius:i})}function ou(e,s){const t=wa(e);if(!t)return;const n=e.player.radius+8;Ht(e.projectiles,{x:e.player.x+t.x*n,y:e.player.y+t.y*n,dirX:t.x,dirY:t.y,speed:s.speed*e.stats.projSpeedMul,lifetime:s.lifetime,radius:s.radius,damage:s.fodderDamage*e.stats.damageMul,team:pt,flags:Yt,rootDuration:s.rootDuration*e.stats.controlDurationMul,tetherDps:s.fodderContactDps*e.stats.damageMul})}function ru(e,s){const t=wa(e);if(!t)return;const n=-t.y,a=t.x,i=s.offset??56;Fd(e.zones,{x:e.player.x+t.x*i,y:e.player.y+t.y*i,dirX:n,dirY:a,length:s.length*e.stats.aoeRadiusMul,width:s.width*e.stats.aoeRadiusMul,duration:s.duration*e.stats.controlDurationMul,slowMul:s.slowMul,damage:s.damage*e.stats.damageMul,fodderOnly:s.fodderOnly})}function lu(e,s,t){if(t.duration<=0)return;let n=s.moveX,a=s.moveY;Math.hypot(n,a)<.01&&(n=e.aimX-e.player.x,a=e.aimY-e.player.y);const i=Math.hypot(n,a);if(i<.001)return;const o=t.distance/t.duration;(t.decoyDuration??0)>0&&Nd(e.decoy,e.player.x,e.player.y,(t.decoyDuration??0)*e.stats.controlDurationMul),e.player.dashVx=n/i*o,e.player.dashVy=a/i*o,e.player.dashRemain=t.duration,e.player.iframeRemain=t.iframe,F(e.fx,At,e.player.x,e.player.y,10147071)}function wa(e){const s=e.aimX-e.player.x,t=e.aimY-e.player.y,n=Math.hypot(s,t);return n<=.001?null:{x:s/n,y:t/n}}function cu(e=E.world.defaultSurvivor,s){const t=E.survivor(e),n=t.startingItems.map(u=>({id:u,stacks:1})),a=xo(t.stats,n,E.item),i=E.loop,o=i.maxFodder+i.maxElites+1,r=bu(t.id,a,E.world.width,E.world.height),l=s?.unlockedItems?new Set(s.unlockedItems):new Set(E.items.map(u=>u.id)),c=new Set(s?.collectedLores??[]),d={catalog:E,survivor:t,stats:a,player:r,inventory:n,aimX:r.x+1,aimY:r.y,projectiles:yd(E.world.maxProjectiles),enemies:Nu(o),gems:rd(i.maxGems),lores:ld(Sa),collectedLores:c,newlyCollectedLores:[],unlockedItems:l,obstacles:Sd(kd(E.obstacles.counts,E.obstacles.dynamicHazards),i.hashCell),hash:Ro(i.hashCell),scratch:new Array(o).fill(0),runTime:0,stageTime:0,stageIndex:0,stageGen:0,coefficient:1,credits:0,lastFodderAt:-99,lastEliteAt:-99,counts:{fodder:0,elite:0,boss:0},xp:0,xpNeed:ka(i.xpBase,i.xpGrowth,1),level:1,pendingLevels:0,phase:"play",offer:null,won:!1,bossSpawned:!1,bossDefeated:!1,teleporter:{state:"hidden",x:0,y:0,radius:i.stages[0].teleporterRadius,charge:0,hold:i.stages[0].teleporterHold},portal:{open:!1,x:0,y:0,hold:0},focus:{kind:"none",hp:0,maxHp:0,name:""},fx:zc(),zones:Pd(),boss:Au(),bossHazards:Su(),decoy:Ld(),bossesDefeated:0,lastSniperAt:-99,kills:{fodder:0,elite:0,boss:0,total:0},killsByEntity:{},encountersByEntity:{},damageDealt:0,damageTaken:0,healingDone:0,gemsCollected:0,stagesCleared:0};return Bo(d,0),d}function du(e,s,t){if(e.phase!=="play")return;const n=e.damageTaken;Xc(e.fx),e.aimX=s.aimX,e.aimY=s.aimY,e.runTime+=t,e.stageTime+=t,su(e,t),e.player.iframeRemain=Math.max(0,e.player.iframeRemain-t),nu(e,s),hu(e,s,t),vd(e.projectiles,t),pu(e),Qc(e,t),_u(e,t),fi(e),Zd(e),fi(e),Md(e),gu(e),yu(e),vu(e,t),$d(e,t),Tu(e,t),Rd(e,t),md(e,t),hd(e,t),Od(e,t),e.stats.hpRegen>0&&e.player.hp>0&&_o(e,e.stats.hpRegen*t),e.damageTaken>n&&e.player.hurtCooldown<=0&&(e.player.hurtRemain=.14,e.player.hurtCooldown=.22),e.player.hurtCooldown=Math.max(0,e.player.hurtCooldown-t),e.player.hurtRemain=Math.max(0,e.player.hurtRemain-t)}const uu=.9,fu=.25;function se(e,s,t=!1){if(s<=0||e.player.iframeRemain>0||e.player.hp<=0)return;let n=s*(1-e.stats.armor);t&&(n*=1-e.stats.hazardResist),n=Math.max(0,n);const a=e.player.maxHp*uu;e.player.hp>=a&&e.player.hp-n<1&&(n=Math.max(0,e.player.hp-1),e.player.iframeRemain=Math.max(e.player.iframeRemain,fu)),e.player.hp-=n,e.damageTaken+=n}function _o(e,s){if(s<=0||e.player.hp<=0)return;const t=e.player.hp;e.player.hp=Math.min(e.player.maxHp,e.player.hp+s),e.healingDone+=Math.max(0,e.player.hp-t)}function Vs(e){const s=nd(e.inventory,e.catalog.item);if(!(s<=0))for(const t of["primary","secondary","utility","special"])e.player.skillCd[t]>0&&(e.player.skillCd[t]=Math.max(0,e.player.skillCd[t]-s))}function mu(e){return Math.atan2(e.aimY-e.player.y,e.aimX-e.player.x)}function hu(e,s,t){const{player:n,stats:a}=e,i=e.catalog.world;if(n.dashRemain>0)n.rootRemain=0,n.dashRemain=Math.max(0,n.dashRemain-t),n.x+=n.dashVx*t,n.y+=n.dashVy*t;else if(n.rootRemain<=0){let l=s.moveX,c=s.moveY;const d=Math.hypot(l,c);d>1&&(l/=d,c/=d);const u=a.speed*Do(e);n.x+=l*u*t,n.y+=c*u*t}const o=(i.borderInsetX??0)+n.radius,r=(i.borderInsetY??0)+n.radius;n.x=V(n.x,o,i.width-o),n.y=V(n.y,r,i.height-r)}function fi(e){un(e.hash);const{enemies:s}=e;for(let t=0;t<s.cap;t+=1)s.alive[t]!==0&&Ea(e.hash,s.x[t],s.y[t],t)}function pu(e){const{projectiles:s,enemies:t}=e;for(let n=0;n<s.alive.length;n+=1){if(s.alive[n]===0||(s.flags[n]&Kt)===0)continue;const a=s.destX[n]-s.x[n],i=s.destY[n]-s.y[n];if(s.life[n]>0&&a*a+i*i>64)continue;const o=s.x[n],r=s.y[n],l=s.impactRadius[n],c=Math.random()<e.stats.critChance,d=c?s.damage[n]*e.stats.critMul:s.damage[n];F(e.fx,It,o,r,c?16729122:16755285,l);let u=!1;for(let f=0;f<t.cap;f+=1)t.alive[f]===0||t.corpseRemain[f]>0||q(o,r,l,t.x[f],t.y[f],t.radius[f])&&(ze(e,f,d),u=!0);c&&u&&s.team[n]===pt&&Vs(e),s.team[n]===pt&&Po(e,o,r,l,d),$t(s,n)}}function gu(e){const{projectiles:s,enemies:t,hash:n,scratch:a}=e;for(let i=0;i<s.alive.length;i+=1){if(s.alive[i]===0||s.team[i]!==pt||(s.flags[i]&Os)!==0)continue;const o=(s.flags[i]&dn)!==0,r=(s.flags[i]&Yt)!==0,l=s.radius[i]+48,c=Ke(n,s.x[i],s.y[i],l,a);if(r){let m=-1,h=1/0;const p=[];for(let g=0;g<c;g+=1){const v=a[g];if(t.alive[v]===0||t.corpseRemain[v]>0||!Ue(s.x[i],s.y[i],s.radius[i],t.x[v],t.y[v],t.radius[v])||ci(s,i,v))continue;const y=t.x[v]-s.x[i],b=t.y[v]-s.y[i],x=y*y+b*b;t.role[v]===O||t.role[v]===j?x<h&&(h=x,m=v):p.push(v)}for(const g of p)ds(e,i,g,!1);m>=0&&(ds(e,i,m,!0),$t(s,i));continue}const d=[];let u=-1,f=1/0;for(let m=0;m<c;m+=1){const h=a[m];if(t.alive[h]===0||t.corpseRemain[h]>0||!Ue(s.x[i],s.y[i],s.radius[i],t.x[h],t.y[h],t.radius[h])||o&&ci(s,i,h))continue;const p=t.x[h]-s.x[i],g=t.y[h]-s.y[i],v=p*p+g*g;if(o){d.push(h);continue}v<f&&(f=v,u=h)}if(o){if(d.length===0)continue;for(const m of d)ds(e,i,m,!1);continue}u<0||(ds(e,i,u,!1),$t(s,i))}}function ds(e,s,t,n){const{projectiles:a,enemies:i}=e;bd(a,s,t);const o=Math.random()<e.stats.critChance,r=o?a.damage[s]*e.stats.critMul:a.damage[s];if(n){i.rootRemain[t]=Math.max(i.rootRemain[t],a.rootDuration[s]),i.rootDuration[t]=Math.max(i.rootDuration[t],a.rootDuration[s]),i.tetherDps[t]=a.tetherDps[s],F(e.fx,ba,i.x[t],i.y[t],o?16729122:16225815,i.radius[t]),r>0&&ze(e,t,r),o&&Vs(e);return}F(e.fx,_e,a.x[s],a.y[s],o?16729122:16774344),ze(e,t,r),o&&Vs(e)}function yu(e){const{player:s,projectiles:t}=e;if(!(s.iframeRemain>0))for(let n=0;n<t.alive.length;n+=1)t.alive[n]===0||t.team[n]!==We||Ue(t.x[n],t.y[n],t.radius[n],s.x,s.y,s.radius)&&(F(e.fx,ne,t.x[n],t.y[n],16742970),se(e,t.damage[n]),$t(t,n))}function vu(e,s){const{player:t,enemies:n,hash:a,scratch:i}=e;if(t.iframeRemain>0)return;const o=e.catalog.loop.fodderContactCap;let r=0;const l=Ke(a,t.x,t.y,t.radius+48,i);for(let c=0;c<l;c+=1){const d=i[c];if(n.alive[d]===0||!Ue(t.x,t.y,t.radius,n.x[d],n.y[d],n.radius[d])||n.corpseRemain[d]>0)continue;if(n.attackRemain[d]<=0&&n.attackCd[d]<=0&&(n.attackRemain[d]=Wo,n.attackCd[d]=zo),n.role[d]===pe){if(r>=o)continue;r+=1}const u=n.contactDps[d]*s;se(e,u),Yu(e,d)}}function bu(e,s,t,n){return{defId:e,x:t*.5,y:n*.5,radius:s.radius,hp:s.maxHp,maxHp:s.maxHp,speed:s.speed,skillCd:pd(),dashRemain:0,dashVx:0,dashVy:0,iframeRemain:0,slowRemain:0,slowMul:1,rootRemain:0,hurtRemain:0,hurtCooldown:0}}const Ra=0,Us=1,Ta=2,Aa=3,Ia=4,Go=0,mn=1,xu=2,ku=24;function Su(e=ku){return{cap:e,alive:new Uint8Array(e),kind:new Uint8Array(e),style:new Uint8Array(e),state:new Uint8Array(e),x:new Float32Array(e),y:new Float32Array(e),dirX:new Float32Array(e),dirY:new Float32Array(e),radius:new Float32Array(e),angle:new Float32Array(e),elapsed:new Float32Array(e),duration:new Float32Array(e),damage:new Float32Array(e),slowMul:new Float32Array(e),slowDuration:new Float32Array(e),rootDuration:new Float32Array(e),poolDuration:new Float32Array(e),poolRadius:new Float32Array(e),poolDps:new Float32Array(e),poolSlow:new Float32Array(e)}}function Oo(e){e.alive.fill(0)}function jt(e){for(let s=0;s<e.cap;s+=1)if(e.alive[s]===0)return s;return-1}function Eu(e,s){const t=jt(e);return t<0?-1:(e.alive[t]=1,e.kind[t]=Ra,e.style[t]=s.style,e.state[t]=0,e.x[t]=s.x,e.y[t]=s.y,e.dirX[t]=1,e.dirY[t]=0,e.radius[t]=s.radius,e.angle[t]=0,e.elapsed[t]=0,e.duration[t]=s.delay,e.damage[t]=s.damage,e.slowMul[t]=1,e.slowDuration[t]=0,e.rootDuration[t]=0,e.poolDuration[t]=s.poolDuration??0,e.poolRadius[t]=s.poolRadius??s.radius,e.poolDps[t]=s.poolDps??0,e.poolSlow[t]=s.poolSlow??1,t)}function Cu(e,s){const t=jt(e);return t<0?-1:(e.alive[t]=1,e.kind[t]=Us,e.style[t]=s.style,e.state[t]=0,e.x[t]=s.x,e.y[t]=s.y,e.dirX[t]=1,e.dirY[t]=0,e.radius[t]=s.radius,e.angle[t]=0,e.elapsed[t]=0,e.duration[t]=s.duration,e.damage[t]=s.dps,e.slowMul[t]=s.slowMul,e.slowDuration[t]=.25,e.rootDuration[t]=0,e.poolDuration[t]=0,e.poolRadius[t]=0,e.poolDps[t]=0,e.poolSlow[t]=1,t)}function Mu(e,s){const t=jt(e);return t<0?-1:(e.alive[t]=1,e.kind[t]=Ta,e.style[t]=mn,e.state[t]=0,e.x[t]=s.x,e.y[t]=s.y,e.dirX[t]=1,e.dirY[t]=0,e.radius[t]=s.radius,e.angle[t]=0,e.elapsed[t]=0,e.duration[t]=s.delay,e.damage[t]=s.damage,e.slowMul[t]=1,e.slowDuration[t]=0,e.rootDuration[t]=s.rootDuration,e.poolDuration[t]=0,e.poolRadius[t]=0,e.poolDps[t]=0,e.poolSlow[t]=1,t)}function wu(e,s){const t=jt(e);return t<0?-1:(e.alive[t]=1,e.kind[t]=Aa,e.style[t]=mn,e.state[t]=0,e.x[t]=s.x,e.y[t]=s.y,e.dirX[t]=s.dirX,e.dirY[t]=s.dirY,e.radius[t]=s.range,e.angle[t]=s.angleRad,e.elapsed[t]=0,e.duration[t]=s.windup,e.damage[t]=s.damage,e.slowMul[t]=s.slowMul,e.slowDuration[t]=s.slowDuration,e.rootDuration[t]=0,e.poolDuration[t]=s.lingering,e.poolRadius[t]=0,e.poolDps[t]=0,e.poolSlow[t]=1,t)}function Ru(e,s){const t=jt(e);return t<0?-1:(e.alive[t]=1,e.kind[t]=Ia,e.style[t]=xu,e.state[t]=0,e.x[t]=s.x,e.y[t]=s.y,e.dirX[t]=1,e.dirY[t]=0,e.radius[t]=s.radius,e.angle[t]=0,e.elapsed[t]=0,e.duration[t]=s.windup,e.damage[t]=s.damage,e.slowMul[t]=s.slowMul,e.slowDuration[t]=s.slowDuration,e.rootDuration[t]=0,e.poolDuration[t]=.45,e.poolRadius[t]=0,e.poolDps[t]=0,e.poolSlow[t]=1,t)}function Tu(e,s){const{bossHazards:t,player:n}=e;if(e.bossDefeated||e.bossSpawned&&e.counts.boss===0){Oo(t);return}for(let i=0;i<t.cap;i+=1){if(t.alive[i]===0)continue;t.elapsed[i]+=s;const o=t.kind[i];if(o===Ra){if(t.elapsed[i]>=t.duration[i]){const r=t.x[i],l=t.y[i],c=t.radius[i],d=t.style[i]===Go?16742970:8049919;F(e.fx,Oe,r,l,d),n.iframeRemain<=0&&q(r,l,c,n.x,n.y,n.radius)&&(F(e.fx,ne,n.x,n.y,d),se(e,t.damage[i])),t.poolDuration[i]>0?(t.kind[i]=Us,t.state[i]=0,t.radius[i]=t.poolRadius[i],t.elapsed[i]=0,t.duration[i]=t.poolDuration[i],t.damage[i]=t.poolDps[i],t.slowMul[i]=t.poolSlow[i]):t.alive[i]=0}continue}if(o===Us){if(n.iframeRemain<=0&&n.dashRemain<=0&&q(t.x[i],t.y[i],t.radius[i],n.x,n.y,n.radius)){const r=t.damage[i]*s;se(e,r,!0);const l=1-(1-t.slowMul[i])*(1-e.stats.hazardResist);Be(n,l,.25)}t.elapsed[i]>=t.duration[i]&&(t.alive[i]=0);continue}if(o===Ta){if(t.state[i]===0){if(t.elapsed[i]>=t.duration[i]){const r=t.x[i],l=t.y[i],c=t.radius[i];F(e.fx,Oe,r,l,8974079),n.iframeRemain<=0&&q(r,l,c,n.x,n.y,n.radius)&&(F(e.fx,ne,n.x,n.y,5627391),se(e,t.damage[i]),Yc(n,t.rootDuration[i])),t.state[i]=1,t.elapsed[i]=0,t.duration[i]=.45}}else t.elapsed[i]>=t.duration[i]&&(t.alive[i]=0);continue}if(o===Aa){t.state[i]===0?t.elapsed[i]>=t.duration[i]&&(n.iframeRemain<=0&&mi(n.x,n.y,n.radius,t.x[i],t.y[i],t.dirX[i],t.dirY[i],t.radius[i],t.angle[i])&&(F(e.fx,ne,n.x,n.y,8049919),se(e,t.damage[i]),Be(n,t.slowMul[i],t.slowDuration[i])),t.state[i]=1,t.elapsed[i]=0,t.duration[i]=Math.max(.25,t.poolDuration[i])):(n.iframeRemain<=0&&mi(n.x,n.y,n.radius,t.x[i],t.y[i],t.dirX[i],t.dirY[i],t.radius[i],t.angle[i])&&Be(n,t.slowMul[i],.35),t.elapsed[i]>=t.duration[i]&&(t.alive[i]=0));continue}if(o===Ia)if(t.state[i]===0){const r=e.boss.enemyIndex;if(r>=0&&e.enemies.alive[r]!==0&&(t.x[i]=e.enemies.x[r],t.y[i]=e.enemies.y[r]),t.elapsed[i]>=t.duration[i]){const l=t.x[i],c=t.y[i],d=t.radius[i];F(e.fx,Oe,l,c,6741503);const u=Math.hypot(n.x-l,n.y-c);n.iframeRemain<=0&&u<=d+n.radius&&!Ko(e,l,c,n.x,n.y)&&(F(e.fx,ne,n.x,n.y,5627391),se(e,t.damage[i]),Be(n,t.slowMul[i],t.slowDuration[i])),t.state[i]=1,t.elapsed[i]=0,t.duration[i]=t.poolDuration[i]}}else t.elapsed[i]>=t.duration[i]&&(t.alive[i]=0)}}function mi(e,s,t,n,a,i,o,r,l){const c=e-n,d=s-a,u=Math.hypot(c,d);if(u>r+t)return!1;if(u<=t+12)return!0;const f=Math.cos(l*.5);return(c*i+d*o)/u>=f}const Ws=8;function Au(){return{enemyIndex:-1,cooldowns:new Float32Array(Ws),activeAttack:-1,phase:"none",elapsed:0,duration:0,aimX:0,aimY:0,laserEndX:0,laserEndY:0,trailTimer:0,enraged:!1,counts:{bolt:0,fan:0,meteor:0,cone:0,prison:0,pulse:0,laser:0,summon:0}}}function Vo(e){e.enemyIndex=-1,e.cooldowns.fill(0),e.activeAttack=-1,e.phase="none",e.elapsed=0,e.duration=0,e.aimX=0,e.aimY=0,e.laserEndX=0,e.laserEndY=0,e.trailTimer=0,e.enraged=!1}function Da(e,s,t){const{boss:n}=e;Vo(n),n.enemyIndex=s;for(let a=0;a<t.attacks.length&&a<Ws;a+=1){const i=t.attacks[a];i.type==="bolt"||i.type==="fan"?n.cooldowns[a]=.8:i.type==="summon"?n.cooldowns[a]=2.4+a*.6:n.cooldowns[a]=1.6+a*1.1}}function Iu(e){switch(e){case"bolt":return"attack-bolt";case"fan":return"attack-fan";case"meteor":return"attack-meteor";case"cone":return"attack-sweep";case"prison":return"attack-prison";case"pulse":return"attack-pulse";case"laser":return"attack-laser";case"summon":return"summon"}}function Du(e,s,t,n,a,i,o,r){const{enemies:l,boss:c,player:d}=e;if(c.enemyIndex!==s&&Da(e,s,t),t.enrage&&!c.enraged&&l.maxHp[s]>0&&l.hp[s]/l.maxHp[s]<=t.enrage.hpPct){c.enraged=!0;for(let u=0;u<t.attacks.length;u+=1)c.cooldowns[u]*=t.enrage.cooldownMul;F(e.fx,we,l.x[s],l.y[s],16733491)}for(let u=0;u<t.attacks.length&&u<Ws;u+=1)c.cooldowns[u]>0&&(c.cooldowns[u]=Math.max(0,c.cooldowns[u]-o));if(c.phase==="windup"){c.elapsed+=o;const u=t.attacks[c.activeAttack];if(!u){c.phase="none",c.activeAttack=-1,l.windup[s]=0;return}if(u.type==="bolt"||u.type==="laser"){const f=Math.min(1,o*8);c.aimX+=(d.x-c.aimX)*f,c.aimY+=(d.y-c.aimY)*f,l.aimX[s]=c.aimX,l.aimY[s]=c.aimY;const m=sa(e,l.x[s],l.y[s],c.aimX,c.aimY);c.laserEndX=m.x,c.laserEndY=m.y}l.windup[s]=Math.max(.01,c.duration-c.elapsed),c.elapsed>=c.duration&&Lu(e,s,u);return}if(c.phase==="channel"){c.elapsed+=o;const u=t.attacks[c.activeAttack];if(!u||u.type!=="laser"){c.phase="none",c.activeAttack=-1,l.windup[s]=0;return}l.windup[s]=Math.max(.01,c.duration-c.elapsed);const f=d.x-c.aimX,m=d.y-c.aimY,h=Math.hypot(f,m);if(h>.001){const k=Math.min(h,u.trackSpeed*o);c.aimX+=f/h*k,c.aimY+=m/h*k}const p=e.catalog.world,g=40;c.aimX=V(c.aimX,g,p.width-g),c.aimY=V(c.aimY,g,p.height-g),l.aimX[s]=c.aimX,l.aimY[s]=c.aimY;const v=sa(e,l.x[s],l.y[s],c.aimX,c.aimY);c.laserEndX=v.x,c.laserEndY=v.y;const y=Math.hypot(d.x-v.x,d.y-v.y),b=Wc(d.x,d.y,l.x[s],l.y[s],v.x,v.y),x=u.hitRadius+d.radius;if(d.iframeRemain<=0&&(y<=x||b<=u.hitRadius*.75+d.radius)){const k=u.dps*e.coefficient*o;se(e,k)}c.trailTimer+=o,c.trailTimer>=u.trailInterval&&(c.trailTimer-=u.trailInterval,Cu(e.bossHazards,{x:v.x,y:v.y,radius:u.trailPool.radius,duration:u.trailPool.duration,dps:u.trailPool.dps*e.coefficient,slowMul:u.trailPool.slowMul,style:mn})),c.elapsed>=c.duration&&(c.phase="none",c.activeAttack=-1,l.windup[s]=0,l.animName[s]=null);return}if(i>.001){const u=n/i,f=a/i;let m=0,h=0;i>t.keep+70?(m=u*r*o,h=f*r*o):i<t.keep-50?(m=-u*r*.75*o,h=-f*r*.75*o):(m=-f*r*.45*o,h=u*r*.45*o),l.x[s]+=m,l.y[s]+=h}for(let u=0;u<t.attacks.length&&u<Ws;u+=1){if(c.cooldowns[u]>0)continue;const f=t.attacks[u];if(f.type==="summon"&&(e.counts.fodder>=e.catalog.loop.maxFodder||Uo(e,f.entity)>=f.maxAlive)){c.cooldowns[u]=1.5;continue}if(!(f.type==="cone"&&i>f.range*1.15)){Pu(e,s,t,u,f);break}}}function Pu(e,s,t,n,a){const{enemies:i,boss:o,player:r}=e,l=o.enraged&&t.enrage?t.enrage.cooldownMul:1;o.cooldowns[n]=a.cooldown*l,o.activeAttack=n,o.phase="windup",o.elapsed=0,o.duration=Math.max(.1,a.windup??.35),o.aimX=r.x,o.aimY=r.y,o.laserEndX=r.x,o.laserEndY=r.y,i.aimX[s]=r.x,i.aimY[s]=r.y,i.windup[s]=o.duration,i.animName[s]=a.anim??Iu(a.type);const c=i.x[s],d=i.y[s],u=r.x-c,f=r.y-d,m=Math.hypot(u,f)||1,h=u/m,p=f/m;if(a.type==="meteor"){const g=i.defId[s]==="cinder-heart";Eu(e.bossHazards,{x:r.x,y:r.y,radius:a.radius,delay:a.delay,damage:a.damage*e.coefficient,style:g?Go:mn,poolDuration:a.pool?.duration??0,poolRadius:a.pool?.radius??a.radius,poolDps:(a.pool?.dps??0)*e.coefficient,poolSlow:a.pool?.slowMul??1}),o.counts.meteor+=1}else a.type==="prison"?(Mu(e.bossHazards,{x:r.x,y:r.y,radius:a.radius,delay:a.delay,damage:a.damage*e.coefficient,rootDuration:a.rootDuration}),o.counts.prison+=1):a.type==="cone"?(wu(e.bossHazards,{x:c,y:d,dirX:h,dirY:p,range:a.range,angleRad:a.angle*Math.PI/180,windup:o.duration,lingering:a.lingering,damage:a.damage*e.coefficient,slowMul:a.slowMul,slowDuration:a.slowDuration}),o.counts.cone+=1):a.type==="pulse"&&(Ru(e.bossHazards,{x:c,y:d,radius:a.radius,windup:o.duration,damage:a.damage*e.coefficient,slowMul:a.slowMul,slowDuration:a.slowDuration}),o.counts.pulse+=1)}function Lu(e,s,t){const{enemies:n,boss:a}=e,i=n.x[s],o=n.y[s],r=a.aimX-i,l=a.aimY-o,c=Math.atan2(l,r),d=n.radius[s]+10,u=n.defId[s]==="cinder-heart"?16742970:8049919;if(t.type==="bolt"){const f=Math.cos(c),m=Math.sin(c),h=i+f*d,p=o+m*d;Ht(e.projectiles,{x:h,y:p,dirX:f,dirY:m,speed:t.projectile.speed,lifetime:t.projectile.lifetime,radius:t.projectile.radius,damage:t.projectile.damage*e.coefficient,team:We}),F(e.fx,Ge,h,p,u),a.counts.bolt+=1}else if(t.type==="fan"){const f=t.spread*Math.PI/180,m=Math.max(1,t.count);for(let h=0;h<m;h+=1){const p=m===1?0:h/(m-1)-.5,g=c+p*f,v=Math.cos(g),y=Math.sin(g),b=i+v*d,x=o+y*d;Ht(e.projectiles,{x:b,y:x,dirX:v,dirY:y,speed:t.projectile.speed,lifetime:t.projectile.lifetime,radius:t.projectile.radius,damage:t.projectile.damage*e.coefficient,team:We})}F(e.fx,Ge,i+Math.cos(c)*d,o+Math.sin(c)*d,u),a.counts.fan+=1}else if(t.type==="summon"){const f=Uo(e,t.entity),m=Math.max(0,Math.min(t.count,t.maxAlive-f)),h=e.catalog.entity(t.entity),p=e.catalog.world,g=h.stats.radius+24,v=n.radius[s]+h.stats.radius+28;for(let y=0;y<m;y+=1){const b=y/Math.max(1,m)*Math.PI*2+e.runTime*1.7,x=V(i+Math.cos(b)*v,g,p.width-g),k=V(o+Math.sin(b)*v,g,p.height-g);le(e,h,x,k)>=0&&F(e.fx,Ge,x,k,u)}a.counts.summon+=1}else if(t.type==="laser"){a.phase="channel",a.elapsed=0,a.duration=t.duration,a.trailTimer=0,n.windup[s]=t.duration,a.counts.laser+=1;const f=Math.cos(c),m=Math.sin(c);a.aimX=i+f*d,a.aimY=o+m*d;const h=sa(e,i,o,a.aimX,a.aimY);a.laserEndX=h.x,a.laserEndY=h.y;return}a.phase="none",a.activeAttack=-1,n.windup[s]=0,n.attackRemain[s]=.25}function Uo(e,s){const{enemies:t}=e;let n=0;for(let a=0;a<t.cap;a+=1)t.alive[a]!==0&&t.defId[a]===s&&(n+=1);return n}function sa(e,s,t,n,a){const{obstacles:i}=e,o=n-s,r=a-t,l=Math.hypot(o,r);if(l<.001)return{x:n,y:a};const c=o/l,d=r/l;let u=l;for(let f=0;f<i.cap;f+=1){if(i.alive[f]===0)continue;const m=i.items[f];if(m.type!=="pillar")continue;const h=m.x-s,p=m.y-t,g=h*c+p*d;if(g<=0||g>=u)continue;const v=h*h+p*p-g*g,y=m.radius*m.radius;if(v<=y){const b=Math.max(0,g-Math.sqrt(y-v));b<u&&(u=b)}}return{x:s+c*u,y:t+d*u}}const pe=0,O=1,j=2,Wo=.35,zo=.8;function Nu(e){return{cap:e,alive:new Uint8Array(e),role:new Uint8Array(e),x:new Float32Array(e),y:new Float32Array(e),facing:new Int8Array(e).fill(1),radius:new Float32Array(e),hp:new Float32Array(e),maxHp:new Float32Array(e),speed:new Float32Array(e),contactDps:new Float32Array(e),xp:new Float32Array(e),credits:new Float32Array(e),attackCd:new Float32Array(e),windup:new Float32Array(e),aimX:new Float32Array(e),aimY:new Float32Array(e),slowRemain:new Float32Array(e),slowMul:new Float32Array(e),shielder:new Uint8Array(e),noxious:new Uint8Array(e),corpseRemain:new Float32Array(e),rootRemain:new Float32Array(e),rootDuration:new Float32Array(e),tetherDps:new Float32Array(e),attackRemain:new Float32Array(e),shieldHp:new Float32Array(e),shieldDelayRemain:new Float32Array(e),hurtRemain:new Float32Array(e),defId:new Array(e).fill(null),animName:new Array(e).fill(null)}}function Fu(e){e.enemies.alive.fill(0),e.enemies.facing.fill(1),e.counts.fodder=0,e.counts.elite=0,e.counts.boss=0}function le(e,s,t,n,a=!1,i){if(e.bossDefeated)return-1;const o=s.role==="boss"?j:a?O:pe;if(o===pe&&e.counts.fodder>=e.catalog.loop.maxFodder||o===O&&e.counts.elite>=e.catalog.loop.maxElites||o===j&&e.counts.boss>=1)return-1;const{enemies:r}=e;for(let l=0;l<r.cap;l+=1){if(r.alive[l]!==0)continue;const c=e.coefficient,d=1+e.catalog.loop.difficulty.speedPerCoeff*(c-1),u=e.catalog.loop.elite,f=o===O?u.hpMul:1,m=o===O?u.damageMul:1,h=o===O?u.xpMul:1,p=o===O?u.creditsMul:1,g=o===O?u.radiusMul:1,v=s.stats.maxHp*c*f;return r.alive[l]=1,r.role[l]=o,r.x[l]=t,r.y[l]=n,r.facing[l]=e.player.x<t?-1:1,r.radius[l]=s.stats.radius*g,r.hp[l]=v,r.maxHp[l]=v,r.speed[l]=s.stats.speed*d,r.contactDps[l]=s.contact.dps*c*m,r.xp[l]=s.rewards.xp*h,r.credits[l]=s.rewards.credits*p,r.attackCd[l]=s.ai.type==="chase"||s.ai.type==="boss"?0:s.ai.cooldown*Math.random(),r.windup[l]=0,r.aimX[l]=t,r.aimY[l]=n,r.slowRemain[l]=0,r.slowMul[l]=1,o===O?(i??(Math.random()<.5?"shielder":"noxious"))==="shielder"?(r.shielder[l]=1,r.noxious[l]=0,r.shieldHp[l]=v*e.catalog.loop.shielder.percentHp,r.shieldDelayRemain[l]=0):(r.shielder[l]=0,r.noxious[l]=1,r.shieldHp[l]=0,r.shieldDelayRemain[l]=0):(r.shielder[l]=0,r.noxious[l]=0,r.shieldHp[l]=0,r.shieldDelayRemain[l]=0),r.corpseRemain[l]=0,r.rootRemain[l]=0,r.rootDuration[l]=0,r.tetherDps[l]=0,r.attackRemain[l]=0,r.animName[l]=null,r.defId[l]=s.id,e.encountersByEntity[s.id]=(e.encountersByEntity[s.id]??0)+1,o===pe?e.counts.fodder+=1:o===O?e.counts.elite+=1:e.counts.boss+=1,l}return-1}function Bu(e,s){const{spawnMin:t,spawnMax:n,spawnSafeRadius:a}=e.catalog.loop.director,i=e.catalog.world,{x:o,y:r}=e.player,l=(i.borderInsetX??0)+s+8,c=(i.borderInsetY??0)+s+8,d=a??t,u=Math.max(t,d),f=Math.max(0,n-u);for(let m=0;m<24;m+=1){const h=u+Math.random()*f,p=Math.random()*Math.PI*2,g=o+Math.cos(p)*h,v=r+Math.sin(p)*h;if(!(g<l||g>i.width-l||v<c||v>i.height-c))return{x:g,y:v}}for(let m=0;m<24;m+=1){const h=l+Math.random()*(i.width-2*l),p=c+Math.random()*(i.height-2*c);if(Math.hypot(h-o,p-r)>=d)return{x:h,y:p}}return null}function hi(e,s,t,n=!1,a){if(t<=0)return 0;const i=s.stats.radius*(n?e.catalog.loop.elite.radiusMul:1),o=Bu(e,i);if(!o)return 0;const{groupSpreadRadius:r}=e.catalog.loop.director,l=e.catalog.world,c=(l.borderInsetX??0)+i+8,d=(l.borderInsetY??0)+i+8;let u=0;for(let f=0;f<t;f+=1){let m=o.x,h=o.y;if(f>0){const g=Math.random()*Math.PI*2,v=Math.random()*r;m=V(o.x+Math.cos(g)*v,c,l.width-c),h=V(o.y+Math.sin(g)*v,d,l.height-d)}if(le(e,s,m,h,n,a)>=0)u+=1;else break}return u}function Hu(e,s){const{enemies:t}=e;if(t.alive[s]!==0&&!(t.corpseRemain[s]>0)){if(t.noxious[s]!==0){t.corpseRemain[s]=e.catalog.loop.noxious.corpseDelay,t.hp[s]=0,t.speed[s]=0,t.windup[s]=0;return}Xo(e,s)}}function Xo(e,s){const{enemies:t}=e;if(t.alive[s]===0)return;const n=t.role[s],a=t.defId[s],i=t.x[s],o=t.y[s],r=t.xp[s];e.credits+=t.credits[s];const l=sd(e.inventory,e.catalog.item);if(l>0&&_o(e,l),F(e.fx,we,i,o,16765786),t.alive[s]=0,e.kills.total+=1,a&&(e.killsByEntity[a]=(e.killsByEntity[a]??0)+1),n===pe?(e.counts.fodder-=1,e.kills.fodder+=1):n===O?(e.counts.elite-=1,e.kills.elite+=1):n===j&&(e.counts.boss-=1,e.kills.boss+=1,e.bossesDefeated+=1,e.bossDefeated=!0,e.portal.x=i,e.portal.y=o),cd(e.gems,i,o,r)||ko(e,r*e.stats.xpMul),a&&!e.collectedLores.has(a)&&!Co(e.lores,a)){const c=n===j?"boss":n===O?"elite":"fodder",d=e.catalog.loop.loreDropChance[c]??0;d>0&&Math.random()<d&&dd(e.lores,i,o,a)}}function $u(e){const{enemies:s}=e;let t=0;for(let n=0;n<s.cap;n+=1){if(s.alive[n]===0)continue;const a=s.defId[n];a&&e.catalog.entity(a).ai.type==="sniper"&&(t+=1)}return t}function _u(e,s){const{enemies:t}=e,n=e.catalog.world,a=e.catalog.loop.shielder;for(let i=0;i<t.cap;i+=1){if(t.alive[i]===0)continue;if(t.hurtRemain[i]=Math.max(0,t.hurtRemain[i]-s),qc(t,i,s),t.role[i]===O&&t.shielder[i]!==0&&t.shieldDelayRemain[i]>0&&(t.shieldDelayRemain[i]-=s,t.shieldDelayRemain[i]<=0&&(t.shieldHp[i]=t.maxHp[i]*a.percentHp)),t.rootRemain[i]>0&&(t.rootRemain[i]=Math.max(0,t.rootRemain[i]-s),t.rootRemain[i]<=0&&(t.tetherDps[i]=0)),t.corpseRemain[i]>0){t.corpseRemain[i]-=s,t.corpseRemain[i]<=0&&Uu(e,i);continue}t.attackRemain[i]>0&&(t.attackRemain[i]=Math.max(0,t.attackRemain[i]-s)),t.attackCd[i]>0&&(t.attackCd[i]=Math.max(0,t.attackCd[i]-s));const o=t.defId[i],r=o?e.catalog.entity(o).ai:{type:"chase"},l=na(e,i),c=l.x-t.x[i],d=l.y-t.y[i],u=Math.hypot(c,d),m=t.rootRemain[i]>0?0:t.speed[i]*jo(e,i),h=t.x[i];if(r.type==="ranged")Gu(e,i,r,c,d,u,s,m);else if(r.type==="sniper")Ou(e,i,r,c,d,u,s,m);else if(r.type==="boss")Du(e,i,r,c,d,u,s,m);else{if(u>.001){const k=c/u*m*s,C=d/u*m*s,M=Pa(e,t.x[i],t.y[i],t.radius[i],k,C,l.x,l.y);t.x[i]+=M.x,t.y[i]+=M.y}const x=e.decoy.active&&t.role[i]===pe?14:e.player.radius;u<=t.radius[i]+x+6&&t.attackRemain[i]<=0&&t.attackCd[i]<=0&&(t.attackRemain[i]=Wo,t.attackCd[i]=zo,t.animName[i]=r.anim??"attack")}const p=n.borderInsetX??0,g=n.borderInsetY??0,v=p+t.radius[i]+8,y=g+t.radius[i]+8;t.x[i]=V(t.x[i],v,n.width-v),t.y[i]=V(t.y[i],y,n.height-y);const b=t.x[i]-h;if(t.windup[i]>0){const x=t.aimX[i]-t.x[i];x<-.001?t.facing[i]=-1:x>.001&&(t.facing[i]=1)}else if(b<-.001)t.facing[i]=-1;else if(b>.001)t.facing[i]=1;else if(t.attackRemain[i]>0){const x=l.x-t.x[i];x<-.001?t.facing[i]=-1:x>.001&&(t.facing[i]=1)}}Wu(e,s)}function na(e,s){return e.enemies.role[s]===pe&&e.decoy.active?{x:e.decoy.x,y:e.decoy.y}:{x:e.player.x,y:e.player.y}}function Gu(e,s,t,n,a,i,o,r){const{enemies:l}=e;if(l.windup[s]>0){l.windup[s]-=o,l.windup[s]<=0&&(zu(e,s,t),l.attackCd[s]=t.cooldown,l.windup[s]=0);return}if(i<=t.range&&l.attackCd[s]<=0){l.windup[s]=t.windup,l.aimX[s]=e.player.x,l.aimY[s]=e.player.y,l.animName[s]=t.anim??"attack";return}if(i>.001){const c=n/i,d=a/i;let u=0,f=0;i>t.range?(u=c*r*o,f=d*r*o):i<t.keep?(u=-c*r*o,f=-d*r*o):(u=-d*r*.45*o,f=c*r*.45*o);const m=Pa(e,l.x[s],l.y[s],l.radius[s],u,f,e.player.x,e.player.y);l.x[s]+=m.x,l.y[s]+=m.y}}function Ou(e,s,t,n,a,i,o,r){const{enemies:l}=e;if(i>.001){const c=n/i,d=a/i;let u=0,f=0;i<t.keep?(u=-c*r*o,f=-d*r*o):(u=-d*r*.25*o,f=c*r*.25*o);const m=Pa(e,l.x[s],l.y[s],l.radius[s],u,f,e.player.x,e.player.y);l.x[s]+=m.x,l.y[s]+=m.y}if(l.windup[s]>0){l.windup[s]-=o,l.windup[s]<=0&&(Vu(e,s,t),l.attackCd[s]=t.cooldown,l.windup[s]=0);return}l.attackCd[s]<=0&&(l.windup[s]=t.windup,l.aimX[s]=e.player.x,l.aimY[s]=e.player.y,l.animName[s]=t.anim??"attack")}function Vu(e,s,t){const{enemies:n,player:a}=e,i=n.x[s],o=n.y[s],r=n.aimX[s],l=n.aimY[s];if(a.iframeRemain>0||Ko(e,i,o,a.x,a.y)||qo(a.x,a.y,i,o,r,l)>t.lineWidth+a.radius)return;F(e.fx,ne,a.x,a.y,16724821);const d=n.role[s]===O?e.catalog.loop.elite.damageMul:1,u=t.damage*e.coefficient*d;se(e,u)}function Pa(e,s,t,n,a,i,o,r){const{obstacles:l}=e,c=Math.hypot(a,i);if(c<1e-4)return{x:a,y:i};let d=a,u=i;for(let f=0;f<l.cap;f+=1){if(l.alive[f]===0)continue;const m=l.items[f];if(m.type==="hazard")continue;const h=m.radius+n+10,p=s-m.x,g=t-m.y,v=p*p+g*g;if(v>h*h)continue;const y=Math.sqrt(v),b=y>1e-4?p/y:1,x=y>1e-4?g/y:0,k=d*b+u*x;if(k<0){d-=k*b,u-=k*x;const C=Math.hypot(d,u);if(C>1e-4)d=d/C*c,u=u/C*c;else{const w=(o-m.x)*x-(r-m.y)*b>=0?1:-1;d=-x*w*c,u=b*w*c}}}return{x:d,y:u}}const Yo=8;function Ko(e,s,t,n,a){const{obstacles:i}=e;for(let o=0;o<i.cap;o+=1){if(i.alive[o]===0)continue;const r=i.items[o];if(r.type==="pillar"&&Zo(s,t,n,a,r.x,r.y,r.radius+Yo))return!0}return!1}function Uu(e,s){const{enemies:t,player:n}=e,a=e.catalog.loop.noxious,i=t.x[s],o=t.y[s];if(F(e.fx,we,i,o,6750088),n.iframeRemain<=0&&q(i,o,a.popRadius,n.x,n.y,n.radius)){F(e.fx,ne,n.x,n.y,16724821);const r=a.popDamage*e.coefficient;se(e,r,!0)}wd(e,i,o),Xo(e,s)}function Wu(e,s){const{enemies:t,player:n}=e;for(let a=0;a<t.cap;a+=1){if(t.alive[a]===0||t.rootRemain[a]<=0||t.tetherDps[a]<=0||t.role[a]!==O&&t.role[a]!==j)continue;const i=t.x[a],o=t.y[a],r=t.radius[a]+8;for(let l=0;l<t.cap;l+=1){if(l===a||t.alive[l]===0||t.role[l]!==pe)continue;const c=t.x[l],d=t.y[l],u=t.radius[l],f=q(i,o,r,c,d,u),m=!f&&Zo(n.x,n.y,i,o,c,d,u+12);!f&&!m||ze(e,l,t.tetherDps[a]*s)}}}function ze(e,s,t){const{enemies:n}=e;if(n.alive[s]===0||t<=0)return;n.hurtRemain[s]=.12;let a=t;if((n.role[s]===O||n.role[s]===j)&&(a*=e.stats.eliteDamageMul),n.role[s]===O&&n.shielder[s]!==0&&(n.shieldDelayRemain[s]=e.catalog.loop.shielder.delay,n.shieldHp[s]>0))if(a<=n.shieldHp[s]){n.shieldHp[s]-=a,e.damageDealt+=a;return}else e.damageDealt+=n.shieldHp[s],a-=n.shieldHp[s],n.shieldHp[s]=0;const i=Math.min(Math.max(0,n.hp[s]),a);e.damageDealt+=i,n.hp[s]-=a,n.hp[s]<=0&&Hu(e,s)}function jo(e,s){const t=e.catalog.obstacles;let n=e.enemies.slowMul[s];const{enemies:a,obstacles:i}=e;for(let o=0;o<i.cap;o+=1){if(i.alive[o]===0)continue;const r=i.items[o];if(r.type==="hazard"&&q(a.x[s],a.y[s],a.radius[s],r.x,r.y,r.radius)){n*=t.hazard.enemySpeedMul;break}}return n}function An(e,s){const{enemies:t}=e;if(t.alive[s]===0||t.corpseRemain[s]>0||t.rootRemain[s]>0)return 0;const n=t.speed[s]*jo(e,s),a=t.defId[s];if(!a)return n;const i=e.catalog.entity(a).ai;if(i.type==="boss"){if(t.windup[s]>0)return 0;const o=na(e,s),r=Math.hypot(o.x-t.x[s],o.y-t.y[s]);return r<=i.keep+70&&r>=i.keep-50?n*.45:n}if(i.type==="ranged"||i.type==="sniper"){if(Pt(e,s))return 0;const o=na(e,s),r=Math.hypot(o.x-t.x[s],o.y-t.y[s]);if(i.type==="ranged"&&r<=i.range&&r>=i.keep)return n*.45;if(i.type==="sniper"&&r>=i.keep)return n*.25}return n}function zu(e,s,t){const{enemies:n,player:a}=e,i=a.x-n.x[s],o=a.y-n.y[s],r=Math.hypot(i,o);if(r<=.001)return;const l=i/r,c=o/r,d=n.radius[s]+8,u=n.x[s]+l*d,f=n.y[s]+c*d,m=n.role[s]===O?e.catalog.loop.elite.damageMul:1;Ht(e.projectiles,{x:u,y:f,dirX:l,dirY:c,speed:t.projectile.speed,lifetime:t.projectile.lifetime,radius:t.projectile.radius,damage:t.projectile.damage*e.coefficient*m,team:We}),F(e.fx,Ge,u,f,16742970)}function Xu(e,s,t,n){const{spawnMin:a,spawnMax:i}=e.catalog.loop.director,o=e.catalog.world,r=n+8;for(let l=0;l<10;l+=1){const c=a+Math.random()*(i-a),d=Math.random()*Math.PI*2,u=V(s+Math.cos(d)*c,r,o.width-r),f=V(t+Math.sin(d)*c,r,o.height-r);if(Math.hypot(u-s,f-t)>=a*.7)return{x:u,y:f}}return{x:V(s+a,r,o.width-r),y:V(t,r,o.height-r)}}function qo(e,s,t,n,a,i){const o=a-t,r=i-n,l=o*o+r*r;if(l<1e-4)return Math.hypot(e-t,s-n);let c=((e-t)*o+(s-n)*r)/l;return c=Math.max(0,Math.min(1,c)),Math.hypot(e-(t+c*o),s-(n+c*r))}function Zo(e,s,t,n,a,i,o){return qo(a,i,e,s,t,n)<=o}function Yu(e,s){if(e.enemies.noxious[s]===0)return;const t=e.catalog.loop.noxious;Be(e.player,t.contactSlowMul,t.contactSlowDuration)}function Pt(e,s){const{enemies:t}=e;return t.attackRemain[s]>0||t.windup[s]>0}function In(e,s){return e.enemies.animName[s]??"attack"}const Ku=["goat-hoof","glass-cannon","calcined-lens"],pi=10,ju=90;let gi=-1,yi=-1;function qu(){return Ku.map(e=>E.item(e))}function Zu(e,s){if(!(s==="hall"||s==="archives"||s==="banner")){if(ef(e),s==="boss"){sf(e);return}tf(e),s==="tablets"&&(e.phase="levelup",e.offer=qu(),e.pendingLevels=1)}}function Qu(e,s,t){const n=vt();if(n!=="circle"&&n!=="boss"||e.phase!=="play")return;e.player.hp<e.player.maxHp*.4&&(e.player.hp=e.player.maxHp*.75);const a=e.teleporter,i=t*.85;let o=-Math.sin(i),r=Math.cos(i);const l=e.player.x-a.x,c=e.player.y-a.y,d=Math.hypot(l,c);d>ju&&(o+=-l/d*1.6,r+=-c/d*1.6);const u=Math.hypot(o,r)||1;s.moveX=o/u,s.moveY=r/u,nf(e,s),s.held.primary=!0,s.held.secondary=!1,s.held.utility=!1,s.held.special=!1,s.pressed.primary=!1,s.pressed.secondary=!1,s.pressed.utility=!1,s.pressed.special=!1;const f=Math.floor(t/1.55);f!==gi&&(gi=f,s.pressed.utility=!0);const m=Math.floor((t+.8)/4.1);m!==yi&&(yi=m,s.pressed.secondary=!0)}function Ju(){const e=document.getElementById("promo-title");e&&(e.classList.remove("hidden"),e.setAttribute("aria-hidden","false"))}function ef(e){const s=e.catalog.loop;e.runTime=268,e.stageTime=Math.max(e.stageTime,s.stages[0].teleporterAt+8),e.coefficient=1+e.runTime*s.difficulty.perSecond,e.level=7,e.xpNeed=ka(s.xpBase,s.xpGrowth,e.level),e.xp=Math.round(e.xpNeed*.58),e.kills.total=214,e.kills.fodder=198,e.kills.elite=16,e.lastFodderAt=e.stageTime,e.lastEliteAt=e.stageTime,e.lastSniperAt=e.stageTime,e.credits=0,e.inventory=[{id:"goat-hoof",stacks:2},{id:"lead-core",stacks:1},{id:"salt-ward",stacks:1}],Eo(e),e.player.hp=e.player.maxHp*.78}function tf(e){const s=e.teleporter;e.player.x=s.x,e.player.y=s.y,e.aimX=s.x+90,e.aimY=s.y-40,e.teleporter.state="charging",e.teleporter.charge=s.hold*.72;const t=e.catalog.entity("ember-mite"),n=e.catalog.entity("ember-chaser"),a=e.catalog.entity("ember-spitter");for(let i=0;i<pi;i+=1){const o=i/pi*Math.PI*2+.35,r=108+i%3*22;le(e,t,s.x+Math.cos(o)*r,s.y+Math.sin(o)*r)}le(e,n,s.x+72,s.y-8,!0,"noxious"),le(e,n,s.x-64,s.y+36,!0,"shielder"),le(e,a,s.x+130,s.y-58),le(e,a,s.x-118,s.y-52)}function sf(e){const s=e.teleporter,t=e.catalog.entity(e.catalog.loop.stages[0].boss);e.player.x=s.x-56,e.player.y=s.y+28,e.aimX=s.x+64,e.aimY=s.y-18,e.teleporter.state="done",e.teleporter.charge=s.hold;const n=le(e,t,s.x+72,s.y-24);n>=0&&t.ai.type==="boss"&&(Da(e,n,t.ai),e.bossSpawned=!0,e.boss.cooldowns[0]=0,e.boss.cooldowns[1]=.2);const a=e.catalog.entity("ember-mite");le(e,a,s.x+118,s.y+36),le(e,a,s.x+40,s.y-96)}function nf(e,s){const{enemies:t,player:n}=e;let a=-1,i=1/0,o=-1,r=1/0;for(let c=0;c<t.cap;c+=1){if(t.alive[c]===0)continue;const d=Math.hypot(t.x[c]-n.x,t.y[c]-n.y);(t.role[c]===O||t.role[c]===j)&&d<r&&(o=c,r=d),d<i&&(a=c,i=d)}const l=o>=0?o:a;if(l<0){s.aimX=n.x+80,s.aimY=n.y;return}s.aimX=t.x[l],s.aimY=t.y[l]}const Qo=96;function af(e){return`sprites/items/${e}.png`}function Xe(e,s,t,n){const a=document.createElement("img");return a.className=t,a.alt=s,n!==void 0&&(a.width=n,a.height=n),a.src=af(e),a.decoding="async",a.draggable=!1,a}function hn(e,s="item-chip",t){const n=document.createElement("span");n.className=s,n.dataset.rarity=e.rarity,n.dataset.itemId=e.id,n.title=e.stacks>1?`${e.name} ×${e.stacks}`:e.name;const a=Xe(e.id,e.name,"item-chip-icon",t);if(a.addEventListener("error",()=>{if(a.remove(),!n.querySelector(".item-chip-fallback")){const i=document.createElement("span");i.className="item-chip-fallback",i.textContent=e.name.slice(0,1).toUpperCase(),n.prepend(i)}}),n.appendChild(a),e.stacks>1){const i=document.createElement("span");i.className="item-chip-stacks",i.textContent=`x${e.stacks}`,n.appendChild(i)}return n}const of=24,La=40;function rf(e){return`sprites/skills/${e}.png`}function Na(e,s,t,n=of){const a=document.createElement("img");return a.className=t,a.alt=s,a.width=n,a.height=n,a.src=rf(e),a.decoding="async",a.draggable=!1,a}let us=null,Dn=null;const vi=new Map,bi=new Map,aa=new Map;let fs=null;function lf(){return typeof ResizeObserver>"u"?null:(fs||(fs=new ResizeObserver(e=>{for(const s of e){const t=s.target,n=aa.get(t);if(!n||!t.isConnected){fs?.unobserve(t),aa.delete(t);continue}Jo(t,n)}})),fs)}function Pn(e,s,t,n,a){const i=`${s.x},${s.y},${s.w},${s.h}:${n}x${a}`,o=bi.get(i);if(o)return o;const r=s.w,l=s.h,c=t.margins,d=t.center??{x:Math.round(r/2),y:Math.round(l/2),w:0,h:0},u=c.left,f=Math.max(0,d.x-c.left),m=d.w,h=Math.max(0,r-c.right-(d.x+d.w)),p=c.right,g=c.top,v=Math.max(0,d.y-c.top),y=d.h,b=Math.max(0,l-c.bottom-(d.y+d.h)),x=c.bottom,k=[0,u,d.x,d.x+d.w,r-c.right],C=[u,f,m,h,p],M=[0,g,d.y,d.y+d.h,l-c.bottom],w=[g,v,y,b,x],R=u,D=m,L=p,U=Math.max(0,n-(R+D+L)),_=Math.floor(U/2),G=U-_,N=g,Se=y,tt=x,es=Math.max(0,a-(N+Se+tt)),Ie=Math.floor(es/2),ts=es-Ie,ss=[0,R,R+_,R+_+D,R+_+D+G],xt=[R,_,D,G,L],jr=[0,N,N+Ie,N+Ie+Se,N+Ie+Se+ts],qr=[N,Ie,Se,ts,tt],ns=document.createElement("canvas");ns.width=Math.max(1,n),ns.height=Math.max(1,a);const bn=ns.getContext("2d");if(bn){bn.imageSmoothingEnabled=!1;for(let st=0;st<5;st++){const Zr=jr[st],qa=qr[st],Qr=s.y+M[st],Za=w[st];if(!(qa<=0||Za<=0))for(let nt=0;nt<5;nt++){const Jr=ss[nt],Qa=xt[nt],el=s.x+k[nt],Ja=C[nt];Qa<=0||Ja<=0||bn.drawImage(e,el,Qr,Ja,Za,Jr,Zr,Qa,qa)}}}const ja=ns.toDataURL("image/png");return bi.set(i,ja),ja}function Jo(e,s){const t=e.getBoundingClientRect(),n=Math.round(t.width),a=Math.round(t.height),i=e.dataset.uiSliceW,o=e.dataset.uiSliceH;if((n===0||a===0)&&i&&o)return;const r=s.scale>0?s.scale:1,l=Math.max(s.entry.idle.w,n>0?Math.round(n/r):s.entry.idle.w),c=Math.max(s.entry.idle.h,a>0?Math.round(a/r):s.entry.idle.h);if(i===String(l)&&o===String(c))return;const d=s.entry.nineSlice,u=Pn(s.atlasImage,s.entry.idle,d,l,c),f=Pn(s.atlasImage,s.entry.hover,d,l,c),m=Pn(s.atlasImage,s.entry.active,d,l,c);e.style.setProperty("--ui-slice-idle",`url("${u}")`),e.style.setProperty("--ui-slice-hover",`url("${f}")`),e.style.setProperty("--ui-slice-active",`url("${m}")`),e.dataset.uiSliceW=String(l),e.dataset.uiSliceH=String(c),e.dataset.hasUiCenterSlice="1",e.dataset.hasUiSlice="0",e.dataset.hasUiStates="1",e.dataset.hasUiSprite="1"}function cf(e){return ia(`sprites/ui/${e}.png`)}function ia(e){if(typeof document<"u"&&document.baseURI)try{return new URL(e,document.baseURI).href}catch{return e}return e}function er(e){return new Promise(s=>{const t=new Image;t.onload=()=>s(t),t.onerror=()=>s(null),t.src=e})}async function df(){return us||(Dn||(Dn=(async()=>{try{const e=await fetch(ia("sprites/manifest.json"),{cache:"no-cache"});if(!e.ok)return{ids:new Set,atlas:null,atlasImage:null,atlasUrl:""};const s=await e.json();if(!s||typeof s!="object")return{ids:new Set,atlas:null,atlasImage:null,atlasUrl:""};const t=s,n=t.uiAtlas??null,a=new Set([...t.ui??[],...Object.keys(n?.frames??{})]);let i=null,o="";return n&&n.src&&(o=ia(n.src),i=await er(o)),{ids:a,atlas:n,atlasImage:i,atlasUrl:o}}catch{return{ids:new Set,atlas:null,atlasImage:null,atlasUrl:""}}})()),us=await Dn,us)}function Ln(e,s){const t=`${s.x},${s.y},${s.w},${s.h}`,n=vi.get(t);if(n)return n;const a=document.createElement("canvas");a.width=Math.max(1,s.w),a.height=Math.max(1,s.h);const i=a.getContext("2d");i&&(i.imageSmoothingEnabled=!1,i.drawImage(e,s.x,s.y,s.w,s.h,0,0,s.w,s.h));const o=a.toDataURL("image/png");return vi.set(t,o),o}function Nn(e,s,t){const n=e/Math.max(1,t.w)*100,a=s/Math.max(1,t.h)*100;return`${n.toFixed(4)}% ${a.toFixed(4)}%`}function Fn(e,s,t){const n=e-t.w,a=s-t.h,i=n>0?t.x/n*100:0,o=a>0?t.y/a*100:0;return`${i.toFixed(4)}% ${o.toFixed(4)}%`}function uf(e,s,t,n,a){if(e.style.setProperty("--ui-aspect",`${a.idle.w} / ${a.idle.h}`),a.nineSlice){const i=a.nineSlice,o=i.scale??1;if(i.center){const u={entry:a,atlasImage:t,scale:o};aa.set(e,u),Jo(e,u),lf()?.observe(e);return}const r=i.margins,l=Ln(t,a.idle),c=Ln(t,a.hover),d=Ln(t,a.active);e.style.setProperty("--ui-slice-idle",`url("${l}")`),e.style.setProperty("--ui-slice-hover",`url("${c}")`),e.style.setProperty("--ui-slice-active",`url("${d}")`),e.style.setProperty("--ui-slice-insets",`${r.top} ${r.right} ${r.bottom} ${r.left}`),e.style.setProperty("--ui-slice-widths",`${Math.round(r.top*o)}px ${Math.round(r.right*o)}px ${Math.round(r.bottom*o)}px ${Math.round(r.left*o)}px`),e.style.setProperty("--ui-slice-repeat",i.repeat??"stretch"),e.style.setProperty("--ui-expandable-rect",`${i.expandable.x}px ${i.expandable.y}px ${i.expandable.w}px ${i.expandable.h}px`),e.dataset.hasUiSlice="1",e.dataset.hasUiStates="1",e.dataset.hasUiSprite="1";return}e.style.setProperty("--ui-sprite",`url("${n}")`),e.style.setProperty("--ui-bg-size",Nn(s.width,s.height,a.idle)),e.style.setProperty("--ui-bg-pos",Fn(s.width,s.height,a.idle)),e.style.setProperty("--ui-bg-size-hover",Nn(s.width,s.height,a.hover)),e.style.setProperty("--ui-bg-pos-hover",Fn(s.width,s.height,a.hover)),e.style.setProperty("--ui-bg-size-active",Nn(s.width,s.height,a.active)),e.style.setProperty("--ui-bg-pos-active",Fn(s.width,s.height,a.active)),e.dataset.hasUiSlice="0",e.dataset.hasUiStates="1",e.dataset.hasUiSprite="1"}function ff(e,s){e&&(e.dataset.uiSprite=s,e.dataset.hasUiSprite||(e.dataset.hasUiSprite="0"),df().then(t=>{if(!e.isConnected||!t.ids.has(s))return;const n=t.atlas?.frames[s];if(t.atlas&&t.atlasImage&&n){uf(e,t.atlas,t.atlasImage,t.atlasUrl,n);return}const a=cf(s);er(a).then(i=>{!i||!e.isConnected||(e.style.setProperty("--ui-sprite",`url("${a}")`),e.style.setProperty("--ui-bg-size","100% 100%"),e.style.setProperty("--ui-bg-pos","0% 0%"),e.style.setProperty("--ui-aspect",`${i.naturalWidth||1} / ${i.naturalHeight||1}`),e.dataset.hasUiSlice="0",e.dataset.hasUiStates="0",e.dataset.hasUiSprite="1")})}))}function de(e=document){e.querySelectorAll("[data-ui-sprite]").forEach(t=>{const n=t.dataset.uiSprite;n&&ff(t,n)})}const mf=()=>document.getElementById("hud-status"),hf=()=>document.getElementById("hud-fps"),pf=()=>document.getElementById("hud-dots"),tr=()=>document.getElementById("hud-renderer"),pn=()=>document.getElementById("hud"),gf=()=>document.getElementById("hud-title"),yf=()=>document.getElementById("hud-hp"),vf=()=>document.getElementById("hud-lv"),bf=()=>document.getElementById("hud-time"),xf=()=>document.getElementById("hud-stage"),kf=()=>document.getElementById("xp-fill"),Sf=()=>document.getElementById("hp-fill"),Ef=()=>document.getElementById("hud-coeff"),Cf=()=>document.getElementById("hud-objective-kicker"),Mf=()=>document.getElementById("hud-objective-label"),wf=()=>document.getElementById("hud-objective-detail"),Rf=()=>document.getElementById("hud-objective-fill"),Tf=()=>document.getElementById("hud-objective-sub"),Af=()=>document.getElementById("hud-item-list"),If=()=>document.getElementById("hud-items"),Df=()=>document.getElementById("hud-difficulty"),Pf=()=>document.getElementById("hud-diff-tier"),Lf=()=>document.getElementById("hud-diff-coeff"),Nf=()=>document.getElementById("hud-diff-tape"),kt=[{index:1,name:"Dormant",min:1,max:1.3},{index:2,name:"Stirring",min:1.3,max:1.65},{index:3,name:"Tempered",min:1.65,max:2.05},{index:4,name:"Calcined",min:2.05,max:2.55},{index:5,name:"Volatile",min:2.55,max:3.15},{index:6,name:"Cataclysm",min:3.15,max:1/0}],ms=72,Ff=44;let oa=xe("debug"),xi=!1,qt=!1,ra="",Fa=[],la="",sr={stage:"--",runTime:0,level:1,bosses:0,kills:0,damageDealt:0,coefficient:1,totalItems:0};function Bf(){return Fa}function Hf(){return sr}function gn(){qt=!1,ra="",Fa=[],la="",Ba(),pn()?.classList.add("hidden"),document.getElementById("hud-play")?.classList.add("hidden")}function $f(e){qt=!1,Ba(),ar(),document.getElementById("hud-play")?.classList.add("hidden"),document.getElementById("hud-debug")?.classList.remove("hidden"),document.getElementById("row-dots")?.classList.remove("hidden"),document.getElementById("row-coeff")?.classList.add("hidden");const s=pf(),t=tr(),n=gf();n&&(n.textContent="GPU smoke"),s&&(s.textContent=String(ta)),t&&(t.textContent=e),zs("warmup")}function _f(e){qt=!0,Ba(),Xf(),ar();const s=document.getElementById("hud-play");s?.classList.remove("hidden"),s&&de(s),document.getElementById("row-dots")?.classList.add("hidden"),document.getElementById("row-coeff")?.classList.remove("hidden");const t=tr();t&&(t.textContent=e),zs("arena"),ir()}function zs(e){const s=mf(),t=pn();s&&(s.textContent=e),t?.setAttribute("data-status",e)}function nr(e){const s=hf();s&&(s.textContent=e.toFixed(0))}function Gf(e){const s=xf(),t=yf(),n=vf(),a=bf(),i=kf(),o=Sf(),r=Ef(),l=Cf(),c=Mf(),d=wf(),u=Rf(),f=Tf(),m=e.items.reduce((p,g)=>p+g.stacks,0);if(sr={stage:e.stage,runTime:e.runTime,level:e.level,bosses:e.bosses??0,kills:e.kills??0,damageDealt:e.damageDealt??0,coefficient:e.coefficient,totalItems:m},s&&(s.textContent=e.stage),t&&(t.textContent=`${Math.max(0,e.playerHp).toFixed(0)} / ${e.playerMax.toFixed(0)}`),n&&(n.textContent=`Lv ${e.level}`),a&&(a.textContent=Q(e.runTime)),l&&(e.objectiveKicker&&e.objectiveKicker.trim().length>0?(l.textContent=e.objectiveKicker,l.classList.remove("hidden")):(l.textContent="",l.classList.add("hidden"))),c&&(c.textContent=e.objective),d&&(d.textContent=e.objectiveDetail,d.classList.toggle("hidden",e.objectiveDetail.length===0)),f&&(e.objectiveSub&&e.objectiveSub.trim().length>0?(f.textContent=e.objectiveSub,f.classList.remove("hidden")):(f.textContent="",f.classList.add("hidden"))),u&&(u.style.width=`${Math.round(Math.min(1,Math.max(0,e.objectivePct))*100)}%`),i){const p=e.xpNeed>0?Math.min(1,e.xp/e.xpNeed):0;i.style.width=`${Math.round(p*100)}%`}if(o){const p=e.playerMax>0?Math.min(1,Math.max(0,e.playerHp)/e.playerMax):0;o.style.height=`${Math.round(p*100)}%`}r&&(r.textContent=`×${e.coefficient.toFixed(2)}`),zf(e.coefficient),Vf(e.skills),Wf(e.items),document.documentElement.dataset.biome=e.biome;const h=pn();h?.setAttribute("data-holding",e.holding?"1":"0"),h?.setAttribute("data-outside",e.outside?"1":"0"),e.iframe||e.holding?h?.setAttribute("data-status","pass"):e.playerHp<e.playerMax*.35?h?.setAttribute("data-status","fail"):e.boss?h?.setAttribute("data-status","warmup"):h?.setAttribute("data-status","arena")}function Of(e){return e>=Tl?"pass":"fail"}function Q(e){const s=Math.floor(e/60),t=Math.floor(e%60);return`${s}:${t.toString().padStart(2,"0")}`}function Vf(e){const s=e.map(n=>`${n.slot}:${n.id}`).join("|"),t=s!==la;t&&(la=s);for(const n of e){const a=document.querySelector(`.skill-slot[data-slot="${n.slot}"]`);if(!a)continue;const i=a.querySelector(".skill-glyph"),o=a.querySelector(".skill-cd");i&&(i.textContent=n.empty?"—":n.glyph),t&&Uf(a,n);const r=!n.empty&&n.cd<=0,l=n.empty||n.max<=0||n.cd<=0?0:Math.min(1,n.cd/n.max);a.style.setProperty("--cd",String(l)),a.dataset.ready=r?"1":"0",a.dataset.empty=n.empty?"1":"0",a.dataset.iframe=n.iframe?"1":"0",a.title=n.empty?"":n.name,o&&(!n.empty&&n.cd>.05?o.textContent=n.cd>=1?`${Math.ceil(n.cd)}s`:`${n.cd.toFixed(1)}s`:o.textContent="")}}function Uf(e,s){if(e.querySelector(".skill-icon")?.remove(),delete e.dataset.skillId,e.dataset.hasIcon="0",s.empty||!s.id)return;const t=Na(s.id,s.name,"skill-icon",La);t.addEventListener("error",()=>{t.remove(),e.dataset.hasIcon="0"}),t.addEventListener("load",()=>{e.dataset.hasIcon="1"}),e.dataset.skillId=s.id,e.appendChild(t)}function Wf(e){Fa=e;const s=Af(),t=If();if(!s||!t)return;const n=Math.max(3,Math.ceil(Math.sqrt(Math.max(1,e.length))));s.style.setProperty("--inv-cols",String(n));const a=`${n}|${e.map(i=>`${i.id}:${i.stacks}:${i.rarity}`).join("|")}`;if(!(a===ra&&s.childElementCount===e.length)){ra=a,s.replaceChildren();for(const i of e)s.appendChild(hn(i,"item-chip"))}}function ar(){pn()?.classList.remove("hidden")}function zf(e){const s=Df(),t=Pf(),n=Lf(),a=Nf();if(!s||!t||!n||!a)return;const i=Math.max(1,e);let o=kt[0],r=0;for(let d=0;d<kt.length;d++){const u=kt[d];i>=u.min&&(o=u,r=d)}let l=0;if(r<kt.length-1){const d=o.max-o.min,u=d>0?Math.min(1,Math.max(0,(i-o.min)/d)):0;l=r*ms+u*ms}else{const d=Math.max(0,i-o.min);l=(kt.length-1)*ms+d/.6*ms}const c=Ff-l;a.style.transform=`translate3d(${c.toFixed(1)}px, 0, 0)`,t.textContent=o.name,n.textContent=`×${i.toFixed(2)}`,s.dataset.tier!==String(o.index)&&(s.dataset.tier=String(o.index))}function Ba(){typeof document>"u"||(document.documentElement.dataset.play=qt?"1":"0")}function Xf(){xi||(xi=!0,window.addEventListener("keydown",e=>{e.key!=="F3"||!qt||(e.preventDefault(),oa=!oa,ir())}))}function ir(){document.getElementById("hud-debug")?.classList.toggle("hidden",!oa)}const Ye=new Map,ki=["runner","penitent"],Yf={cinder:"#120a0d",rime:"#08101a"};function Kf(e){return e==="rime-dock"||e==="glacial-tomb"?"rime":"cinder"}function jf(e){return e==="glacial-tomb"?"glacial":e==="rime-dock"?"rime":"cinder"}function B(e,s,t,n,a){const i=Ye.get(e);if(i)return i;const o=sm(s,Yf[t],n,a);return Ye.set(e,o),o}function qf(e,s){const t=Ye.get(e);if(t)return t;const n=s();return Ye.set(e,n),n}function je(e){return e==="penitent"||e==="consecrated"?"penitent":"runner"}function Zf(e="runner"){return`px-player-${je(e)}`}function Qf(e,s){return e===0&&s===0?null:Math.abs(e)>=Math.abs(s)&&e!==0?e<0?"left":"right":s<0?"up":"down"}function Jf(e,s){return e==="left"||e==="right"?e:s}function Ha(e,s="runner"){return`px-player-eyes-${je(s)}-${e}`}function or(e="runner"){return`px-crosshair-${je(e)}`}function rr(){return"px-elite-glyph"}function em(e){return je(e)==="penitent"?hm():mm()}function tm(e){return Gt("cinder",je(e))}function Xs(e){return`px-pillar-${e}`}function _t(e,s){return`px-hazard-${e}-${s}`}function $a(e){return`px-volatile-${e}`}function Ys(e){return`px-floor-${e}`}function sm(e,s,t,n){const a=qe(e,e),i=a.getContext("2d",{willReadFrequently:!0});if(!i)throw new Error("2d context missing");return i.imageSmoothingEnabled=!1,i.clearRect(0,0,e,e),t({size:e,fill:(r,l,c,d,u)=>{i.fillStyle=u,i.fillRect(Math.floor(r),Math.floor(l),Math.max(1,Math.floor(c)),Math.max(1,Math.floor(d)))},dot:(r,l,c)=>{i.fillStyle=c,i.fillRect(Math.floor(r),Math.floor(l),1,1)}}),n?.seal&&Am(i,e,e,n.seal),Im(i,e,e,s,n?.dither!==!1),a}function nm(){const e=new Map;return e.set("runner",ue(Gt("cinder","runner"))),e.set("penitent",ue(Gt("cinder","penitent"))),e.set("ember-mite",Ei([He("cinder",0),He("cinder",1)],[Ci("cinder")],7)),e.set("frost-mite",Ei([He("rime",0),He("rime",1)],[Ci("rime")],7)),e.set("ember-spitter",ue(Ks("cinder"))),e.set("frost-spitter",ue(Ks("rime"))),e.set("ember-chaser",ue(js("cinder"))),e.set("frost-warden",ue(js("rime"))),e.set("cinder-heart",ue(dr())),e.set("frost-sovereign",ue(ur())),e.set("frost-emperor",ue(fr())),e.set("enemy-astral-sniper",ue(mr())),e}function am(e){switch(e){case"runner":return Gt("cinder","runner");case"penitent":return Gt("cinder","penitent");case"ember-mite":return He("cinder",0);case"frost-mite":return He("rime",0);case"ember-spitter":return Ks("cinder");case"frost-spitter":return Ks("rime");case"ember-chaser":return js("cinder");case"frost-warden":return js("rime");case"cinder-heart":return dr();case"frost-sovereign":return ur();case"frost-emperor":return fr();case"enemy-astral-sniper":return mr();default:return He("cinder",0)}}function im(e,s="cinder"){return e==="pillar"?hr(s):e==="hazard"?ca(s,0):pr(s)}function om(){const e=new Map,s=["cinder","rime"];for(const t of s){for(const n of ki)z(e,Ha(t,n),um(t,n));z(e,Xs(t),hr(t)),z(e,_t(t,0),ca(t,0)),z(e,_t(t,1),ca(t,1)),z(e,$a(t),pr(t))}z(e,rr(),fm()),z(e,"px-bolt-player",Bn("#fff4c8","#ffd35a","cinder")),z(e,"px-bolt-enemy-cinder",Bn("#ffcc88","#ff5522","cinder")),z(e,"px-bolt-enemy-rime",Bn("#dff6ff","#44ddff","rime")),z(e,"px-gem",pm()),z(e,"px-lore",gm()),z(e,"px-spark",ym());for(const t of ki)z(e,or(t),Mi(t));return z(e,"px-crosshair",Mi("runner")),z(e,"px-waypoint",xm()),z(e,"px-glow",km()),z(e,"px-player-halo",Sm()),z(e,"px-ash",hs("#9a8a80",2)),z(e,"px-ember",hs("#ff7722",1)),z(e,"px-snow",hs("#d8eef8",2)),z(e,"px-mist",hs("#1a3048",3)),e}function Si(e,s,t){const n=qe(s.w,s.h),a=n.getContext("2d",{willReadFrequently:!0});if(!a)return n;a.imageSmoothingEnabled=!1,a.drawImage(e,s.x,s.y,s.w,s.h,0,0,s.w,s.h);const i=a.getImageData(0,0,s.w,s.h),{data:o}=i;for(let r=0;r<o.length;r+=4){if(o[r+3]<16)continue;let l=o[r],c=o[r+1],d=o[r+2];t==="cinder"?l>110&&l>d*1.65?(l=Math.round(58+(l-58)*.68),c=Math.round(42+(c-42)*.65),d=Math.round(40+(d-40)*.75)):(l=Math.min(255,Math.round(44+l*.72)),c=Math.min(255,Math.round(35+c*.7)),d=Math.min(255,Math.round(38+d*.7))):t==="rime"?d>160&&(c>130||d>l*1.5)?(l=Math.round(l*.45),c=Math.min(130,Math.round(c*.5)),d=Math.min(150,Math.round(d*.56))):(l=Math.round(l*.48),c=Math.round(c*.52),d=Math.round(d*.58)):t==="glacial"&&(d>190&&c>150?(l=Math.round(l*.38),c=Math.min(125,Math.round(c*.44)),d=Math.min(145,Math.round(d*.5))):(l=Math.round(l*.42),c=Math.round(c*.46),d=Math.round(d*.52))),o[r]=l,o[r+1]=c,o[r+2]=d}return a.putImageData(i,0,0),n}function rm(e,s){if(!s)return null;const t=u=>{let f=s[`${e}-${u}`];return(!f||f.w===0||f.h===0)&&e==="glacial"&&(f=s[`rime-${u}`]),f&&f.w>0&&f.h>0?f:void 0},n=t("border-edge"),a=t("border-corner"),i=t("border-h-0")??n,o=t("border-h-1")??i,r=t("border-v-0")??n,l=t("border-v-1")??r,c=t("border-corner-top")??a,d=t("border-corner-bottom")??a;return!i&&!o&&!r&&!l&&!c&&!d?null:{h0:i,h1:o,v0:r,v1:l,cornerTop:c,cornerBottom:d}}function lm(e,s,t,n,a){const i=e==="cinder"?"cinder":"rime";return qf(Ys(e),()=>{const o=qe(s,t),r=o.getContext("2d");if(!r)throw new Error("2d context missing");r.imageSmoothingEnabled=!1;const l=[0,1,2,3].map(x=>{if(!a)return null;let k=a[`${e}-tile-${x}`];return(!k||k.w===0||k.h===0)&&e==="glacial"&&(k=a[`rime-tile-${x}`]),(!k||k.w===0||k.h===0)&&(k=a[`${e}-tile-0`]),(!k||k.w===0||k.h===0)&&e==="glacial"&&(k=a["rime-tile-0"]),k&&k.w>0&&k.h>0?k:null}),c=[0,1,2,3].map(x=>{if(!a)return null;let k=a[`${e}-tile-rune-${x}`];return(!k||k.w===0||k.h===0)&&e==="glacial"&&(k=a[`rime-tile-rune-${x}`]),(!k||k.w===0||k.h===0)&&(k=a[`${e}-tile-rune-0`]),(!k||k.w===0||k.h===0)&&e==="glacial"&&(k=a["rime-tile-rune-0"]),k&&k.w>0&&k.h>0?k:null}),d=!!n&&l.some(x=>x!==null),u=[0,1,2,3].map(x=>{const k=l[x];return!d||!n||!k?null:Si(n,k,e)}),f=[0,1,2,3].map(x=>{const k=c[x];return!d||!n||!k?null:Si(n,k,e)}),m=[0,1,2,3].map(x=>Em(i,x)),h=[0,1,2,3].map(x=>Cm(i,x)),p=64,g=Math.floor(s/p),v=Math.floor(t/p),y=e==="cinder"?1013:e==="rime"?2027:3049;for(let x=0;x<v;x+=1)for(let k=0;k<g;k+=1)if(wm(k,x,g,v,y)){const M=Rm(k,x,y),w=f[M]??f[0],R=c[M]??c[0];if(w)r.drawImage(w,0,0,w.width,w.height,k*p,x*p,p,p);else if(d&&n&&R)r.drawImage(n,R.x,R.y,R.w,R.h,k*p,x*p,p,p);else if(d&&n){const D=u[Hn(k,x,y)]??u[0],L=l[Hn(k,x,y)]??l[0];D?r.drawImage(D,0,0,D.width,D.height,k*p,x*p,p,p):L?r.drawImage(n,L.x,L.y,L.w,L.h,k*p,x*p,p,p):r.drawImage(h[M],k*p,x*p,p,p)}else r.drawImage(h[M],k*p,x*p,p,p)}else{const M=Hn(k,x,y),w=u[M]??u[0],R=l[M]??l[0];w?r.drawImage(w,0,0,w.width,w.height,k*p,x*p,p,p):d&&n&&R?r.drawImage(n,R.x,R.y,R.w,R.h,k*p,x*p,p,p):r.drawImage(m[M],k*p,x*p,p,p)}const b=rm(e,a);return n&&b?cm(r,s,t,n,b):Tm(r,s,t,i),o})}function cm(e,s,t,n,a){const{h0:i,h1:o,v0:r,v1:l,cornerTop:c,cornerBottom:d}=a,u=i??o;if(u){const m=u.w,h=u.h;for(let p=0;p<s;p+=m){const g=Math.min(m,s-p),v=(p*2654435761>>>0)%2===0?i??u:o??u;e.drawImage(n,v.x,v.y,g,h,p,0,g,h);const y=((p+1337)*2654435761>>>0)%2===0?i??u:o??u;e.drawImage(n,y.x,y.y,g,h,p,t-h,g,h)}}const f=r??l??u;if(f){const m=f.w,h=f.h;for(let p=0;p<t;p+=h){const g=Math.min(h,t-p),v=(p*1597334677>>>0)%2===0?r??f:l??f;e.drawImage(n,v.x,v.y,m,g,0,p,m,g);const y=((p+7919)*1597334677>>>0)%2===0?r??f:l??f;e.drawImage(n,y.x,y.y,m,g,s-m,p,m,g)}}if(c&&c.w>0&&c.h>0){const m=c.w,h=c.h;e.drawImage(n,c.x,c.y,m,h,0,0,m,h),e.save(),e.translate(s,0),e.scale(-1,1),e.drawImage(n,c.x,c.y,m,h,0,0,m,h),e.restore()}if(d&&d.w>0&&d.h>0){const m=d.w,h=d.h;e.drawImage(n,d.x,d.y,m,h,0,t-h,m,h),e.save(),e.translate(s,t-h),e.scale(-1,1),e.drawImage(n,d.x,d.y,m,h,0,0,m,h),e.restore()}}function z(e,s,t){Ye.set(s,t),e.set(s,t)}function dm(e){const s=e[0].width,t=e[0].height,n=qe(s*e.length,t),a=n.getContext("2d");if(!a)throw new Error("2d context missing");return a.imageSmoothingEnabled=!1,e.forEach((i,o)=>a.drawImage(i,o*s,0)),n}function ue(e){return{canvas:e,frameWidth:e.width,frameHeight:e.height,anims:{idle:{frames:[0],frameRate:1,repeat:-1}}}}function Ei(e,s,t){const n=[...e,...s],a=e.map((o,r)=>r),i=s.map((o,r)=>e.length+r);return{canvas:dm(n),frameWidth:n[0].width,frameHeight:n[0].height,anims:{idle:{frames:[0],frameRate:1,repeat:-1},walk:{frames:a,frameRate:t,repeat:-1},attack:{frames:i,frameRate:t*1.5,repeat:0}}}}function Gt(e,s){return B(Zf(s),32,e,t=>{s==="penitent"?cr(t):lr(t,e)})}function um(e,s){const t=s==="penitent"?e==="rime"?"#ffe8a0":"#ffdd66":e==="cinder"?"#b8fff8":"#77ffff";return B(Ha(e,s),8,e,n=>{n.fill(1,3,2,1,t),n.fill(5,3,2,1,t)})}function lr(e,s,t=0){const n=s==="cinder"?"#c94a4a":"#5ad4ff";e.fill(10,6,12,4,"#3a3244"),e.fill(8,8,16,5,"#52465c"),e.fill(7,12,18,14,"#2a2430"),e.fill(8,24,16,3,"#2a2430"),e.fill(9+t,26,5,4,"#2a2430"),e.fill(18-t,26,5,4,"#2a2430"),e.fill(8,12,16,2,n),e.fill(11,4,10,5,"#1c1822"),e.fill(12,3,8,3,"#1c1822")}function cr(e,s,t=0){const n="#c4783a",a="#3a2418",i="#2a1810";e.fill(8,4,16,6,i),e.fill(6,10,20,16,a),e.fill(8,24,16,6,i),e.fill(12,6,8,5,"#1a100c"),e.fill(7,8,18,3,"#8a6a32"),e.fill(10,12,12,3,n),e.fill(14,18,4,6,"#5c4520"),e.fill(9+t,26,5,4,i),e.fill(18-t,26,5,4,i)}function He(e,s){const t=e==="cinder"?"#ff5522":"#44ddff",n=e==="cinder"?"#5a2018":"#1a3a52",a=e==="cinder"?"#3a1410":"#0e2438";return B(`px-mite-${e}-${s}`,24,e,i=>{i.fill(4,8,16,10,n),i.fill(6,6,12,4,n),i.fill(8,10,8,6,t),i.fill(10,12,4,2,"#fff0c8");const o=s===0?18:17;i.fill(3,o,4,3,a),i.fill(17,s===0?17:18,4,3,a),i.fill(2,10,3,3,a),i.fill(19,10,3,3,a)})}function Ci(e){const s=e==="cinder"?"#ffffff":"#e0ffff",t=e==="cinder"?"#7a2b20":"#225070",n=e==="cinder"?"#ff3311":"#00ffff";return B(`px-mite-atk-${e}`,24,e,a=>{a.fill(3,7,18,11,t),a.fill(5,5,14,5,t),a.fill(7,9,10,8,s),a.fill(9,11,6,4,"#fff8e0"),a.fill(1,6,5,4,n),a.fill(18,6,5,4,n),a.fill(2,16,4,4,n),a.fill(18,16,4,4,n)})}function Ks(e){const s=e==="cinder"?"#4a2818":"#163044",t=e==="cinder"?"#ff7a3a":"#7ad4ff";return B(`px-spitter-${e}`,28,e,n=>{n.fill(12,18,4,8,s),n.fill(6,20,4,6,s),n.fill(18,20,4,6,s),n.fill(8,8,12,12,s),n.fill(10,4,8,6,"#2a1810"),n.fill(12,6,4,5,t),n.fill(13,8,2,2,"#fff4c8")})}function js(e){const s=e==="cinder"?"#6a3a32":"#2a4a66",t=e==="cinder"?"#c45a3a":"#7ad4ff";return B(`px-elite-${e}`,40,e,n=>{n.fill(12,10,16,22,s),n.fill(8,14,8,10,s),n.fill(24,14,8,10,s),n.fill(10,6,20,6,t),n.fill(14,2,4,6,t),n.fill(22,2,4,6,t),n.fill(16,16,8,8,e==="cinder"?"#ff5522":"#44ddff"),n.fill(6,12,4,4,"#9aa0a8"),n.fill(30,12,4,4,"#9aa0a8"),n.fill(14,32,5,6,s),n.fill(22,32,5,6,s)})}function fm(){return B(rr(),48,"cinder",e=>{const s="#ffffff";for(let t=8;t<40;t+=2)e.dot(t,8,s),e.dot(t,39,s),e.dot(8,t,s),e.dot(39,t,s);e.fill(22,14,4,20,s),e.fill(14,22,20,4,s),e.fill(18,18,12,12,"#00000000")})}function mm(){return B("px-portrait-runner",32,"rime",e=>{lr(e,"rime"),e.fill(13,9,2,2,"#77ffff"),e.fill(17,9,2,2,"#77ffff"),e.fill(12,16,8,6,"#3a90b8")},{seal:"#2a2430",dither:!1})}function hm(){return B("px-portrait-penitent",32,"cinder",e=>{cr(e),e.fill(13,14,2,2,"#ffdd66"),e.fill(17,14,2,2,"#ffdd66")},{seal:"#3a2418",dither:!1})}function dr(){return B("px-boss-cinder-heart",64,"cinder",e=>{e.fill(18,14,28,36,"#2a1814"),e.fill(16,18,32,28,"#3a2018"),e.fill(22,12,6,8,"#1a0c0a"),e.fill(36,12,6,8,"#1a0c0a"),e.fill(24,22,16,16,"#ff7722"),e.fill(28,26,8,8,"#fff0c8"),e.fill(20,20,4,20,"#1a0c0a"),e.fill(40,20,4,20,"#1a0c0a"),e.dot(26,18,"#5a3020"),e.dot(38,40,"#5a3020")})}function ur(){return B("px-boss-frost-sovereign",64,"rime",e=>{e.fill(22,16,20,36,"#1a3048"),e.fill(18,22,28,24,"#163044"),e.fill(20,6,24,12,"#7ad4ff"),e.fill(16,8,6,10,"#dff6ff"),e.fill(42,8,6,10,"#dff6ff"),e.fill(28,4,8,8,"#f4fbff"),e.fill(28,26,8,10,"#55ffff"),e.fill(14,28,8,3,"#88c8e8"),e.fill(42,32,8,3,"#88c8e8")})}function fr(){return B("px-boss-frost-emperor",64,"rime",e=>{e.fill(18,14,28,40,"#102238"),e.fill(14,20,36,28,"#183654"),e.fill(16,6,32,12,"#3d8ad4"),e.fill(12,4,6,14,"#dff6ff"),e.fill(46,4,6,14,"#dff6ff"),e.fill(22,2,6,10,"#ffffff"),e.fill(36,2,6,10,"#ffffff"),e.fill(29,1,6,12,"#77ffff"),e.fill(26,24,12,14,"#77ffff"),e.fill(29,27,6,8,"#ffffff"),e.fill(10,26,8,4,"#7ad4ff"),e.fill(46,26,8,4,"#7ad4ff")})}function mr(){return B("px-astral-watcher",28,"rime",e=>{e.fill(8,8,12,12,"#2a1844"),e.fill(6,10,16,8,"#4a2878"),e.fill(10,6,8,16,"#4a2878"),e.fill(10,10,8,8,"#b47aff"),e.fill(12,12,4,4,"#f0e8ff"),e.fill(13,13,2,2,"#44ddff"),e.fill(4,13,3,2,"#c4a35a"),e.fill(21,13,3,2,"#c4a35a"),e.fill(13,3,2,3,"#c4a35a"),e.fill(13,22,2,3,"#c4a35a")})}function hr(e){const s=e==="cinder"?"#3a2428":"#1c3044",t=e==="cinder"?"#c45a3a":"#55ffff";return B(Xs(e),64,e,n=>{n.fill(18,48,28,10,"#120a0d"),n.fill(20,8,24,46,s),n.fill(16,12,32,38,s),n.fill(22,6,20,6,e==="cinder"?"#4a3030":"#2a4860"),n.fill(28,18,8,2,t),n.fill(30,24,4,10,t),n.fill(26,36,12,2,t),n.fill(18,20,4,20,"#221418")})}function ca(e,s){const t=e==="cinder"?"#3a2018":"#1a3040",i=s===0?e==="cinder"?"#ff5522":"#1a6888":e==="cinder"?"#cc3300":"#44ddff";return B(_t(e,s),64,e,o=>{o.fill(8,16,48,32,t),o.fill(12,12,40,40,t),o.fill(16,18,32,28,i),o.fill(20,22,24,20,s===0?"#ffaa33":e==="cinder"?"#ff7722":"#88f0ff"),e==="rime"?(o.fill(18,20,6,4,"#dff6ff"),o.fill(40,36,8,5,"#c8e8f8")):(o.fill(24,24,3,3,"#fff0c8"),o.fill(36,32,2,2,"#ffcc66"))})}function pr(e){const s=e==="cinder"?"#b87333":"#8aa4b8",t=e==="cinder"?"#4a2018":"#1a3a52";return B($a(e),24,e,n=>{n.fill(7,4,10,16,t),n.fill(6,6,12,3,s),n.fill(6,12,12,3,s),n.fill(8,2,8,3,e==="cinder"?"#8a4a28":"#c8e4f4"),n.fill(10,8,4,4,e==="cinder"?"#ff5522":"#55ffff")})}function Bn(e,s,t){return B(`px-bolt-${e}-${s}`,8,t,n=>{n.fill(2,2,4,4,s),n.fill(3,3,2,2,e)})}function pm(){return B("px-gem",16,"cinder",e=>{e.fill(6,2,4,12,"#4aa0d4"),e.fill(4,4,8,8,"#ffffff"),e.fill(7,6,2,4,"#88ddff")})}function gm(){return B("px-lore",16,"cinder",e=>{e.fill(2,2,12,2,"#c49a45"),e.fill(2,12,12,2,"#c49a45"),e.fill(3,4,10,8,"#e8d8b8"),e.fill(4,5,8,6,"#f6ebd4"),e.fill(5,5,6,1,"#4a3423"),e.fill(5,7,4,1,"#4a3423"),e.fill(6,8,4,3,"#c93b3b"),e.fill(7,9,2,1,"#ffd35a")})}function ym(){return B("px-spark",8,"cinder",e=>{e.fill(3,2,2,4,"#ffffff"),e.fill(2,3,4,2,"#ffd35a")})}function vm(){return B("px-crosshair-runner",16,"cinder",e=>{e.fill(7,1,2,3,"#5ad4ff"),e.fill(7,4,2,1,"#ffffff"),e.fill(7,11,2,1,"#ffffff"),e.fill(7,12,2,3,"#5ad4ff"),e.fill(1,7,3,2,"#5ad4ff"),e.fill(4,7,1,2,"#ffffff"),e.fill(11,7,1,2,"#ffffff"),e.fill(12,7,3,2,"#5ad4ff"),e.dot(3,3,"#dff6ff"),e.dot(12,3,"#dff6ff"),e.dot(3,12,"#dff6ff"),e.dot(12,12,"#dff6ff")})}function bm(){return B("px-crosshair-penitent",16,"cinder",e=>{e.fill(7,1,2,2,"#ffe8a0"),e.fill(7,13,2,2,"#ffe8a0"),e.fill(1,7,2,2,"#ffe8a0"),e.fill(13,7,2,2,"#ffe8a0"),e.fill(6,3,4,1,"#c4783a"),e.fill(6,12,4,1,"#c4783a"),e.fill(3,6,1,4,"#c4783a"),e.fill(12,6,1,4,"#c4783a"),e.dot(4,4,"#c4783a"),e.dot(11,4,"#c4783a"),e.dot(4,11,"#c4783a"),e.dot(11,11,"#c4783a"),e.fill(7,7,2,2,"#fff4c8")})}function Mi(e){return je(e)==="penitent"?bm():vm()}function xm(){return B("px-waypoint",16,"cinder",e=>{e.fill(12,6,3,4,"#fff4c8"),e.fill(8,4,5,8,"#5ad4ff"),e.fill(4,2,5,12,"#9ad4ff")})}function km(){const e=qe(32,32),s=e.getContext("2d");if(!s)throw new Error("2d context missing");const t=s.createRadialGradient(16,16,2,16,16,15);return t.addColorStop(0,"rgba(255, 220, 140, 0.55)"),t.addColorStop(1,"rgba(255, 220, 140, 0)"),s.fillStyle=t,s.fillRect(0,0,32,32),Ye.set("px-glow",e),e}function Sm(){const e=qe(48,48),s=e.getContext("2d");if(!s)throw new Error("2d context missing");const t=s.createRadialGradient(24,24,2,24,24,23);return t.addColorStop(0,"rgba(255, 244, 200, 0.95)"),t.addColorStop(.35,"rgba(255, 215, 120, 0.65)"),t.addColorStop(.7,"rgba(255, 160, 60, 0.30)"),t.addColorStop(1,"rgba(255, 120, 30, 0)"),s.fillStyle=t,s.fillRect(0,0,48,48),Ye.set("px-player-halo",e),e}function hs(e,s){const t=qe(4,4),n=t.getContext("2d");if(!n)throw new Error("2d context missing");return n.imageSmoothingEnabled=!1,n.fillStyle=e,n.fillRect(0,0,s,s),t}function Em(e,s){const t=`px-tile-${e}-${s}`,n=e==="cinder"?["#3c3034","#46383c","#342a2d","#4a3c40"]:["#0e1722","#121e2b","#0a111a","#162030"],a=e==="cinder"?"#78523c":"#3a5a70";return B(t,64,e,i=>{if(i.fill(0,0,64,64,n[s%3]),i.fill(2,2,28,28,n[(s+1)%3]),i.fill(34,6,26,22,n[(s+2)%3]),i.fill(8,36,40,20,n[s%3]),s===0)i.fill(12,12,8,1,a),i.fill(16,10,1,8,a);else if(s===1)for(let o=8;o<50;o+=7)i.dot(o,40+o%3,a);else s===2?(i.fill(40,18,10,1,a),i.fill(44,16,1,8,a)):i.fill(20,48,18,1,a)})}function Cm(e,s){const t=`px-tile-rune-${e}-${s}`,n=e==="cinder"?["#1c1113","#231517","#170d0f","#2a1814"]:["#0e1722","#121e2b","#0a111a","#162030"],a=e==="cinder"?"#ff9933":"#55ffff",i=e==="cinder"?"#b44a24":"#2888aa";return B(t,64,e,o=>{o.fill(0,0,64,64,n[s%3]),o.fill(2,2,28,28,n[(s+1)%3]),o.fill(34,6,26,22,n[(s+2)%3]),o.fill(8,36,40,20,n[s%3]),o.fill(20,20,24,24,"#100a0d"),o.fill(22,22,20,20,n[(s+1)%3]),s===0?(o.fill(26,31,12,2,i),o.fill(31,26,2,12,i),o.dot(31,31,a),o.dot(32,32,a),o.dot(26,31,a),o.dot(37,31,a)):s===1?(o.fill(28,26,8,2,i),o.fill(26,28,2,8,i),o.fill(36,28,2,8,i),o.fill(28,36,8,2,i),o.fill(31,24,2,16,a)):s===2?(o.fill(26,26,12,2,i),o.fill(26,36,12,2,i),o.fill(24,28,2,8,i),o.fill(38,28,2,8,i),o.fill(30,30,4,4,a)):(o.fill(27,25,10,2,i),o.fill(27,37,10,2,i),o.fill(25,27,2,10,a),o.fill(37,27,2,10,a),o.dot(31,31,a))})}function Me(e,s,t=1337){let n=t+Math.imul(e,2654435761)+Math.imul(s,2246822519)>>>0;return n=Math.imul(n^n>>>16,2246822507),n=Math.imul(n^n>>>13,3266489909),(n^n>>>16)>>>0}function Mm(e,s,t=42){const n=e*.12,a=s*.12,i=Math.floor(n),o=Math.floor(a),r=n-i,l=a-o,c=r*r*(3-2*r),d=l*l*(3-2*l),u=(Me(i,o,t)&65535)/65535,f=(Me(i+1,o,t)&65535)/65535,m=(Me(i,o+1,t)&65535)/65535,h=(Me(i+1,o+1,t)&65535)/65535,p=u*(1-c)+f*c,g=m*(1-c)+h*c;return p*(1-d)+g*d}function wm(e,s,t,n,a=1337){if(e<=1||s<=1||e>=t-2||s>=n-2)return!1;const i=Me(e,s,a+8888);if(i<4127195136)return!1;for(let o=-2;o<=2;o++)for(let r=-2;r<=2;r++)if(!(r===0&&o===0)&&Me(e+r,s+o,a+8888)>=i)return!1;return!0}function Rm(e,s,t=1337){return Me(e,s,t+4444)>>>16&3}function Hn(e,s,t=1337){const n=Mm(e,s,t+101),a=(Me(e,s,t+202)&65535)/65535;return n>.7?a<.35?1:a<.8?2:0:n<.25?a<.75?2:a<.9?1:0:a<.76?0:a<.87?2:a<.95?1:3}function Tm(e,s,t,n){const a=n==="cinder"?"#5a3020":"#3a5a7a",i=n==="cinder"?"#c45a3a":"#55ffff";e.imageSmoothingEnabled=!1,e.fillStyle=a,e.fillRect(0,0,s,8),e.fillRect(0,t-8,s,8),e.fillRect(0,0,8,t),e.fillRect(s-8,0,8,t),e.fillStyle=i,e.fillRect(8,8,s-16,2),e.fillRect(8,t-10,s-16,2),e.fillRect(8,8,2,t-16),e.fillRect(s-10,8,2,t-16),e.fillStyle=n==="cinder"?"#ffaa33":"#88f0ff";for(let o=32;o<s;o+=64)e.fillRect(o,4,4,4),e.fillRect(o,t-8,4,4),e.fillRect(4,o,4,4),e.fillRect(s-8,o,4,4)}function Am(e,s,t,n){const a=e.getImageData(0,0,s,t),{data:i}=a,o=new Uint8Array(s*t),r=[],l=(d,u)=>{if(d<0||u<0||d>=s||u>=t)return;const f=u*s+d;o[f]!==1&&(i[f*4+3]>16||(o[f]=1,r.push(f)))};for(let d=0;d<s;d+=1)l(d,0),l(d,t-1);for(let d=0;d<t;d+=1)l(0,d),l(s-1,d);for(;r.length>0;){const d=r.pop()??0,u=d%s,f=d/s|0;l(u-1,f),l(u+1,f),l(u,f-1),l(u,f+1)}const c=gr(n);for(let d=0;d<t;d+=1)for(let u=0;u<s;u+=1){const f=d*s+u;if(o[f]===1)continue;const m=f*4;i[m+3]>16||(i[m]=c[0],i[m+1]=c[1],i[m+2]=c[2],i[m+3]=255)}e.putImageData(a,0,0)}function Im(e,s,t,n,a=!0){const i=e.getImageData(0,0,s,t),{data:o}=i,r=new Uint8ClampedArray(o),l=gr(n),c=(u,f)=>(f*s+u)*4,d=(u,f)=>u<0||f<0||u>=s||f>=t?!1:r[c(u,f)+3]>16;for(let u=0;u<t;u+=1)for(let f=0;f<s;f+=1){const m=c(f,u);if(r[m+3]>16){let h=r[m],p=r[m+1],g=r[m+2];const v=a&&((f^u)&1)===0;v&&u<t*.4?(h=Math.min(255,h+22),p=Math.min(255,p+18),g=Math.min(255,g+16)):v&&u>t*.62&&(h=Math.floor(h*.78),p=Math.floor(p*.78),g=Math.floor(g*.82)),o[m]=h,o[m+1]=p,o[m+2]=g,o[m+3]=255}else d(f-1,u)||d(f+1,u)||d(f,u-1)||d(f,u+1)?(o[m]=l[0],o[m+1]=l[1],o[m+2]=l[2],o[m+3]=255):o[m+3]=0}e.putImageData(i,0,0)}function gr(e){const s=Number.parseInt(e.replace("#",""),16);return[s>>16&255,s>>8&255,s&255]}function qe(e,s){if(typeof document<"u"){const n=document.createElement("canvas");return n.width=e,n.height=s,n}const t=new Proxy({createImageData:()=>({data:new Uint8ClampedArray(e*s*4)}),getImageData:()=>({data:new Uint8ClampedArray(e*s*4)})},{get:(n,a)=>a in n?n[a]:()=>{},set:()=>!0});return{width:e,height:s,getContext:()=>t}}let ps=null,$n=null;async function yr(){return ps||($n||($n=(async()=>{try{const e=await fetch("sprites/manifest.json");if(!e.ok)return null;const s=await e.json();if(!s||typeof s!="object"||!("entities"in s))return null;const t=s;try{const n=await fetch("sprites/env/atlas.json");if(n.ok){const a=await n.json();if(a&&typeof a=="object"){const i="frames"in a&&typeof a.frames=="object"?a.frames:a;if(t.envAtlas)for(const[o,r]of Object.entries(i)){const l=r;l&&typeof l.w=="number"&&typeof l.h=="number"&&l.w>0&&l.h>0&&(t.envAtlas.frames[o]={x:Number(l.x)||0,y:Number(l.y)||0,w:l.w,h:l.h})}}}}catch{}return t}catch{return null}})()),ps=await $n,ps)}function Lt(e,s,t=0,n=0,a,i){const o=e.getContext("2d");o&&(o.imageSmoothingEnabled=!1,o.clearRect(0,0,e.width,e.height),a!==void 0&&i!==void 0?o.drawImage(s,t,n,a,i,0,0,e.width,e.height):o.drawImage(s,0,0,e.width,e.height))}function da(e){return new Promise(s=>{const t=new Image;t.onload=()=>s(t),t.onerror=()=>s(null),t.src=e})}function Dm(e,s){return e in s.entities?e:e==="ember-chaser"&&"ember-warden"in s.entities?"ember-warden":e==="ember-warden"&&"ember-chaser"in s.entities?"ember-chaser":e==="frost-chaser"&&"frost-warden"in s.entities?"frost-warden":e==="frost-warden"&&"frost-chaser"in s.entities?"frost-chaser":(e==="ember-mite"||e==="frost-mite")&&"mite"in s.entities?"mite":(e==="ember-spitter"||e==="frost-spitter")&&"spitter"in s.entities?"spitter":e}function _a(e,s,t,n){const a=am(s),i=document.createElement("canvas");return i.width=a.width,i.height=a.height,i.className=t,i.setAttribute("role","img"),i.setAttribute("aria-label",n),Lt(i,a),e.appendChild(i),yr().then(async o=>{if(!o||!i.isConnected)return;const r=Dm(s,o),l=o.entities[r];if(!l)return;const c=await da(l.src);if(!c||!i.isConnected)return;const d=l.anims.idle?.frames[0]??0,u=Math.max(1,Math.floor(c.naturalWidth/l.frameWidth)),f=d%u*l.frameWidth,m=Math.floor(d/u)*l.frameHeight;i.width=l.frameWidth,i.height=l.frameHeight,Lt(i,c,f,m,l.frameWidth,l.frameHeight)}),i}function Pm(e,s,t,n,a){const i=im(s,t),o=document.createElement("canvas");o.width=i.width,o.height=i.height,o.className=n,o.setAttribute("role","img"),o.setAttribute("aria-label",a),Lt(o,i),e.appendChild(o);const l=`${t}-${s==="hazard"?"hazard-0":s}`;return yr().then(async c=>{if(!c||!o.isConnected)return;const d=c.envAtlas?.frames[l];if(d&&c.envAtlas?.src){const u=await da(c.envAtlas.src);if(u&&o.isConnected){o.width=d.w,o.height=d.h,Lt(o,u,d.x,d.y,d.w,d.h);return}}if(c.env?.includes(l)){const u=await da(`sprites/env/${l}.png`);u&&o.isConnected&&(o.width=u.naturalWidth,o.height=u.naturalHeight,Lt(o,u))}}),o}const vr=1,br="survivors.records.v1",xr=10,_n=new WeakSet,wi=new WeakMap;let Pe=null;function Ga(){return{version:vr,totalRuns:0,victories:0,defeats:0,abandons:0,totalPlayTime:0,totalKills:0,fodderKills:0,eliteKills:0,bossKills:0,totalDamageDealt:0,totalDamageTaken:0,totalHealingDone:0,totalGemsCollected:0,totalItemsCollected:0,totalLevelsGained:0,stagesCleared:0,longestRunTime:0,fastestVictoryTime:null,highestLevel:1,highestCoefficient:1,mostKillsInRun:0,mostDamageInRun:0,furthestStageIndex:0,bySurvivor:{},entityKills:{},entityEncounters:{},entityLores:{},itemPicks:{},stageVisits:{},stageClears:{},recentRuns:[]}}function Lm(){const e=Ga();return e.totalRuns=4,e.victories=1,e.defeats=3,e.totalKills=640,e.fodderKills=580,e.eliteKills=52,e.bossKills=8,e.stageVisits["cinder-yard"]=4,e.stageClears["cinder-yard"]=2,e.furthestStageIndex=0,e.entityEncounters["ember-mite"]=220,e.entityKills["ember-mite"]=180,e.entityLores["ember-mite"]=1,e.entityEncounters["ember-spitter"]=48,e.entityKills["ember-spitter"]=31,e.entityEncounters["ember-chaser"]=18,e.entityKills["ember-chaser"]=11,e.entityLores["ember-chaser"]=1,e.entityEncounters["cinder-heart"]=2,e.entityKills["cinder-heart"]=1,e.entityLores["cinder-heart"]=1,e.entityEncounters["enemy-astral-sniper"]=14,e.entityKills["enemy-astral-sniper"]=9,e.itemPicks["goat-hoof"]=3,e.itemPicks["brittle-plate"]=2,e.itemPicks["glass-cannon"]=1,e.bySurvivor.runner={...kr(),runs:4,victories:1,defeats:3,kills:640,bossesDefeated:2,bestTime:268,fastestVictory:312,highestLevel:11,totalPlayTime:980,totalDamageDealt:42e3},e}function kr(){return{runs:0,victories:0,defeats:0,abandons:0,kills:0,bossesDefeated:0,bestTime:0,fastestVictory:null,highestLevel:1,totalPlayTime:0,totalDamageDealt:0}}function $(){return Pe||(Xt()?(Pe=Lm(),Pe):(Pe=_m($m()),Pe))}function Nm(){const e=Ga();return Pe=e,Zt(e),e}function Fm(e){if(xe("smoke")||Xt())return;const s=$();s.totalItemsCollected+=1,s.itemPicks[e]=(s.itemPicks[e]??0)+1,Zt(s)}function Bm(e){if(xe("smoke")||Xt())return!1;const s=$(),t=(s.entityLores[e]??0)>0;return s.entityLores[e]=(s.entityLores[e]??0)+1,Zt(s),!t}function it(e){const s=$();if(xe("smoke")||Xt())return s;let t=wi.get(e);t||(t={totalKills:0,fodderKills:0,eliteKills:0,bossKills:0,stagesCleared:0,maxVisitedStage:-1,killsByEntity:{},encountersByEntity:{}},wi.set(e,t));let n=!1;const a=Math.max(0,e.kills.total-t.totalKills),i=Math.max(0,e.kills.fodder-t.fodderKills),o=Math.max(0,e.kills.elite-t.eliteKills),r=Math.max(0,e.kills.boss-t.bossKills);(a>0||i>0||o>0||r>0)&&(s.totalKills+=a,s.fodderKills+=i,s.eliteKills+=o,s.bossKills+=r,t.totalKills=e.kills.total,t.fodderKills=e.kills.fodder,t.eliteKills=e.kills.elite,t.bossKills=e.kills.boss,n=!0);for(const[u,f]of Object.entries(e.killsByEntity)){const m=t.killsByEntity[u]??0,h=Math.max(0,f-m);h>0&&(s.entityKills[u]=(s.entityKills[u]??0)+h,t.killsByEntity[u]=f,n=!0)}for(const[u,f]of Object.entries(e.encountersByEntity)){const m=t.encountersByEntity[u]??0,h=Math.max(0,f-m);h>0&&(s.entityEncounters[u]=(s.entityEncounters[u]??0)+h,t.encountersByEntity[u]=f,n=!0)}const l=e.catalog.loop.stages,c=Math.min(e.stageIndex,l.length-1);if(c>t.maxVisitedStage){for(let u=t.maxVisitedStage+1;u<=c;u+=1){const f=l[u].id;s.stageVisits[f]=(s.stageVisits[f]??0)+1}t.maxVisitedStage=c,e.stageIndex>s.furthestStageIndex&&(s.furthestStageIndex=e.stageIndex),n=!0}const d=Math.min(e.stagesCleared,l.length);if(d>t.stagesCleared){for(let u=t.stagesCleared;u<d;u+=1){const f=l[u].id;s.stageClears[f]=(s.stageClears[f]??0)+1}s.stagesCleared+=d-t.stagesCleared,t.stagesCleared=d,n=!0}return n&&Zt(s),s}function qs(e,s=$()){return(s.stageVisits[e]??0)>0||(s.stageClears[e]??0)>0}function ot(e,s=$()){return(s.entityEncounters[e]??0)>0||(s.entityKills[e]??0)>0}function ua(e,s=$()){if(!e)return"Unlocked";let t=e.label;if(e.type==="stage-clear"){const n=E.loop.stages.find(a=>a.id===e.stageId);return n&&!qs(n.id,s)&&(t=t.split(n.name).join("???")),t}if(e.type==="boss-kill"){const n=E.entities.find(i=>i.id===e.entityId);n&&!ot(e.entityId,s)&&(t=t.split(n.name).join("???"));const a=e.stageId??E.loop.stages.find(i=>i.boss===e.entityId)?.id;if(a){const i=E.loop.stages.find(o=>o.id===a);i&&!qs(i.id,s)&&(t=t.split(i.name).join("???"))}return t}return t}function Ze(e,s=$()){const t=ua(e,s);if(!e)return{unlocked:!0,progress:"Unlocked",label:t};if(e.type==="stage-clear"){const a=e.count??1,i=s.stageClears[e.stageId]??0,o=E.loop.stages.find(l=>l.id===e.stageId),r=qs(e.stageId,s)?o?.name??e.stageId:"???";return{unlocked:i>=a,progress:a>1?`${Math.min(i,a)} / ${a} ${r} Clears`:i>=1?"Cleared":"0 / 1 Cleared",label:t}}if(e.type==="boss-kill"){const a=e.count??1,i=s.entityKills[e.entityId]??0;return{unlocked:i>=a,progress:a>1?`${Math.min(i,a)} / ${a} Slain`:i>=1?"Slain":"0 / 1 Slain",label:t}}if(e.type==="total-kills"){const a=s.totalKills;return{unlocked:a>=e.count,progress:`${Math.min(a,e.count).toLocaleString()} / ${e.count.toLocaleString()} Slain`,label:t}}if(e.type==="elite-kills"){const a=s.eliteKills;return{unlocked:a>=e.count,progress:`${Math.min(a,e.count).toLocaleString()} / ${e.count.toLocaleString()} Elites Slain`,label:t}}const n=s.victories;return{unlocked:n>=e.count,progress:`${Math.min(n,e.count)} / ${e.count} Transmutations`,label:t}}function Sr(e,s=$()){return Ze(e.unlock,s).unlocked}function ae(e,s=$()){return Ze(e.unlock,s).unlocked}function St(e=$()){const s=new Set;for(const t of E.items)Sr(t,e)&&s.add(t.id);return s}function Hm(e=$()){const s=new Set;for(const[t,n]of Object.entries(e.entityLores))n>0&&s.add(t);return s}function gs(e,s){const t=$();if(xe("smoke")||Xt()||_n.has(e))return t;if(s==="abandon"&&e.runTime<1&&e.kills.total===0)return _n.add(e),t;_n.add(e);const n=K(e),a=e.survivor.id,i=t.bySurvivor[a]??kr();t.totalRuns+=1,i.runs+=1,s==="victory"?(t.victories+=1,i.victories+=1,(t.fastestVictoryTime===null||e.runTime<t.fastestVictoryTime)&&(t.fastestVictoryTime=e.runTime),(i.fastestVictory===null||e.runTime<i.fastestVictory)&&(i.fastestVictory=e.runTime)):s==="defeat"?(t.defeats+=1,i.defeats+=1):(t.abandons+=1,i.abandons+=1),t.totalPlayTime+=e.runTime,i.totalPlayTime+=e.runTime,it(e),i.kills+=e.kills.total,i.bossesDefeated+=e.bossesDefeated,t.totalDamageDealt+=e.damageDealt,t.totalDamageTaken+=e.damageTaken,t.totalHealingDone+=e.healingDone,t.totalGemsCollected+=e.gemsCollected,t.totalLevelsGained+=Math.max(0,e.level-1),i.totalDamageDealt+=e.damageDealt,e.runTime>t.longestRunTime&&(t.longestRunTime=e.runTime),e.runTime>i.bestTime&&(i.bestTime=e.runTime),e.level>t.highestLevel&&(t.highestLevel=e.level),e.level>i.highestLevel&&(i.highestLevel=e.level),e.coefficient>t.highestCoefficient&&(t.highestCoefficient=e.coefficient),e.kills.total>t.mostKillsInRun&&(t.mostKillsInRun=e.kills.total),e.damageDealt>t.mostDamageInRun&&(t.mostDamageInRun=e.damageDealt),e.stageIndex>t.furthestStageIndex&&(t.furthestStageIndex=e.stageIndex),t.bySurvivor[a]=i;const o={timestamp:Date.now(),outcome:s,survivorId:a,stageId:n.id,stageName:n.name,runTime:e.runTime,level:e.level,coefficient:e.coefficient,kills:e.kills.total,bossesDefeated:e.bossesDefeated,damageDealt:Math.round(e.damageDealt),items:e.inventory.map(r=>({id:r.id,stacks:r.stacks}))};return t.recentRuns=[o,...t.recentRuns].slice(0,xr),Zt(t),t}function $m(){if(typeof localStorage>"u")return{};try{const e=localStorage.getItem(br);if(!e)return{};const s=JSON.parse(e);return s&&typeof s=="object"?s:{}}catch{return{}}}function Zt(e){if(!(typeof localStorage>"u"))try{localStorage.setItem(br,JSON.stringify(e))}catch{}}function _m(e){const s=Ga();return{version:vr,totalRuns:W(e.totalRuns),victories:W(e.victories),defeats:W(e.defeats),abandons:W(e.abandons),totalPlayTime:me(e.totalPlayTime),totalKills:W(e.totalKills),fodderKills:W(e.fodderKills),eliteKills:W(e.eliteKills),bossKills:W(e.bossKills),totalDamageDealt:me(e.totalDamageDealt),totalDamageTaken:me(e.totalDamageTaken),totalHealingDone:me(e.totalHealingDone),totalGemsCollected:W(e.totalGemsCollected),totalItemsCollected:W(e.totalItemsCollected),totalLevelsGained:W(e.totalLevelsGained),stagesCleared:W(e.stagesCleared),longestRunTime:me(e.longestRunTime),fastestVictoryTime:typeof e.fastestVictoryTime=="number"&&Number.isFinite(e.fastestVictoryTime)&&e.fastestVictoryTime>0?e.fastestVictoryTime:null,highestLevel:Math.max(1,W(e.highestLevel,1)),highestCoefficient:Math.max(1,me(e.highestCoefficient,1)),mostKillsInRun:W(e.mostKillsInRun),mostDamageInRun:me(e.mostDamageInRun),furthestStageIndex:W(e.furthestStageIndex),bySurvivor:Gm(e.bySurvivor),entityKills:at(e.entityKills),entityEncounters:at(e.entityEncounters),entityLores:at(e.entityLores),itemPicks:at(e.itemPicks),stageVisits:at(e.stageVisits),stageClears:at(e.stageClears),recentRuns:Array.isArray(e.recentRuns)?e.recentRuns.slice(0,xr):s.recentRuns}}function at(e){if(!e||typeof e!="object")return{};const s={};for(const[t,n]of Object.entries(e))typeof n=="number"&&Number.isFinite(n)&&n>0&&(s[t]=Math.floor(n));return s}function Gm(e){if(!e||typeof e!="object")return{};const s={};for(const[t,n]of Object.entries(e)){if(!n||typeof n!="object")continue;const a=n;s[t]={runs:W(a.runs),victories:W(a.victories),defeats:W(a.defeats),abandons:W(a.abandons),kills:W(a.kills),bossesDefeated:W(a.bossesDefeated),bestTime:me(a.bestTime),fastestVictory:typeof a.fastestVictory=="number"&&Number.isFinite(a.fastestVictory)&&a.fastestVictory>0?a.fastestVictory:null,highestLevel:Math.max(1,W(a.highestLevel,1)),totalPlayTime:me(a.totalPlayTime),totalDamageDealt:me(a.totalDamageDealt)}}return s}function me(e,s=0){return typeof e=="number"&&Number.isFinite(e)&&e>=0?e:s}function W(e,s=0){return typeof e=="number"&&Number.isFinite(e)&&e>=0?Math.floor(e):s}let ys=null,Gn=null;async function Om(){return ys||(Gn||(Gn=(async()=>{try{const e=await fetch("sprites/manifest.json");if(!e.ok)return null;const s=await e.json();return!s||typeof s!="object"||!("entities"in s)?null:s}catch{return null}})()),ys=await Gn,ys)}function vs(e,s,t=0,n=0,a,i){const o=e.getContext("2d");if(!o)throw new Error("2d context missing");o.imageSmoothingEnabled=!1,o.clearRect(0,0,e.width,e.height),a!==void 0&&i!==void 0?o.drawImage(s,t,n,a,i,0,0,e.width,e.height):o.drawImage(s,0,0,e.width,e.height)}function On(e){return new Promise(s=>{const t=new Image;t.onload=()=>s(t),t.onerror=()=>s(null),t.src=e})}function Qt(e,s,t,n){const a=t.includes("portrait"),i=a?em(s):tm(s),o=document.createElement("canvas");o.width=i.width,o.height=i.height,o.className=t,o.setAttribute("role","img"),o.setAttribute("aria-label",n),vs(o,i),e.appendChild(o);const r=je(s);return Om().then(async l=>{if(!o.isConnected)return;if(a){const p=l?.uiAtlas?.frames[`portrait-${s}`];if(p){const g=l?.uiAtlas?.src??"sprites/ui/atlas.png",v=await On(g);if(v&&o.isConnected){const y=p.idle;o.width=y.w,o.height=y.h,vs(o,v,y.x,y.y,y.w,y.h);return}}if(l?.ui?.includes(`portrait-${s}`)){const g=await On(`sprites/ui/portrait-${s}.png`);if(g&&o.isConnected){o.width=g.naturalWidth,o.height=g.naturalHeight,vs(o,g);return}}return}const c=l?.entities[r];if(!c||!o.isConnected)return;const d=await On(c.src);if(!d||!o.isConnected)return;const u=c.anims.idle?.frames[0]??0,f=Math.max(1,Math.floor(d.naturalWidth/c.frameWidth)),m=u%f*c.frameWidth,h=Math.floor(u/f)*c.frameHeight;o.width=c.frameWidth,o.height=c.frameHeight,vs(o,d,m,h,c.frameWidth,c.frameHeight)}),o}const Vm=[{id:"howto",label:"RITES OF MOTION",sub:"Stride, Aim, Survive",glyph:"⚶"},{id:"lore",label:"CHRONICLES",sub:"World, Vessels & Chambers",glyph:"☉"},{id:"entities",label:"BESTIARY",sub:"Dross, Elites & Guardians",glyph:"🜂"},{id:"reliquary",label:"RELIQUARY",sub:"Augmentations & Relics",glyph:"🜍"},{id:"stats",label:"LEDGER",sub:"Records & Run History",glyph:"☿"}],Um={speed:"Speed",maxHp:"Max HP",radius:"Vessel Size",damage:"Damage",cooldown:"Cooldown",critChance:"Crit Chance",critDamage:"Crit Damage",armor:"Armor",hazardResist:"Hazard Ward",hpRegen:"HP/s Regen",pickupRadius:"Essence Magnet",xpGain:"Essence XP",aoeRadius:"Area Size",projSpeed:"Projectile Speed",controlDuration:"Rite Duration",eliteDamage:"Elite & Boss Damage"};let he="howto",Et="work",Zs="all",bs=E.entities[0]?.id??"ember-mite",Qs="all",xs=E.items[0]?.id??"glass-cannon",$e="",Ne=!1,Ri=!1,Ti=()=>{};function Wm(e,s){Ti=e,s&&(he=s);const t=$();$e||($e=H().survivorId||E.world.defaultSurvivor);const n=E.survivors.find(i=>i.id===$e);(!n||!ae(n,t))&&($e=E.world.defaultSurvivor),Ne=!1;const a=document.getElementById("archives");a&&(Ri||(Ri=!0,document.getElementById("archives-back")?.addEventListener("click",()=>{T("close"),Ti()})),Er(),Cr(),Qe(),de(a))}function Er(){const e=document.getElementById("archives-ribbon");if(!e)return;const s=$(),t=E.entities.filter(o=>(s.entityEncounters[o.id]??0)>0||(s.entityKills[o.id]??0)>0).length,n=E.entities.filter(o=>(s.entityLores[o.id]??0)>0).length,a=E.items.filter(o=>(s.itemPicks[o.id]??0)>0).length,i=[["Workings",String(s.totalRuns)],["Transmutations",String(s.victories)],["Dross Slain",s.totalKills.toLocaleString()],["Bestiary",`${t} / ${E.entities.length}`],["Treatises",`${n} / ${E.entities.length}`],["Reliquary",`${a} / ${E.items.length}`]];e.replaceChildren();for(const[o,r]of i){const l=document.createElement("div");l.className="archives-ribbon-pill";const c=document.createElement("span");c.className="archives-ribbon-k",c.textContent=o;const d=document.createElement("span");d.className="archives-ribbon-v",d.textContent=r,l.append(c,d),e.appendChild(l)}}function Cr(){const e=document.getElementById("archives-nav");if(e){e.replaceChildren();for(const s of Vm){const t=document.createElement("button");t.type="button",t.className="archives-tab-btn",t.setAttribute("role","tab"),t.setAttribute("aria-selected",s.id===he?"true":"false"),t.dataset.active=s.id===he?"1":"0";const n=document.createElement("span");n.className="archives-tab-glyph",n.setAttribute("aria-hidden","true"),n.textContent=s.glyph;const a=document.createElement("span");a.className="archives-tab-copy";const i=document.createElement("span");i.className="archives-tab-label",i.textContent=s.label;const o=document.createElement("span");o.className="archives-tab-sub",o.textContent=s.sub,a.append(i,o);const r=document.createElement("span");r.className="archives-tab-arrow",r.setAttribute("aria-hidden","true"),t.append(n,a,r),t.addEventListener("click",()=>{he!==s.id&&(T("click"),he=s.id,Ne=!1,Cr(),Qe())}),e.appendChild(t)}}}function Qe(){const e=document.getElementById("archives-stage");e&&(e.replaceChildren(),e.dataset.tab=he,he==="howto"?e.appendChild(zm()):he==="lore"?e.appendChild(Ym()):he==="entities"?e.appendChild(Qm()):he==="reliquary"?e.appendChild(th()):e.appendChild(nh()),de(e))}function zm(){const e=document.createElement("div");e.className="archives-scroll-pane";const s=Oa("Rites of Motion","HOW TO SURVIVE THE GREAT WORK","Kite the dross. Aim your primary art. Charge the Transmutation Circle. Standing still is death.");e.appendChild(s);const t=document.createElement("section");t.className="archives-panel";const n=document.createElement("div");n.className="archives-panel-head";const a=document.createElement("h3");a.className="archives-section-title",a.textContent="I. VESSEL CONTROLS & RITE BINDINGS";const i=$(),o=document.createElement("div");o.className="archives-filter-bar";for(const g of E.survivors){const v=ae(g,i),y=document.createElement("button");y.type="button",y.className="archives-filter-pill",y.dataset.active=g.id===$e?"1":"0",y.disabled=!v,y.textContent=v?g.name:"🔒 ???",v&&y.addEventListener("click",()=>{T("click"),$e=g.id,Qe()}),o.appendChild(y)}n.append(a,o),t.appendChild(n);const r=E.survivors.find(g=>g.id===$e)??E.survivor(E.world.defaultSurvivor);t.appendChild(Xm(r)),e.appendChild(t);const l=document.createElement("section");l.className="archives-panel";const c=document.createElement("h3");c.className="archives-section-title",c.textContent="II. THE FOUR STAGES OF A WORKING",l.appendChild(c);const d=document.createElement("div");d.className="archives-cards-grid cols-2";const u=[{step:"01 · DISTILLATION",title:"Harvest Mercury Drops & Ascend",body:`Slay the lesser dross. Mercury Drops rise from the husks. Each ascent pauses the chamber and offers one of ${E.loop.levelChoices} tablets. Common and Uncommon grafts only fortify you. Rare and Lunar covenants cut both ways.`},{step:"02 · CONVERGENCE",title:"Channel the Transmutation Circle",body:"When the chamber has run its course, the Transmutation Circle appears. A chevron points you to the ring. Stand inside to charge it. Leave, and the seal cools until you return."},{step:"03 · THE GUARDIAN",title:"Shatter the Seal Guardian & Descend",body:"A full seal wakes the chamber’s Guardian. Slay it to tear open the Rift, or to finish the Great Work in the last chamber. Stand in the Rift until you descend."},{step:"04 · RISING PRESSURE",title:"The Chamber Grows Meaner",body:"The longer you linger, the worse the chamber becomes: Aether-warded elites, Noxious blights, and Astral Watchers. The swarm does not grow denser. It grows meaner."}];for(const g of u){const v=document.createElement("article");v.className="archives-info-card";const y=document.createElement("p");y.className="info-card-kicker",y.textContent=g.step;const b=document.createElement("h4");b.className="info-card-title",b.textContent=g.title;const x=document.createElement("p");x.className="info-card-body",x.textContent=g.body,v.append(y,b,x),d.appendChild(v)}l.appendChild(d),e.appendChild(l);const f=document.createElement("section");f.className="archives-panel";const m=document.createElement("h3");m.className="archives-section-title",m.textContent="III. CHAMBER PROPS, HAZARDS & ELITE WARDS",f.appendChild(m);const h=document.createElement("div");h.className="archives-cards-grid cols-2";const p=[{kind:"pillar",kicker:"SOLID COVER",title:"Kilns, Bollards & Monoliths",body:"Impassable stone and iron. Break a Watcher’s gaze, catch a spitter’s bolt, and cut a sightline when the horde closes."},{kind:"hazard",kicker:"GROUND HAZARD",title:"Slag Fissures & Brine Pools",body:"Corrosive ground that burns and slows you. Phase Step or Ash Step carries you across unharmed."},{kind:"volatile",kicker:"VOLATILE VESSELS",title:"Brimstone Urns & Rime Casks",body:"Strike an urn or cask, then step back. The blast hits dross and you alike. Rime casks also chill. Phase through the blast to skip the wound; the frost still bites."},{kind:"elite",kicker:"ELITE AFFLICTIONS",title:"Aether Wards & Noxious Blights",body:"Elites wear one of two marks. An Aether Ward is an azure shell you must break before the flesh. A Noxious blight is a viridian haze that slows your stride on contact and leaves an acid pool when the husk dies."}];for(const g of p){const v=document.createElement("article");v.className="archives-info-card with-art";const y=document.createElement("div");y.className="info-card-art",g.kind==="elite"?_a(y,"ember-chaser","archives-prop-canvas",g.title):Pm(y,g.kind,"cinder","archives-prop-canvas",g.title);const b=document.createElement("div");b.className="info-card-copy";const x=document.createElement("p");x.className="info-card-kicker",x.textContent=g.kicker;const k=document.createElement("h4");k.className="info-card-title",k.textContent=g.title;const C=document.createElement("p");C.className="info-card-body",C.textContent=g.body,b.append(x,k,C),v.append(y,b),h.appendChild(v)}return f.appendChild(h),e.appendChild(f),e}function Xm(e){const s=Rt(e,"primary"),t=Rt(e,"secondary"),n=Rt(e,"utility"),a=Rt(e,"special"),i=document.createElement("table");i.className="archives-table";const o=document.createElement("thead"),r=document.createElement("tr");for(const d of["Input","Rite / Action","Effect in the Chamber"]){const u=document.createElement("th");u.textContent=d,r.appendChild(u)}o.appendChild(r);const l=document.createElement("tbody"),c=[["WASD / Arrows","Stride","Move the vessel continuously across the chamber floor."],["Mouse Cursor","Sightline","Aim your primary, secondary, and ultimate arts."],["Hold LMB",s?`${s.name} (I)`:"Primary Art (I)",s?.hook??"Channel your primary weapon toward the cursor."],["Press RMB",t?`${t.name} (II · ${t.cooldown}s)`:"Secondary Art (II)",t?.hook??"Unleash your secondary tactical art."],["Shift / Space",n?`${n.name} (III · ${n.cooldown}s)`:"Utility Dash (III)",n?.hook??"Dash through foes and hazards unharmed."],["Press Q",a?`${a.name} (IV · ${a.cooldown}s)`:"Ultimate Rite (IV)",a?.hook??"Invoke your high-impact ultimate rite."],["1 / 2 / 3","Bind Augmentation","Select a tablet during vessel ascension (or use Arrow keys + Enter)."],["Stand in Ring","Channel / Descend","Hold inside the Transmutation Circle or Rift portal until charged."],["Esc / P","Pause Working","Pause the working, inspect tablets, or open The Archives."]];for(const[d,u,f]of c){const m=document.createElement("tr"),h=document.createElement("td");h.className="key-cell",h.textContent=d;const p=document.createElement("td");p.className="rite-cell",p.textContent=u;const g=document.createElement("td");g.textContent=f,m.append(h,p,g),l.appendChild(m)}return i.append(o,l),i}function Ym(){const e=document.createElement("div");e.className="archives-scroll-pane";const s=Oa("Hermetic Chronicles","APOCRYPHA OF THE GREAT WORK","Treatises recovered from the outer foundry, the frozen sea-locks, and the sealed glacial vault.");e.appendChild(s);const t=document.createElement("div");t.className="archives-filter-bar";const n=[{id:"work",label:"I. The Great Work"},{id:"vessels",label:"II. Vessels & Arts"},{id:"chambers",label:"III. The Three Chambers"},{id:"exchange",label:"IV. Law of Exchange"}];for(const a of n){const i=document.createElement("button");i.type="button",i.className="archives-filter-pill",i.dataset.active=a.id===Et?"1":"0",i.textContent=a.label,i.addEventListener("click",()=>{T("click"),Et=a.id,Qe()}),t.appendChild(i)}return e.appendChild(t),Et==="work"?e.appendChild(Km()):Et==="vessels"?e.appendChild(jm()):Et==="chambers"?e.appendChild(qm()):e.appendChild(Zm()),e}function Km(){const e=document.createElement("div");e.className="archives-cards-grid cols-2";const s=[{kicker:"FOLIO I · THE SHATTERED CRUCIBLE",title:"When the Magisterium Burned",paragraphs:["The Great Work was meant to distill immortal quintessence from base lead, sulfur, and sea-salt. Instead, the Grand Crucible cracked at the midnight conjunction, flooding the subterranean vaults with volatile humors.","The alchemists were consumed in the first flash of calcination. What remained in the ash were the failed transmutations—skittering clots of slag, brine-swollen husks, and the colossal furnace cores that now guard the lower seals."]},{kicker:"FOLIO II · ESSENCE & MERCURY",title:"The Circulation of Quicksilver",paragraphs:["No natural flesh can breathe the fumes of the Rifts. Only constructed or consecrated Vessels—animated by refined quicksilver—can walk the flagstones without dissolving into dross.","Every fallen abomination releases a bead of stolen Mercury (Essence). By drawing these beads back into its core, a Vessel ascends in potency, binding fractured hermetic tablets directly into its frame."]},{kicker:"FOLIO III · TRANSMUTATION CIRCLES",title:"Seals of Passage",paragraphs:["Each chamber is locked by a heavy Transmutation Circle etched into the stone. Only when the chamber’s temporal alignment arrives can a Vessel stand inside the hexagram and channel its own vital heat into the ring.","The channeling acts as a beacon: the chamber’s hordes converge on the circle, and the Seal Guardian awakens to crush the intruder before the Rift can tear open."]},{kicker:"FOLIO IV · THE THREE OPERATIONS",title:"Nigredo, Albedo, Rubedo",paragraphs:["The descent follows the three classical stages of hermetic transmutation: first Nigredo in the blackened ash of the Cinder Yard; second Albedo in the white salt-frost of the Rime Dock; and finally Rubedo in the deep Glacial Tomb.","Only by slaying the Frost Emperor at the bottom of the third seal is the Great Work stabilized and the transmutation made whole."]}];for(const t of s){const n=document.createElement("article");n.className="archives-lore-parchment";const a=document.createElement("p");a.className="info-card-kicker",a.textContent=t.kicker;const i=document.createElement("h4");i.className="lore-parchment-title",i.textContent=t.title,n.append(a,i);for(const o of t.paragraphs){const r=document.createElement("p");r.className="lore-parchment-text",r.textContent=o,n.appendChild(r)}e.appendChild(n)}return e}function jm(){const e=document.createElement("div");e.className="archives-stack";const s=$();for(const t of E.survivors){const n=s.bySurvivor[t.id],a=Ze(t.unlock,s),i=a.unlocked,o=document.createElement("section");o.className=i?"archives-panel vessel-lore-card":"archives-panel vessel-lore-card is-locked",o.dataset.seen=i?"1":"0";const r=document.createElement("div");r.className="vessel-lore-top";const l=document.createElement("div");l.className="vessel-lore-art",l.dataset.seen=i?"1":"0",Qt(l,t.id,"vessel-lore-canvas",i?t.name:"Sealed Vessel");const c=document.createElement("div");c.className="vessel-lore-meta";const d=document.createElement("p");d.className="info-card-kicker",d.textContent=i?`${(t.title??"The Vessel").toUpperCase()} · VESSEL DOSSIER`:"SEALED VESSEL · UNCONSECRATED FRAME";const u=document.createElement("h3");u.className="vessel-lore-name",u.textContent=i?t.name.toUpperCase():"???";const f=document.createElement("p");f.className=i?"vessel-lore-text":"vessel-lore-text hall-lore is-locked-lore",f.textContent=i?t.lore??"":`Vessel Sealed — Requirement: ${a.label} (${a.progress}).`;const m=document.createElement("div");m.className="archives-stat-chips";const h=i?[["Vitality",`${t.stats.maxHp} HP`],["Stride",String(t.stats.speed)],["Workings",String(n?.runs??0)],["Victories",String(n?.victories??0)]]:[["Vitality","???"],["Stride","???"],["Status",`SEALED (${a.progress})`]];for(const[p,g]of h)m.appendChild(ee(p,g));if(c.append(d,u,f,m),r.append(l,c),o.appendChild(r),i){const p=document.createElement("div");p.className="vessel-skills-codex";const g=["primary","secondary","utility","special"],v={primary:"I · LMB",secondary:"II · RMB",utility:"III · Shift / Space",special:"IV · Q"};for(const y of g){const b=Rt(t,y);if(!b)continue;const x=document.createElement("div");x.className="codex-skill-card";const k=document.createElement("div");k.className="codex-skill-icon-wrap";const C=Na(b.id,b.name,"codex-skill-icon",La);C.addEventListener("error",()=>C.remove()),k.appendChild(C);const M=document.createElement("div");M.className="codex-skill-body";const w=document.createElement("div");w.className="codex-skill-head";const R=document.createElement("strong");R.textContent=b.name;const D=document.createElement("span");D.className="codex-skill-meta",D.textContent=`${v[y]} · ${b.cooldown}s CD`,w.append(R,D);const L=document.createElement("p");L.className="codex-skill-hook",L.textContent=b.hook??"";const U=document.createElement("p");U.className="codex-skill-lore",U.textContent=b.lore?`"${b.lore}"`:"",M.append(w,L,U),x.append(k,M),p.appendChild(x)}o.appendChild(p)}e.appendChild(o)}return e}function qm(){const e=document.createElement("div");e.className="archives-stack";const s=$();return E.loop.stages.forEach((t,n)=>{const a=s.stageVisits[t.id]??0,i=s.stageClears[t.id]??0,o=a>0||i>0,r=document.createElement("section");r.className=o?"archives-panel chamber-lore-card":"archives-panel chamber-lore-card is-unseen",r.dataset.seen=o?"1":"0";const l=document.createElement("div");l.className="chamber-lore-head";const c=document.createElement("div"),d=document.createElement("p");d.className="info-card-kicker",d.textContent=o?t.kicker??`Chamber ${n+1}`:`CHAMBER ${n+1} · UNCHARTERED SEAL`;const u=document.createElement("h3");u.className="vessel-lore-name",u.textContent=o?`${n+1}. ${t.name.toUpperCase()}`:`${n+1}. ???`,c.append(d,u);const f=document.createElement("div");f.className="archives-stat-chips",o?f.append(ee("Visited",String(a)),ee("Cleared",String(i))):f.append(ee("Status","UNENCOUNTERED")),l.append(c,f);const m=document.createElement("p");m.className=o?"vessel-lore-text":"vessel-lore-text hall-lore is-locked-lore",m.textContent=o?t.lore??"":"Uncharted Chamber — Descend through the Rifts to unseal this chamber’s chronicle and survey its hazards.";const h=document.createElement("div");h.className="archives-cards-grid cols-2";const p=document.createElement("div");p.className="archives-info-card",p.dataset.seen=o?"1":"0";const g=document.createElement("p");g.className="info-card-kicker",g.textContent="WHO WALKS HERE";const v=document.createElement("p");if(v.className="info-card-body",o){const k=ot(t.fodder,s)?E.entity(t.fodder).name:"???",C=t.ranged?ot(t.ranged,s)?E.entity(t.ranged).name:"???":"None",M=t.sniper?ot(t.sniper,s)?E.entity(t.sniper).name:"???":"None",w=ot(t.elite,s)?E.entity(t.elite).name:"???",R=ot(t.boss,s)?E.entity(t.boss).name:"???";v.textContent=`Hunts you: ${k}. Spits from afar: ${C}. Lances from the rim: ${M}. Warden: ${w}. Guards the seal: ${R}.`}else v.textContent="Hunts you: ??? · Spits from afar: ??? · Guards the seal: ???";p.append(g,v);const y=document.createElement("div");y.className="archives-info-card",y.dataset.seen=o?"1":"0";const b=document.createElement("p");b.className="info-card-kicker",b.textContent="IN THE CHAMBER";const x=document.createElement("p");if(x.className="info-card-body",o){const k=E.obstacles.biomes[t.id];x.textContent=k?`${k.pillar}. ${k.hazard}. ${k.volatile}.`:"Stone, slag, and vessels waiting to burst."}else x.textContent="???. ???. ???.";y.append(b,x),h.append(p,y),r.append(l,m,h),e.appendChild(r)}),e}function Zm(){const e=document.createElement("div");e.className="archives-cards-grid cols-2";const s=[{rarity:"common",title:"Common Tablets · Base Matter",desc:"Pure grafts: tendons, slag plating, lead plumbum, and cinnabar leeches. They carry no drawback and form the backbone of every working."},{rarity:"uncommon",title:"Uncommon Tablets · Refined Humors",desc:"Quicksilver draughts, spasmodic nerves, and bellows hearts. Scarcer distillations that hasten your rites without corrupting the vessel."},{rarity:"rare",title:"Rare Tablets · Volatile Bargains",desc:"Double-edged masterworks such as Vitriol Veins, Parasitic Alembic, and the Astrologer’s Ocular. Power or haste, paid in vitality, stride, or a swollen frame."},{rarity:"lunar",title:"Lunar Covenants · Forbidden Heresy",desc:"The Pale Moon Covenant. An unforgiven heresy against the Great Work: ruin against guardians and elite horrors, a brittle shell, and insight that will not take."}];for(const t of s){const n=document.createElement("article");n.className=`archives-info-card rarity-border-${t.rarity}`;const a=document.createElement("p");a.className=`info-card-kicker rarity-text-${t.rarity}`,a.textContent=t.rarity.toUpperCase();const i=document.createElement("h4");i.className="info-card-title",i.textContent=t.title;const o=document.createElement("p");o.className="info-card-body",o.textContent=t.desc,n.append(a,i,o),e.appendChild(n)}return e}function Qm(){const e=document.createElement("div");e.className="archives-split-layout";const s=document.createElement("div");s.className="archives-split-left";const t=document.createElement("div");t.className="archives-filter-bar";const n=[{id:"all",label:`All (${E.entities.length})`},{id:"fodder",label:"Denizens"},{id:"boss",label:"Guardians"}];for(const c of n){const d=document.createElement("button");d.type="button",d.className="archives-filter-pill",d.dataset.active=c.id===Zs?"1":"0",d.textContent=c.label,d.addEventListener("click",()=>{T("click"),Zs=c.id;const u=Ai();!u.some(f=>f.id===bs)&&u[0]&&(bs=u[0].id),Qe()}),t.appendChild(d)}s.appendChild(t);const a=$(),i=Ai(),o=document.createElement("div");o.className="archives-entity-grid";const r=document.createElement("aside");r.className="archives-dossier";const l=E.entities.find(c=>c.id===bs)??i[0]??E.entities[0];Ii(r,l,a);for(const c of i){const d=a.entityKills[c.id]??0,u=(a.entityEncounters[c.id]??0)>0||d>0,f=(a.entityLores[c.id]??0)>0,m=Mr(c),h=document.createElement("button");h.type="button",h.className=`archives-entity-card role-${c.role}`,h.dataset.active=c.id===l.id?"1":"0",h.dataset.seen=u?"1":"0",h.dataset.lore=f?"1":"0";const p=document.createElement("div");p.className="entity-card-art",_a(p,c.id,"entity-card-canvas",u?c.name:"Unencountered Entity");const g=document.createElement("span");g.className=`entity-role-badge archetype-badge-${m.key}`,g.textContent=u?m.label.toUpperCase():"???";const v=document.createElement("span");v.className="entity-card-name",v.textContent=u?c.name:"???";const y=document.createElement("span");y.className="entity-card-tally",y.textContent=u?`Slain: ${d.toLocaleString()}${f?" · ☉":""}`:"Unencountered",h.append(g,p,v,y),h.addEventListener("click",()=>{T("click"),bs=c.id,o.querySelectorAll(".archives-entity-card").forEach(b=>{b.dataset.active="0"}),h.dataset.active="1",Ii(r,c,a)}),o.appendChild(h)}return s.appendChild(o),e.append(s,r),e}function Mr(e){return e.role==="boss"||e.ai.type==="boss"?{key:"guardian",label:"Guards the seal"}:e.ai.type==="sniper"?{key:"sniper",label:"Lances from the rim"}:e.ai.type==="ranged"?{key:"ranged",label:"Spits from afar"}:{key:"chaser",label:"Hunts you"}}function Ai(){return Zs==="all"?E.entities:Zs==="boss"?E.entities.filter(e=>e.role==="boss"):E.entities.filter(e=>e.role!=="boss")}function Ii(e,s,t){const n=t.entityKills[s.id]??0,a=Math.max(n,t.entityEncounters[s.id]??0),i=a>0||n>0,o=(t.entityLores[s.id]??0)>0,r=document.createElement("p");r.className="dossier-header",r.textContent=i?s.role==="boss"?"SEAL GUARDIAN":"CHAMBER DENIZEN":"UNENCOUNTERED ENTITY";const l=document.createElement("h2");l.className="hall-name",l.textContent=i?s.name.toUpperCase():"???";const c=document.createElement("p");c.className="archives-dossier-subtitle",c.textContent=i?s.title??"":"Uncharted Dross of the Rifts";const d=document.createElement("div");d.className="archives-dossier-pedestal",d.dataset.seen=i?"1":"0",_a(d,s.id,"archives-dossier-canvas",i?s.name:"Unencountered Entity");const u=document.createElement("div");u.className="archives-dossier-ledger";const f=o?"RECOVERED":"UNRECOVERED";u.innerHTML=`
    <div class="archives-dossier-ledger-item"><span>ENCOUNTERED:</span><strong>${a.toLocaleString()}</strong></div>
    <div class="archives-dossier-ledger-item"><span>SLAIN:</span><strong>${n.toLocaleString()}</strong></div>
    <div class="archives-dossier-ledger-item"><span>TREATISE:</span><strong>${f}</strong></div>
  `;const m=document.createElement("p");i?o?(m.className="hall-lore",m.textContent=s.lore):(m.className="hall-lore is-locked-lore",m.textContent="Slay it to recover its treatise."):(m.className="hall-lore is-locked-lore",m.textContent="Encounter it in the Rifts.");const h=document.createElement("div");h.className="hall-stats-grid";const p=Jm(s.id,t),g=Mr(s),v=i?[["♥",`VITALITY: ${s.stats.maxHp}`],["◎",`CHAMBER: ${p}`],["⟁",`KIND: ${g.label.toUpperCase()}`]]:[["♥","VITALITY: ???"],["◎","CHAMBER: ???"],["⟁","KIND: ???"]];for(const[b,x]of v){const k=document.createElement("div");k.className="hall-stat-cell";const C=document.createElement("span");C.className="hall-stat-icon",C.textContent=b;const M=document.createElement("span");M.className="hall-stat-text",M.textContent=x,k.append(C,M),h.appendChild(k)}const y=document.createElement("div");y.className="archives-dossier-note",y.textContent=i?eh(s):"Unknown until encountered in the Rifts.",e.replaceChildren(r,l,c,d,u,m,h,y)}function Jm(e,s){const t=[];let n=!0;for(const a of E.loop.stages)(a.fodder===e||a.ranged===e||a.sniper===e||a.elite===e||a.boss===e)&&(qs(a.id,s)?t.push(a.name):(t.push("???"),n=!1));return n&&t.length===E.loop.stages.length?"ALL CHAMBERS":t.length>0?t.join(", ").toUpperCase():"THE RIFTS"}function eh(e){if(e.ai.type==="boss"){const s=e.ai.attacks.map(n=>n.name).filter(n=>!!n);return`${s.length>0?`Its rites: ${s.join(", ")}. `:""}Wakes when the Transmutation Circle is full. Slaying it opens the Rift, or completes the Great Work in the last chamber.`}return e.ai.type==="ranged"?"Keeps its distance and spits. Do not stand still.":e.ai.type==="sniper"?"Draws a beam from the rim. Hide behind kilns, bollards, or monoliths.":"Runs straight at you."}function th(){const e=document.createElement("div");e.className="archives-split-layout";const s=document.createElement("div");s.className="archives-split-left";const t=document.createElement("div");t.className="archives-filter-bar";const n=[{id:"all",label:`All (${E.items.length})`},{id:"common",label:"Common"},{id:"uncommon",label:"Uncommon"},{id:"rare",label:"Rare"},{id:"lunar",label:"Lunar"}];for(const c of n){const d=document.createElement("button");d.type="button",d.className="archives-filter-pill",d.dataset.active=c.id===Qs?"1":"0",d.textContent=c.label,d.addEventListener("click",()=>{T("click"),Qs=c.id;const u=Di();!u.some(f=>f.id===xs)&&u[0]&&(xs=u[0].id),Qe()}),t.appendChild(d)}s.appendChild(t);const a=$(),i=Di(),o=document.createElement("div");o.className="archives-entity-grid";const r=document.createElement("aside");r.className="archives-dossier";const l=E.items.find(c=>c.id===xs)??i[0]??E.items[0];Pi(r,l,a);for(const c of i){const d=a.itemPicks[c.id]??0,u=d>0,f=Ze(c.unlock,a),m=document.createElement("button");m.type="button",m.className=`archives-entity-card rarity-border-${c.rarity}`,m.dataset.active=c.id===l.id?"1":"0",m.dataset.seen=u?"1":"0",m.dataset.unlocked=f.unlocked?"1":"0";const h=document.createElement("span");h.className=`entity-role-badge rarity-text-${c.rarity}`,h.textContent=c.rarity.toUpperCase();const p=document.createElement("div");p.className="entity-card-art";const g=Xe(c.id,u?c.name:"Unencountered Relic","reliquary-card-icon",64);g.addEventListener("error",()=>{g.remove();const b=document.createElement("span");b.className="aug-card-fallback",b.textContent=u?c.name.slice(0,1).toUpperCase():"?",p.appendChild(b)}),p.appendChild(g);const v=document.createElement("span");v.className="entity-card-name",v.textContent=u?c.name:"???";const y=document.createElement("span");y.className="entity-card-tally",y.textContent=u?`Bound: ×${d}`:f.unlocked?"Unencountered":"Sealed",m.append(h,p,v,y),m.addEventListener("click",()=>{T("click"),xs=c.id,o.querySelectorAll(".archives-entity-card").forEach(b=>{b.dataset.active="0"}),m.dataset.active="1",Pi(r,c,a)}),o.appendChild(m)}return s.appendChild(o),e.append(s,r),e}function Di(){return Qs==="all"?E.items:E.items.filter(e=>e.rarity===Qs)}function Pi(e,s,t){const n=t.itemPicks[s.id]??0,a=n>0,i=Ze(s.unlock,t),o=document.createElement("p");o.className="dossier-header",o.textContent=a?`${s.rarity.toUpperCase()} AUGMENTATION`:i.unlocked?"UNENCOUNTERED AUGMENTATION":"SEALED AUGMENTATION";const r=document.createElement("h2");r.className="hall-name",r.textContent=a?s.name.toUpperCase():"???";const l=document.createElement("div");l.className="archives-dossier-pedestal",l.dataset.seen=a?"1":"0";const c=Xe(s.id,a?s.name:"Unencountered Relic","archives-dossier-item-icon",Qo);c.addEventListener("error",()=>c.remove()),l.appendChild(c);const d=document.createElement("div");d.className="archives-dossier-ledger";const u=a?"BOUND":i.unlocked?"UNBOUND":"SEALED";d.innerHTML=`
    <div class="archives-dossier-ledger-item"><span>TIMES BOUND:</span><strong>×${n.toLocaleString()}</strong></div>
    <div class="archives-dossier-ledger-item"><span>STATUS:</span><strong>${u}</strong></div>
  `;const f=document.createElement("div");if(f.className="archives-dossier-hooks",a)for(const h of s.hooks){const p=document.createElement("span"),g=sh(h);p.className=g.up?"hook-up":"hook-down",p.textContent=g.text.toUpperCase(),f.appendChild(p)}else{const h=document.createElement("span");h.className="hook-down",h.textContent="ALCHEMICAL PROPERTIES UNCHARTED (???)",f.appendChild(h)}const m=document.createElement("p");a?(m.className="hall-lore",m.textContent=s.lore):!i.unlocked&&s.unlock?(m.className="hall-lore is-locked-lore",m.textContent=`Sealed Relic — Requirement: ${i.label} (${i.progress}).`):(m.className="hall-lore is-locked-lore",m.textContent="Unbound Augmentation — Bind this tablet during Vessel Ascension in the Rifts to inscribe its record."),e.replaceChildren(o,r,l,d,f,m)}function sh(e){const s=e.value>0?"+":"";if(e.op==="on-kill")return{text:`${s}${e.value} HP on kill`,up:e.value>0};if(e.op==="on-crit")return{text:`-${e.value}s CD on crit`,up:!0};const t=e.op==="pct"?`${s}${Math.round(e.value*100)}%`:`${s}${e.value}`,n=e.stat==="radius"||e.stat==="cooldown",a=e.value===0?!0:n?e.value<0:e.value>0;return{text:`${t} ${Um[e.stat]}`,up:a}}function nh(){const e=document.createElement("div");e.className="archives-scroll-pane";const s=$(),t=document.createElement("div");t.className="archives-banner-row",t.appendChild(Oa("Ledger of Workings","PERSISTENT TRANSMUTATION RECORDS","Every vessel cast into the Rifts is inscribed here across sessions."));const n=document.createElement("button");n.type="button",n.className=Ne?"plaque-btn purge-btn is-confirm":"plaque-btn purge-btn",n.dataset.uiSprite="btn-plaque";const a=document.createElement("span");a.className="plaque-label",a.textContent=Ne?"CONFIRM PURGE?":"PURGE LEDGER",n.appendChild(a),n.addEventListener("click",()=>{if(!Ne){T("click"),Ne=!0,n.classList.add("is-confirm"),a.textContent="CONFIRM PURGE?";return}T("error"),Nm(),Ne=!1,Er(),Qe()}),t.appendChild(n),e.appendChild(t);const i=s.totalRuns>0?`${Math.round(s.victories/s.totalRuns*100)}%`:"0%",o=E.loop.stages[Math.min(s.furthestStageIndex,E.loop.stages.length-1)]?.name??"Cinder Yard",r=document.createElement("section");r.className="archives-panel";const l=document.createElement("h3");l.className="archives-section-title",l.textContent="I. LIFETIME TOTALS & HALL OF RECORDS",r.appendChild(l);const c=document.createElement("div");c.className="ledger-metrics-grid";const d=[["Total Workings",String(s.totalRuns),`${s.victories} Won · ${s.defeats} Shattered · ${s.abandons} Abandoned`],["Completion Rate",i,`${s.stagesCleared} Chambers Cleared`],["Time in the Rifts",Q(s.totalPlayTime),`Longest Working: ${Q(s.longestRunTime)}`],["Fastest Transmutation",s.fastestVictoryTime!==null?Q(s.fastestVictoryTime):"—",`Furthest Chamber: ${o}`],["Total Dross Slain",s.totalKills.toLocaleString(),`${s.fodderKills.toLocaleString()} Dross · ${s.eliteKills.toLocaleString()} Elites · ${s.bossKills.toLocaleString()} Guardians`],["Most Slain (Single Run)",s.mostKillsInRun.toLocaleString(),`Highest Ascension: Lv ${s.highestLevel}`],["Total Damage Dealt",Math.round(s.totalDamageDealt).toLocaleString(),`Peak Run Damage: ${Math.round(s.mostDamageInRun).toLocaleString()}`],["Total Damage Taken",Math.round(s.totalDamageTaken).toLocaleString(),`Vitality Siphoned: +${Math.round(s.totalHealingDone).toLocaleString()} HP`],["Augmentations Bound",s.totalItemsCollected.toLocaleString(),`${s.totalGemsCollected.toLocaleString()} Mercury Drops Harvested`],["Total Ascensions",s.totalLevelsGained.toLocaleString(),"Bound across every working"]];for(const[g,v,y]of d){const b=document.createElement("div");b.className="ledger-metric-card";const x=document.createElement("span");x.className="ledger-metric-k",x.textContent=g;const k=document.createElement("strong");k.className="ledger-metric-v",k.textContent=v;const C=document.createElement("span");C.className="ledger-metric-sub",C.textContent=y,b.append(x,k,C),c.appendChild(b)}r.appendChild(c),e.appendChild(r);const u=document.createElement("section");u.className="archives-panel";const f=document.createElement("h3");f.className="archives-section-title",f.textContent="II. PERFORMANCE BY VESSEL",u.appendChild(f);const m=document.createElement("div");m.className="archives-cards-grid cols-2";for(const g of E.survivors){const v=s.bySurvivor[g.id],y=Ze(g.unlock,s),b=y.unlocked,x=v?.runs??0,k=v?.victories??0,C=document.createElement("div");C.className="archives-info-card with-art ledger-vessel-card",C.dataset.seen=b?"1":"0";const M=document.createElement("div");M.className="info-card-art",M.dataset.seen=b?"1":"0",Qt(M,g.id,"vessel-art portrait-art",b?g.name:"Sealed Vessel");const w=document.createElement("div");w.className="info-card-copy";const R=document.createElement("p");R.className="info-card-kicker",R.textContent=b?(g.title??"Vessel").toUpperCase():"SEALED VESSEL";const D=document.createElement("h4");D.className="info-card-title",D.textContent=b?g.name:"???",w.append(R,D);const L=document.createElement("div");L.className="archives-stat-chips ledger-vessel-stats",b?L.append(ee("Workings",String(x)),ee("Victories",String(k)),ee("Slain",(v?.kills??0).toLocaleString()),ee("Best Time",Q(v?.bestTime??0)),ee("Fastest Win",v?.fastestVictory?Q(v.fastestVictory):"—"),ee("Peak Level",`Lv ${v?.highestLevel??1}`)):L.append(ee("Status",`SEALED (${y.progress})`),ee("Rite",y.label)),C.append(M,w,L),m.appendChild(C)}u.appendChild(m),e.appendChild(u);const h=document.createElement("section");h.className="archives-panel";const p=document.createElement("h3");if(p.className="archives-section-title",p.textContent="III. CHRONICLE OF RECENT WORKINGS",h.appendChild(p),s.recentRuns.length===0){const g=document.createElement("p");g.className="archives-empty-note",g.textContent="No workings recorded yet. Commence a transmutation to inscribe the ledger.",h.appendChild(g)}else{const g=document.createElement("div");g.className="ledger-history-list";for(const v of s.recentRuns){const y=document.createElement("div");y.className=`ledger-history-row outcome-${v.outcome}`;const b=document.createElement("span");b.className=`outcome-badge badge-${v.outcome}`,b.textContent=v.outcome==="victory"?"TRANSMUTED":v.outcome==="defeat"?"SHATTERED":"ABANDONED";const x=E.survivors.find(R=>R.id===v.survivorId)?.name??v.survivorId,k=document.createElement("div");k.className="history-summary";const C=document.createElement("strong");C.textContent=`${x} · ${v.stageName}`;const M=document.createElement("span");M.textContent=`Duration ${Q(v.runTime)} · Lv ${v.level} · ${v.kills} Slain · ${v.damageDealt.toLocaleString()} Dmg`,k.append(C,M);const w=document.createElement("div");w.className="history-items-strip";for(const R of v.items)try{const D=E.item(R.id);w.appendChild(hn({id:D.id,name:D.name,stacks:R.stacks,rarity:D.rarity},"item-chip history-chip",24))}catch{}y.append(b,k,w),g.appendChild(y)}h.appendChild(g)}return e.appendChild(h),e}function Oa(e,s,t){const n=document.createElement("header");n.className="archives-section-banner";const a=document.createElement("p");a.className="info-card-kicker",a.textContent=e.toUpperCase();const i=document.createElement("h2");i.className="archives-banner-title",i.textContent=s;const o=document.createElement("p");return o.className="archives-banner-sub",o.textContent=t,n.append(a,i,o),n}function ee(e,s){const t=document.createElement("span");t.className="archives-stat-chip";const n=document.createElement("span");n.className="chip-k",n.textContent=`${e}:`;const a=document.createElement("strong");return a.className="chip-v",a.textContent=s,t.append(n,a),t}function Rt(e,s){const t=e.skills[s];return t?E.skill(t):null}const Li="sprites/env/atlas.png",fe={x:5,y:720,w:320,h:315},ah=`
attribute vec2 a_pos;
varying vec2 v_uv;
void main() {
  v_uv = (a_pos + 1.0) * 0.5;
  v_uv.y = 1.0 - v_uv.y;
  gl_Position = vec4(a_pos, 0.0, 1.0);
}
`,ih=`
precision mediump float;
varying vec2 v_uv;
uniform sampler2D u_tex;
uniform float u_time;

vec4 sampleTex(vec2 uv) {
  if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
    return vec4(0.0);
  }
  return texture2D(u_tex, uv);
}

float getEmissive(vec4 col) {
  if (col.a < 0.05) return 0.0;
  // Isolate only hot rune/ember pixels; keep dark stone (r ~= b) at 0.0
  float warmth = max(col.r - col.b * 0.85, 0.0);
  return smoothstep(0.28, 0.68, warmth) * col.a;
}

void main() {
  vec2 center = vec2(0.5);
  vec2 d = v_uv - center;

  // Hypnotic occult slow rotation (~72s period)
  float angle = u_time * 0.087;
  float ca = cos(angle);
  float sa = sin(angle);
  vec2 rotUv = vec2(d.x * ca - d.y * sa, d.x * sa + d.y * ca) + center;

  vec4 base = sampleTex(rotUv);
  if (base.a < 0.03) {
    gl_FragColor = vec4(0.0);
    return;
  }
  float selfEmissive = getEmissive(base);

  // Slow hypnotic in-place blinking of the carved runes (~5.2s cycle)
  // Pulses smoothly in place without radiating outward into surroundings
  float wave = sin(u_time * 1.2);
  float blink = smoothstep(-0.4, 0.85, wave);
  float pulse = 0.12 + 0.88 * blink;

  // Dark Hermetic palette: deep smoldering ruby -> molten gold amber
  vec3 deepEmber = vec3(0.50, 0.08, 0.02);
  vec3 brightAmber = vec3(0.96, 0.56, 0.14);
  vec3 runeColor = mix(deepEmber, brightAmber, pulse);

  // Dark grounded stone body
  vec3 darkStone = vec3(base.r * 0.72, base.g * 0.62, base.b * 0.68);

  // Inscribed runes blink brightly on stone; stone remains dark and quiet
  vec3 finalRgb = mix(darkStone, runeColor, selfEmissive);

  // Strict premultiplied alpha clamping: RGB never exceeds Alpha, eliminating any boundary halo
  finalRgb = clamp(finalRgb * base.a, 0.0, base.a);

  gl_FragColor = vec4(finalRgb, base.a);
}
`;function Ni(e,s,t){const n=e.createShader(s);return n?(e.shaderSource(n,t),e.compileShader(n),e.getShaderParameter(n,e.COMPILE_STATUS)?n:(console.warn("[CinderCircle] Shader compile error:",e.getShaderInfoLog(n)),e.deleteShader(n),null)):null}function oh(e){const s=document.createElement("canvas");s.className="cinder-circle-canvas",s.width=512,s.height=512,s.setAttribute("aria-hidden","true"),e.replaceChildren(s);let t=null;try{t=s.getContext("webgl",{alpha:!0,premultipliedAlpha:!0,antialias:!0,preserveDrawingBuffer:!0})}catch{t=null}let n=!1,a=0,i=0,o=!1,r=!1;if(!t){const b=s.getContext("2d"),x=new Image;return x.onload=()=>{!b||o||(b.clearRect(0,0,512,512),b.drawImage(x,fe.x,fe.y,fe.w,fe.h,46,50,420,413))},x.src=Li,{start(){},stop(){},destroy(){o=!0,s.remove()}}}const l=Ni(t,t.VERTEX_SHADER,ah),c=Ni(t,t.FRAGMENT_SHADER,ih);if(!l||!c)return{start(){},stop(){},destroy(){o=!0,s.remove()}};const d=t.createProgram();if(!d)return{start(){},stop(){},destroy(){o=!0,s.remove()}};if(t.attachShader(d,l),t.attachShader(d,c),t.linkProgram(d),!t.getProgramParameter(d,t.LINK_STATUS))return console.warn("[CinderCircle] Program link error:",t.getProgramInfoLog(d)),{start(){},stop(){},destroy(){o=!0,s.remove()}};t.useProgram(d);const u=t.createBuffer();t.bindBuffer(t.ARRAY_BUFFER,u),t.bufferData(t.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),t.STATIC_DRAW);const f=t.getAttribLocation(d,"a_pos");t.enableVertexAttribArray(f),t.vertexAttribPointer(f,2,t.FLOAT,!1,0,0);const m=t.getUniformLocation(d,"u_tex"),h=t.getUniformLocation(d,"u_time");t.uniform1i(m,0),t.enable(t.BLEND),t.blendFunc(t.ONE,t.ONE_MINUS_SRC_ALPHA),t.viewport(0,0,512,512);const p=t.createTexture(),g=new Image;g.onload=()=>{if(o||!t)return;const b=document.createElement("canvas");b.width=512,b.height=512;const x=b.getContext("2d");if(x){const C=fe.h/fe.w*420,M=92/2,w=(512-C)/2;x.imageSmoothingEnabled=!0,x.drawImage(g,fe.x,fe.y,fe.w,fe.h,M,w,420,C)}t.bindTexture(t.TEXTURE_2D,p),t.texParameteri(t.TEXTURE_2D,t.TEXTURE_WRAP_S,t.CLAMP_TO_EDGE),t.texParameteri(t.TEXTURE_2D,t.TEXTURE_WRAP_T,t.CLAMP_TO_EDGE),t.texParameteri(t.TEXTURE_2D,t.TEXTURE_MIN_FILTER,t.LINEAR),t.texParameteri(t.TEXTURE_2D,t.TEXTURE_MAG_FILTER,t.LINEAR),t.texImage2D(t.TEXTURE_2D,0,t.RGBA,t.RGBA,t.UNSIGNED_BYTE,b),r=!0,v(0)},g.src=Li;function v(b){if(!t||!r||o)return;i===0&&(i=b);const x=(b-i)/1e3;t.viewport(0,0,512,512),t.useProgram(d),t.bindBuffer(t.ARRAY_BUFFER,u),t.enableVertexAttribArray(f),t.vertexAttribPointer(f,2,t.FLOAT,!1,0,0),t.activeTexture(t.TEXTURE0),t.bindTexture(t.TEXTURE_2D,p),t.uniform1i(m,0),t.enable(t.BLEND),t.blendFunc(t.ONE,t.ONE_MINUS_SRC_ALPHA),t.clearColor(0,0,0,0),t.clear(t.COLOR_BUFFER_BIT),t.uniform1f(h,x),t.drawArrays(t.TRIANGLES,0,6)}function y(b){n&&(v(b),a=requestAnimationFrame(y))}return{start(){n||o||(n=!0,a=requestAnimationFrame(y))},stop(){n&&(n=!1,a&&(cancelAnimationFrame(a),a=0))},destroy(){o=!0,n=!1,a&&cancelAnimationFrame(a),t&&(p&&t.deleteTexture(p),u&&t.deleteBuffer(u),d&&t.deleteProgram(d)),s.remove()}}}const rh=`
attribute vec2 a_pos;
varying vec2 v_uv;
void main() {
  v_uv = (a_pos + 1.0) * 0.5;
  v_uv.y = 1.0 - v_uv.y;
  gl_Position = vec4(a_pos, 0.0, 1.0);
}
`;function Fi(e,s,t){const n=e.createShader(s);return n?(e.shaderSource(n,t),e.compileShader(n),e.getShaderParameter(n,e.COMPILE_STATUS)?n:(console.warn("[GlCanvas] Shader compile error:",e.getShaderInfoLog(n)),e.deleteShader(n),null)):null}function lh(e,s,t={}){const n=t.dprCap??1.25;let a=null;try{a=e.getContext("webgl",{alpha:t.alpha??!0,premultipliedAlpha:!0,antialias:!1,depth:!1,stencil:!1,powerPreference:"high-performance"})}catch{a=null}if(!a)return null;const i=Fi(a,a.VERTEX_SHADER,rh),o=Fi(a,a.FRAGMENT_SHADER,s);if(!i||!o)return null;const r=a.createProgram();if(!r)return null;if(a.attachShader(r,i),a.attachShader(r,o),a.linkProgram(r),!a.getProgramParameter(r,a.LINK_STATUS))return console.warn("[GlCanvas] Link error:",a.getProgramInfoLog(r)),a.deleteProgram(r),null;a.useProgram(r);const l=a.createBuffer();a.bindBuffer(a.ARRAY_BUFFER,l),a.bufferData(a.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),a.STATIC_DRAW);const c=a.getAttribLocation(r,"a_pos");c>=0&&(a.enableVertexAttribArray(c),a.vertexAttribPointer(c,2,a.FLOAT,!1,0,0));let d=!1,u=0,f=0,m=!1;const h=()=>{if(!a||m)return;const v=Math.min(window.devicePixelRatio||1,n),y=e.getBoundingClientRect(),b=Math.max(1,Math.floor(y.width*v)),x=Math.max(1,Math.floor(y.height*v));(e.width!==b||e.height!==x)&&(e.width=b,e.height=x,a.viewport(0,0,b,x),t.onResize?.(b,x,a))},p=new ResizeObserver(()=>h());p.observe(e),h();const g=v=>{if(!d||!a||m)return;f||(f=v);const y=(v-f)*.001;h(),a.viewport(0,0,e.width,e.height),a.useProgram(r),t.onRender?.(y,a,e.width,e.height),a.drawArrays(a.TRIANGLES,0,6),u=requestAnimationFrame(g)};return{gl:a,program:r,canvas:e,getUniformLocation(v){return a.getUniformLocation(r,v)},start(){m||d||(d=!0,f=0,h(),u=requestAnimationFrame(g))},stop(){d=!1,u&&(cancelAnimationFrame(u),u=0)},destroy(){m=!0,d=!1,u&&cancelAnimationFrame(u),p.disconnect(),l&&a.deleteBuffer(l),i&&a.deleteShader(i),o&&a.deleteShader(o),r&&a.deleteProgram(r)}}}const ch=`
precision mediump float;

varying vec2 v_uv;
uniform vec2 u_res;
uniform vec2 u_center; // Stage/pedestal center in pixel coordinates
uniform float u_time;
uniform float u_locked;

// Pseudo-random & noise utilities
float hash(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

float noise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(
    mix(hash(i + vec2(0.0, 0.0)), hash(i + vec2(1.0, 0.0)), u.x),
    mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x),
    u.y
  );
}

float fbm(vec2 p) {
  float v = 0.0;
  float a = 0.5;
  vec2 shift = vec2(100.0);
  mat2 rot = mat2(cos(0.5), sin(0.5), -sin(0.5), cos(0.5));
  for (int i = 0; i < 4; i++) {
    v += a * noise(p);
    p = rot * p * 2.02 + shift;
    a *= 0.5;
  }
  return v;
}

// Procedural occult sigil circle on the floor
float sigilRings(vec2 p, float t) {
  float r = length(p);
  if (r > 1.25 || r < 0.02) return 0.0;

  float ring1 = smoothstep(0.025, 0.002, abs(r - 0.98));
  float ring2 = smoothstep(0.020, 0.002, abs(r - 0.90));
  float ring3 = smoothstep(0.016, 0.002, abs(r - 0.68));
  float ring4 = smoothstep(0.014, 0.002, abs(r - 0.44));
  float ring5 = smoothstep(0.016, 0.002, abs(r - 0.16));

  float angle = atan(p.y, p.x);

  // Rotating rune ticks on outer band
  float ticks1 = smoothstep(0.65, 0.95, cos((angle + t * 0.06) * 36.0)) * smoothstep(0.08, 0.0, abs(r - 0.94));
  // Rotating inner radial divisions
  float ticks2 = smoothstep(0.80, 0.98, cos((angle - t * 0.09) * 12.0)) * smoothstep(0.14, 0.0, abs(r - 0.56));
  // Hermetic triangle / geometric lines
  float triAngle = angle + t * 0.04;
  float geom = smoothstep(0.85, 0.99, cos(triAngle * 3.0)) * smoothstep(0.20, 0.0, abs(r - 0.44));

  float glowBase = ring1 * 1.0 + ring2 * 0.75 + ring3 * 0.85 + ring4 * 0.70 + ring5 * 0.55;
  return glowBase + ticks1 * 0.85 + ticks2 * 0.70 + geom * 0.60;
}

// Procedural rising embers/sparks
float embers(vec2 uv, float t) {
  float acc = 0.0;
  for (int i = 0; i < 24; i++) {
    float fi = float(i);
    float speed = 0.10 + fract(fi * 0.317) * 0.16;
    float seedX = fract(fi * 0.618);
    float x = (seedX - 0.5) * 0.85 + sin(t * 1.4 + fi * 2.3) * 0.05;
    float y = fract(0.95 - (t * speed + fract(fi * 0.733))) * 1.15 - 0.1;

    vec2 pos = vec2(x, y);
    float dist = length(uv - pos);
    float spark = smoothstep(0.035, 0.002, dist);
    float flicker = 0.55 + 0.45 * sin(t * 8.5 + fi * 4.7);
    float life = smoothstep(0.95, 0.45, y) * smoothstep(-0.05, 0.2, y);
    acc += spark * flicker * life;
  }
  return acc;
}

void main() {
  vec2 res = max(u_res, vec2(1.0, 1.0));
  vec2 p = (gl_FragCoord.xy - res * 0.5) / min(res.x, res.y);

  // Pedestal center in screen aspect-corrected coordinates
  vec2 centerNorm = (u_center - res * 0.5) / min(res.x, res.y);
  vec2 stageCoord = p - centerNorm;

  // 1. Deep Atmospheric Dark Base
  vec3 bgDeep = vec3(0.065, 0.048, 0.080);
  vec3 bgVoid = vec3(0.020, 0.015, 0.025);
  vec3 col = mix(bgDeep, bgVoid, length(p) * 0.9);

  // 2. Slow Domain-Warped Aetheric Smoke / Fog
  vec2 fogUv = p * 1.5;
  fogUv.y += u_time * 0.03;
  vec2 warp = vec2(
    fbm(fogUv + vec2(0.0, u_time * 0.035)),
    fbm(fogUv + vec2(5.2, u_time * 0.025))
  );
  float smoke = fbm(fogUv + warp * 1.3);
  float centerFalloff = smoothstep(1.3, 0.1, length(stageCoord));
  smoke *= (0.4 + 0.6 * centerFalloff);

  vec3 smokeCold = vec3(0.18, 0.13, 0.25);
  vec3 smokeWarm = mix(vec3(0.36, 0.18, 0.08), vec3(0.10, 0.14, 0.20), u_locked);
  col += mix(smokeCold, smokeWarm, smoke * 0.7) * smoke * 0.55;

  // 3. Volumetric Occult Light Cone / God-Ray falling onto pedestal
  vec2 rayUv = stageCoord;
  float coneWidth = 0.32 + (1.0 - rayUv.y) * 0.26;
  float inCone = smoothstep(coneWidth, 0.0, abs(rayUv.x));
  float rayVertical = smoothstep(-0.65, 0.85, rayUv.y);
  float rayNoise = noise(vec2(rayUv.x * 5.0, rayUv.y * 2.0 - u_time * 0.18));
  float beam = inCone * rayVertical * (0.60 + 0.40 * rayNoise);
  vec3 beamColor = mix(vec3(0.32, 0.25, 0.16), vec3(0.14, 0.16, 0.24), u_locked);
  col += beamColor * beam * 0.38;

  // 4. Perspective-Squashed Transmutation Seal (Floor Pedestal)
  vec2 floorCoord = stageCoord;
  floorCoord.y += 0.24; // under vessel feet
  floorCoord.y *= 2.8;  // perspective compression

  float sigilTime = u_time * (1.0 - u_locked * 0.7);
  float sigilMask = sigilRings(floorCoord * 2.3, sigilTime);

  float sealDist = length(floorCoord * 2.3);
  float sealGlow = smoothstep(1.4, 0.1, sealDist) * 0.35;

  vec3 brassCol = vec3(0.86, 0.72, 0.38);
  vec3 emberCol = vec3(0.92, 0.42, 0.12);
  vec3 lockedSigilCol = vec3(0.28, 0.34, 0.44);

  float sigilBlink = 0.80 + 0.20 * sin(u_time * 1.2);
  vec3 activeSigilColor = mix(emberCol, brassCol, 0.65) * sigilBlink;
  vec3 sigilColor = mix(activeSigilColor, lockedSigilCol, u_locked);

  col += sigilColor * sigilMask * (0.95 - u_locked * 0.45);
  col += mix(emberCol * 0.4, lockedSigilCol * 0.20, u_locked) * sealGlow;

  // 5. Rising Embers / Occult Cinders
  if (u_locked < 0.95) {
    vec2 emberCoord = stageCoord;
    emberCoord.y += 0.18;
    float emb = embers(emberCoord, u_time);
    vec3 emberTint = vec3(0.98, 0.52, 0.14);
    col += emberTint * emb * 0.95;
  }

  // 6. Deep Vignette & Dark Hermetic Grade
  float edgeDist = length(p);
  float vignette = smoothstep(1.5, 0.4, edgeDist);
  col *= vignette;

  // Micro film-grain to prevent 8-bit banding on dark gradients
  float grain = (hash(gl_FragCoord.xy + fract(u_time)) - 0.5) * 0.025;
  col += grain;

  col = clamp(col, 0.0, 1.0);
  gl_FragColor = vec4(col, 1.0);
}
`;function dh(e){const s=document.createElement("canvas");s.className="hall-backdrop-canvas",s.setAttribute("aria-hidden","true"),e.replaceChildren(s);let t=null,n=!1;const a=window.matchMedia("(prefers-reduced-motion: reduce)");let i=a.matches;a.addEventListener("change",u=>{i=u.matches});let o=null,r=null,l=null,c=null;const d=lh(s,ch,{dprCap:1.25,alpha:!1,onRender(u,f,m,h){!o&&d&&(o=d.getUniformLocation("u_res"),r=d.getUniformLocation("u_center"),l=d.getUniformLocation("u_time"),c=d.getUniformLocation("u_locked")),o&&f.uniform2f(o,m,h);let p=m*.48,g=h*.45;if(t){const v=t.getBoundingClientRect(),y=s.getBoundingClientRect();if(y.width>0&&y.height>0&&v.width>0){const b=m/y.width,x=h/y.height;p=(v.left+v.width*.5-y.left)*b;const k=(v.bottom-v.height*.32-y.top)*x;g=h-k}}r&&f.uniform2f(r,p,g),l&&f.uniform1f(l,i?1:u),c&&f.uniform1f(c,n?1:0)}});return{start(){d?.start()},stop(){d?.stop()},destroy(){d?.destroy(),s.remove()},updateStage(u,f){t=u,n=f}}}const uh={speed:"Speed",maxHp:"Max HP",radius:"Vessel Size",damage:"Damage",cooldown:"Cooldown",critChance:"Crit Chance",critDamage:"Crit Damage",armor:"Armor",hazardResist:"Hazard Ward",hpRegen:"HP/s Regen",pickupRadius:"Essence Magnet",xpGain:"Essence XP",aoeRadius:"Area Size",projSpeed:"Projectile Speed",controlDuration:"Rite Duration",eliteDamage:"Elite & Boss Damage"};let X={onStart:()=>{},onResume:()=>{},onQuit:()=>{},onAbandon:()=>{},onPause:()=>{},onPick:()=>{},onRestart:()=>{}},Bi=!1,Hi=!1,$i=!1,_i=!1,A="hidden",J="menu",ie=!1,Ps=0,Va=0,Nt=null,ft=null,Gi=0,Ot="",wr,Rr;async function fh(e){if(typeof navigator<"u"&&navigator.clipboard&&typeof navigator.clipboard.writeText=="function")try{return await navigator.clipboard.writeText(e),!0}catch{}try{const s=document.createElement("textarea");s.value=e,s.style.position="fixed",s.style.left="-9999px",s.style.top="-9999px",s.style.opacity="0",document.body.appendChild(s),s.focus(),s.select();const t=document.execCommand("copy");return s.remove(),t}catch{return!1}}function mh(e=Rr??"defeat",s=wr){const t=e==="victory"?"TRANSMUTATION COMPLETE 🜂":e==="defeat"?"VESSEL SHATTERED 🜍":"VESSEL DISSOLVED ☿";if(!s)return`⚗️ HERMETIC RIFTS — ${t}`;const n=s.items.length>0?s.items.map(a=>`${a.name}${a.stacks>1?` ×${a.stacks}`:""}`).join(", "):"None";return[`⚗️ HERMETIC RIFTS — ${t}`,`Vessel: ${s.survivor} · Chamber: ${s.stage}`,`Time: ${Q(s.time)} · Lv ${s.level} · Coeff: ×${s.coefficient.toFixed(2)}`,`Dross Slain: ${(s.kills??0).toLocaleString()} · Bosses Slain: ${s.bosses}`,`Damage Dealt: ${Math.round(s.damageDealt??0).toLocaleString()} · Essence: ${s.gemsCollected??0}`,`Relics: ${n}`].join(`
`)}function Tr(){const e=mh(),t=document.getElementById("runend-copy")?.querySelector(".plaque-label");fh(e).then(n=>{if(n){if(T("confirm"),t){const a=t.textContent;t.textContent="COPIED TO LEDGER ✓",window.setTimeout(()=>{t&&t.textContent==="COPIED TO LEDGER ✓"&&(t.textContent=a)},2200)}}else T("error")})}function hh(){typeof document>"u"||(document.fullscreenElement?document.exitFullscreen().catch(()=>{}):document.documentElement.requestFullscreen().catch(()=>{}))}function Ar(e){X={...X,...e},Bi||(Bi=!0,window.addEventListener("keydown",Mh,!0),window.addEventListener("blur",()=>{dt()||A==="hidden"&&!ie&&X.onPause()}),document.addEventListener("visibilitychange",()=>{dt()||document.hidden&&A==="hidden"&&!ie&&X.onPause()}),window.addEventListener("pointerdown",()=>{typeof window<"u"&&document.activeElement!==document.body&&window.focus()}),document.getElementById("settings-close")?.addEventListener("click",()=>Ut()?.close()),va(),de(document)),ke()}function Oi(){return A}function ph(){return ie}function gh(){return A!=="hidden"}function mt(){const e=A==="pause",s=Ae();Nt?.stop(),ft?.stop(),A="hidden",ie=!1,J="menu",ke(),Te(),e&&T("close"),s&&(Uh(s),Ut()?.close(),s.classList.add("hidden"),s.setAttribute("aria-hidden","true"),s.removeAttribute("data-screen"))}function Jt(){ie=!1,J="menu",wh()}function yn(){ie=!1,J="lobby",Pr()}function Ua(e=J,s){J=e,ie=e==="pause";const t=Ae(),n=Fr();!t||!n||(A="howto",ke(),t.dataset.screen="archives",t.setAttribute("aria-labelledby","archives-brand"),Je(),n.classList.remove("hidden"),Wm(fa,s),et(t),Te())}function Ir(e=J){J=e;const s=Ut(),t=document.getElementById("settings-body");!s||!t||(t.replaceChildren($h(H())),de(s),s.open||s.showModal())}function Wa(){const e=J==="pause"&&(A==="abandon"||A==="howto"||A==="pause");ie=!0,J="pause",e||T("open"),Nh()}const yh={missing:{kicker:"The vessel cannot ignite",title:"WebGL required",sub:"This working needs a GPU that speaks WebGL. The chamber could not open a graphics context."},software:{kicker:"The vessel cannot ignite",title:"WebGL required",sub:"The browser offered only a software renderer. That cannot carry a swarm."},incomplete:{kicker:"The vessel cannot ignite",title:"WebGL required",sub:"This GPU is missing extensions the chamber needs (instanced arrays)."},lost:{kicker:"The aether tore",title:"GPU context lost",sub:"The graphics context was seized mid-working. Relics in this run are gone."}},vh=["Enable hardware acceleration in the browser (Chrome: chrome://settings/system).","Update the graphics driver, then restart the browser.","Close other GPU-heavy tabs and reload."];function yt(e){gn(),ie=!0;const s=yh[e],t=document.createElement("ul");t.className="webgl-gate-tips";for(const n of vh){const a=document.createElement("li");a.textContent=n,t.appendChild(a)}Dr({screen:"webgl",kicker:s.kicker,title:s.title,sub:s.sub,body:t,actions:[{label:"Reload Chamber",onClick:()=>window.location.reload(),primary:!0,sfx:"confirm"}]})}function bh(){ie=!0,J="pause",Dr({screen:"abandon",kicker:"Break the vessel?",title:"Abandon run",sub:"The vessel shatters. Progress in this working will be committed to the Great Ledger.",actions:[{label:"Abandon Vessel",onClick:()=>{X.onAbandon()},primary:!0,sfx:"error"},{label:"Keep working",onClick:Wa,sfx:null}]})}function xh(e){ie=!0,T("open");const s=Ae(),t=Br(),n=document.getElementById("levelup-choices");!s||!t||!n||(A="levelup",ke(),s.dataset.screen="levelup",s.setAttribute("aria-labelledby","levelup-title"),Je(),t.classList.remove("hidden"),n.replaceChildren(),e.forEach((a,i)=>{const o=document.createElement("div");o.className="aug-card-col";const r=document.createElement("button");r.type="button",r.className=`choice aug-card rarity-${a.rarity}`,r.dataset.uiSprite=`card-${a.rarity}`,r.dataset.hooks=String(a.hooks.length);const l=document.createElement("span");l.className="aug-card-name",l.textContent=a.name;const c=document.createElement("div");c.className="aug-card-art";const d=Xe(a.id,a.name,"choice-icon",Qo);d.addEventListener("error",()=>{d.remove();const v=document.createElement("span");v.className="aug-card-fallback",v.textContent=a.name.slice(0,1).toUpperCase(),c.appendChild(v)}),c.appendChild(d);const u=document.createElement("span");u.className=`aug-card-rarity rarity-text-${a.rarity}`,u.textContent=Eh(a.rarity);const f=document.createElement("div");f.className="aug-card-hooks",f.append(...za(a,!1));const m=document.createElement("hr");m.className="aug-card-divider";const h=document.createElement("p");h.className="aug-card-lore",h.textContent=a.lore;const p=document.createElement("div");p.className="aug-card-desc",p.append(f,m,h),r.append(l,c,u,p),r.addEventListener("click",()=>{T("confirm"),X.onPick(i)}),r.addEventListener("mouseenter",()=>r.focus({preventScroll:!0}));const g=document.createElement("span");g.className="aug-card-key",g.textContent=`[${i+1}]`,o.append(r,g),n.appendChild(o)}),de(t),et(s),Te())}function Vn(e,s,t){gn(),ie=!0,T(e==="victory"?"victory":"defeat"),Gh(e,s,t)}function Un(e,s=2e3){if(mo())return;const t=Gr(),n=document.getElementById("sting-kicker"),a=document.getElementById("sting-title"),i=document.getElementById("sting-sub");if(!t||!n||!a||!i)return;n.textContent=e.kicker,a.textContent=e.title,i.textContent=e.sub,t.classList.remove("hidden"),t.classList.add("visible"),Ps+=1;const o=Ps;Va=performance.now()+s,window.setTimeout(()=>{o===Ps&&Vt()},s)}function Vt(){Ps+=1,Va=0;const e=Gr();e&&(e.classList.remove("visible"),window.setTimeout(()=>{e.classList.contains("visible")||e.classList.add("hidden")},200))}function Vi(){return Va>performance.now()}function Js(e){const s=qh(),t=document.getElementById("prompt-title"),n=document.getElementById("prompt-detail"),a=document.getElementById("prompt-fill");if(!(!s||!t||!n||!a)){if(!e.visible){s.classList.add("hidden");return}s.classList.remove("hidden"),s.dataset.state=e.outside?"out":"in",t.textContent=e.title,n.textContent=e.detail,a.style.width=`${Math.round(Math.min(1,Math.max(0,e.pct))*100)}%`}}function kh(e){const s=document.getElementById("levelup-choices");if(!s)return;const t=[...s.querySelectorAll("button.choice")];if(t.length===0)return;const n=document.activeElement,a=t.findIndex(r=>r===n),o=((a<0?e>0?-1:0:a)+e+t.length)%t.length;t[o]?.focus()}function za(e,s=!1){return e.hooks.map(t=>{const n=document.createElement("span"),a=Sh(t);return n.className=a.up?"hook-up":"hook-down",n.textContent=s?a.text.toUpperCase():a.text,n})}function Sh(e){const s=e.value>0?"+":"";if(e.op==="on-kill")return{text:`${s}${e.value} HP on kill`,up:e.value>0};if(e.op==="on-crit")return{text:`-${e.value}s CD on crit`,up:!0};const t=e.op==="pct"?`${s}${Math.round(e.value*100)}%`:`${s}${e.value}`,n=e.stat==="radius"||e.stat==="cooldown",a=e.value===0?!0:n?e.value<0:e.value>0;return{text:`${t} ${uh[e.stat]}`,up:a}}function Eh(e){return e.length>0?e[0].toUpperCase()+e.slice(1):e}function Ch(e){return e.code==="Escape"||e.key==="Escape"||e.key==="Esc"||e.keyCode===27}function Ui(e){return e.code==="KeyP"||e.key==="p"||e.key==="P"}function Mh(e){if(A==="hidden"&&(e.code==="Space"||e.key===" "||e.key.startsWith("Arrow"))&&e.preventDefault(),(Ch(e)||Ui(e))&&!(Ui(e)&&(A==="menu"||A==="lobby"||A==="levelup"))){if(e.preventDefault(),e.repeat)return;const s=Ut();if(s?.open){s.close();return}A==="pause"?X.onResume():A==="lobby"?(T("close"),Jt()):A==="howto"||A==="survivor"||A==="abandon"?fa():A==="runend"?(T("close"),X.onQuit()):A==="hidden"&&X.onPause();return}if(e.key==="Enter"){if(A==="webgl"){e.preventDefault(),window.location.reload();return}if(Ut()?.open)return;if(A==="menu")e.preventDefault(),T("confirm"),yn();else if(A==="lobby"){e.preventDefault();const s=bt();if(!ae(s)){T("error");return}T("confirm"),X.onStart()}else A==="pause"?(e.preventDefault(),X.onResume()):A==="abandon"?(e.preventDefault(),T("defeat"),X.onAbandon()):A==="survivor"?(e.preventDefault(),fa()):A==="runend"&&(e.preventDefault(),X.onRestart());return}if(A==="runend"&&(e.key==="c"||e.key==="C")){e.preventDefault(),Tr();return}if(A==="levelup"){if(e.key==="1"||e.key==="2"||e.key==="3"){e.preventDefault(),T("confirm"),X.onPick(Number(e.key)-1);return}(e.key==="ArrowLeft"||e.key==="ArrowRight")&&(e.preventDefault(),kh(e.key==="ArrowRight"?1:-1))}}function fa(){J==="pause"||A==="abandon"?Wa():J==="lobby"?yn():Jt()}function Je(){Nt?.stop(),ft?.stop(),Lr()?.classList.add("hidden"),Nr()?.classList.add("hidden"),Fr()?.classList.add("hidden"),Br()?.classList.add("hidden"),Hr()?.classList.add("hidden"),$r()?.classList.add("hidden"),_r()?.classList.add("hidden")}function Dr(e){const s=Ae(),t=_r(),n=Wh(),a=zh(),i=Xh(),o=Yh(),r=Kh(),l=jh();if(!(!s||!t||!n||!a||!i||!o||!r||!l)){if(A=e.screen,ke(),s.dataset.screen=e.screen,s.setAttribute("aria-labelledby","overlay-title"),Je(),t.classList.remove("hidden"),n.textContent=e.kicker,a.textContent=e.title,i.textContent=e.sub,o.replaceChildren(),e.body&&o.appendChild(e.body),r.replaceChildren(),e.choices)for(;e.choices.firstChild;)r.appendChild(e.choices.firstChild);l.replaceChildren();for(const c of e.actions??[])l.appendChild(Vh(c.label,c.onClick,c.primary,c.sfx));de(t),et(s),Te()}}function wh(){const e=Ae(),s=Lr();if(!e||!s)return;A="menu",ke(),e.dataset.screen="menu",e.setAttribute("aria-labelledby","menu-brand"),Je(),s.classList.remove("hidden"),Rh(),Th();const t=document.getElementById("menu-cinder-circle");t&&(Nt||(Nt=oh(t)),Nt.start()),de(s),et(e),lt({kind:"menu"}),Te()}function Rh(){Hi||(Hi=!0,document.getElementById("menu-archives")?.addEventListener("click",()=>{T("click"),Ua("menu","howto")}),document.getElementById("menu-desk")?.addEventListener("click",()=>{T("click"),Ir("menu")}),document.getElementById("menu-commence")?.addEventListener("click",()=>{T("confirm"),yn()}))}function Th(){const e=document.getElementById("menu-preview");if(!e)return;const s=Xa();e.replaceChildren(),Qt(e,s.id,"menu-vessel",s.name)}function bt(){if(Ot){const e=E.survivors.find(s=>s.id===Ot);if(e)return e}return Xa()}function Pr(){const e=Ae(),s=Nr();if(!e||!s)return;Ot||(Ot=Xa().id),A="lobby",ke(),e.dataset.screen="lobby",e.setAttribute("aria-labelledby","hall-brand"),Je(),s.classList.remove("hidden");const t=document.getElementById("hall-backdrop");t&&(ft||(ft=dh(t)),ft.start()),Ah(),Dh(),Ph(),Lh(),Ih(),de(s),et(e),lt({kind:"menu"}),Te()}function Ah(){$i||($i=!0,document.getElementById("hall-back")?.addEventListener("click",()=>{T("close"),Jt()}),document.getElementById("hall-commence")?.addEventListener("click",()=>{const e=bt();if(!ae(e)){T("error");return}T("confirm"),X.onStart()}))}function Ih(){const e=document.getElementById("hall-commence");if(!e)return;const s=ae(bt());e.disabled=!s,e.dataset.locked=s?"0":"1";const t=e.querySelector(".plaque-label");t&&(t.textContent=s?"COMMENCE WORKING":"VESSEL SEALED")}function Dh(){const e=document.getElementById("hall-nav");if(!e)return;e.replaceChildren();const s=$(),t=bt().id;for(const n of E.survivors){const a=ae(n,s),i=document.createElement("button");i.type="button",i.className="vessel-pick",i.dataset.active=n.id===t?"1":"0",i.dataset.locked=a?"0":"1";const o=document.createElement("div");o.className="vessel-portrait-box",Qt(o,n.id,"vessel-art portrait-art",a?n.name:"Sealed Vessel");const r=document.createElement("span");r.className="vessel-nameplate",r.textContent=a?n.name.toUpperCase():"??? · SEALED";const l=document.createElement("span");l.className="vessel-active-arrow",l.setAttribute("aria-hidden","true"),i.append(o,r,l),i.addEventListener("click",()=>{T("click"),Ot=n.id,a&&De({survivorId:n.id}),Pr()}),e.appendChild(i)}}function Ph(){const e=document.getElementById("hall-preview");if(!e)return;const s=bt(),t=ae(s);e.dataset.locked=t?"0":"1",e.replaceChildren(),Qt(e,s.id,"hall-vessel",t?s.name:"Sealed Vessel"),ft?.updateStage(e,!t)}function Lh(){const e=document.getElementById("hall-dossier");if(!e)return;const s=$(),t=bt(),n=Ze(t.unlock,s),a=n.unlocked,i=document.createElement("p");i.className="dossier-header",i.textContent=a?"VESSEL DOSSIER":"SEALED VESSEL";const o=document.createElement("h2");o.className="hall-name",o.textContent=a?t.name.toUpperCase():"???";const r=document.createElement("p");r.className=a?"hall-lore":"hall-lore is-locked-lore",r.textContent=a?t.lore??"":`Rite of Unsealing: ${n.label} (${n.progress}).`;const l=document.createElement("div");l.className="hall-stats-grid";const c=a?[{icon:"♥",text:`VITALITY: ${t.stats.maxHp}`},{icon:"⚔",text:(t.title??"The Vessel").toUpperCase()},{icon:"🥾",text:`STRIDE: ${t.stats.speed>=260?"SWIFT":"MEASURED"}`},{icon:"🛡",text:"FRAME: COMPACT"}]:[{icon:"♥",text:"VITALITY: ???"},{icon:"⚔",text:"ROLE: ???"},{icon:"🥾",text:"STRIDE: ???"},{icon:"🛡",text:`SEAL: ${n.progress}`}];for(const m of c){const h=document.createElement("div");h.className="hall-stat-cell";const p=document.createElement("span");p.className="hall-stat-icon",p.textContent=m.icon;const g=document.createElement("span");g.className="hall-stat-text",g.textContent=m.text,h.append(p,g),l.appendChild(h)}const d=document.createElement("div");d.className="hall-skills";const u=["primary","secondary","utility","special"],f=["I","II","III","IV"];u.forEach((m,h)=>{const p=Oh(t,m),g=document.createElement("div");g.className="hall-skill-unit";const v=document.createElement("button");if(v.type="button",v.className="hall-skill",!a||!p){v.textContent=a?"—":"?",v.dataset.locked=a?"0":"1";const R=document.createElement("span");R.className="hall-skill-label",R.textContent=a?"—":"???",g.append(v,R),d.appendChild(g);return}const y=document.createElement("span");y.className="hall-skill-glyph",y.textContent=f[h];const b=Na(p.id,p.name,"hall-skill-icon",La);b.addEventListener("error",()=>{b.remove(),v.dataset.hasIcon="0"}),b.addEventListener("load",()=>{v.dataset.hasIcon="1"});const x=document.createElement("span");x.className="tip";const k=document.createElement("strong");k.textContent=p.name;const C=document.createElement("span");C.textContent=p.hook??p.slot;const M=document.createElement("em");M.textContent=p.lore??"",x.append(k,C,M),v.append(y,b,x);const w=document.createElement("span");w.className="hall-skill-label",w.textContent=p.name,g.append(v,w),d.appendChild(g)}),e.replaceChildren(i,o,r,l,d)}function Nh(){const e=Ae(),s=Hr();!e||!s||(A="pause",ke(),e.dataset.screen="pause",e.setAttribute("aria-labelledby","pause-title"),Je(),s.classList.remove("hidden"),Fh(),Bh(),Hh(Bf()),de(s),et(e),Te())}function Fh(){_i||(_i=!0,document.getElementById("pause-resume")?.addEventListener("click",()=>{X.onResume()}),document.getElementById("pause-archives")?.addEventListener("click",()=>{T("click"),Ua("pause","howto")}),document.getElementById("pause-settings")?.addEventListener("click",()=>{T("click"),Ir("pause")}),document.getElementById("pause-abandon")?.addEventListener("click",()=>{T("click"),bh()}))}function Bh(){const e=document.getElementById("pause-summary-rows");if(!e)return;const s=Hf(),t=[["Run Time:",Q(s.runTime)],["Level:",String(s.level)],["Dross Slain:",String(s.kills)],["Bosses Slain:",String(s.bosses)],["Damage Dealt:",s.damageDealt.toLocaleString("en-US")],["Total Augmentations:",String(s.totalItems)]];e.replaceChildren();for(const[n,a]of t){const i=document.createElement("div");i.className="summary-row";const o=document.createElement("span");o.className="summary-k",o.textContent=n;const r=document.createElement("span");r.className="summary-v",r.textContent=a,i.append(o,r),e.appendChild(i)}}function Hh(e){const s=document.getElementById("pause-inv-list"),t=document.getElementById("pause-item-tooltip");if(!s||!t)return;const n=Math.max(4,Math.ceil(Math.sqrt(Math.max(1,e.length))));s.style.setProperty("--inv-cols",String(n)),s.replaceChildren(),t.classList.add("hidden");const a=e.length===0;if(s.classList.toggle("is-empty",a),a){const l=document.createElement("p");l.className="pause-inv-empty",l.textContent="No augmentations bound yet.",s.appendChild(l);return}const i=l=>{let c;try{c=E.item(l.id)}catch{return}t.classList.remove("hidden");const d=document.createElement("div");d.className="tooltip-art-wrap";const u=Xe(c.id,c.name,"tooltip-item-icon",64);u.addEventListener("error",()=>u.remove()),d.appendChild(u);const f=document.createElement("h4");f.className="tooltip-item-name",f.textContent=l.stacks>1?`${c.name.toUpperCase()} ×${l.stacks}`:c.name.toUpperCase();const m=document.createElement("div");m.className="tooltip-item-hooks",m.append(...za(c,!1));const h=document.createElement("p");h.className="tooltip-item-lore",h.textContent=c.lore,t.replaceChildren(d,f,m,h)},o=(l,c)=>{const f=t.getBoundingClientRect(),m=f.width||280,h=f.height||220;let p=l+16,g=c+16;p+m+12>window.innerWidth&&(p=Math.max(12,l-m-16)),g+h+12>window.innerHeight&&(g=Math.max(12,c-h-16)),t.style.left=`${Math.round(p)}px`,t.style.top=`${Math.round(g)}px`},r=()=>{t.classList.add("hidden")};for(const l of e){const c=hn(l,"item-chip pause-chip");c.removeAttribute("title"),c.tabIndex=0,c.addEventListener("mouseenter",d=>{i(l),o(d.clientX,d.clientY)}),c.addEventListener("mousemove",d=>{o(d.clientX,d.clientY)}),c.addEventListener("mouseleave",r),c.addEventListener("focus",()=>{i(l);const d=c.getBoundingClientRect();o(d.right,d.top)}),c.addEventListener("blur",r),s.appendChild(c)}}function $h(e){const s=document.createElement("div");return s.appendChild(_h("Fullscreen Chamber","Expand working to fill the entire monitor.",()=>{hh()})),s.appendChild(Wn("Master Volume","Overall resonance of the chamber.",e.masterVolume,t=>{De({masterVolume:t})})),s.appendChild(Wn("Sound Effects","Strikes, footsteps, and the chime of brass.",e.sfxVolume,t=>{De({sfxVolume:t});const n=performance.now();n-Gi<120||(Gi=n,T("click"))})),s.appendChild(Wn("Music","Ritual hymns and the chamber’s drone.",e.musicVolume,t=>{De({musicVolume:t})})),s.appendChild(zn("Mute All","Silences the entire working.",e.muted,t=>{De({muted:t}),t||T("click")})),s.appendChild(zn("Screenshake","Tremor of the chamber upon heavy impacts.",e.screenshake,t=>{De({screenshake:t})})),s.appendChild(zn("Reduce Effects","Dims sparks and flashes for clearer sight.",e.reduceVfx,t=>{De({reduceVfx:t})})),s}function Wn(e,s,t,n){const a=document.createElement("label");a.className="setting-row";const i=document.createElement("span"),o=document.createElement("span");o.textContent=e;const r=document.createElement("span");r.className="hint",r.textContent=s,i.append(o,r);const l=document.createElement("span");l.className="setting-control";const c=document.createElement("input");c.type="range",c.min="0",c.max="1",c.step="0.05",c.value=String(t),c.setAttribute("aria-label",e);const d=document.createElement("span");d.className="setting-value",d.textContent=Wi(t);const u=()=>{const f=Number(c.value);d.textContent=Wi(f),n(f)};return c.addEventListener("input",u),c.addEventListener("change",u),l.append(c,d),a.append(i,l),a}function zn(e,s,t,n){const a=document.createElement("label");a.className="setting-row";const i=document.createElement("span"),o=document.createElement("span");o.textContent=e;const r=document.createElement("span");r.className="hint",r.textContent=s,i.append(o,r);const l=document.createElement("input");return l.type="checkbox",l.checked=t,l.setAttribute("aria-label",e),l.addEventListener("change",()=>n(l.checked)),a.append(i,l),a}function _h(e,s,t){const n=document.createElement("div");n.className="setting-row";const a=document.createElement("span"),i=document.createElement("span");i.textContent=e;const o=document.createElement("span");o.className="hint",o.textContent=s,a.append(i,o);const r=document.createElement("span");r.className="setting-control";const l=document.createElement("button");l.type="button",l.className="plaque-btn",l.dataset.uiSprite="btn-plaque",l.style.padding="4px 12px";const c=document.createElement("span");return c.className="plaque-label",c.textContent="Toggle Fullscreen",l.appendChild(c),l.addEventListener("click",()=>{T("click"),t()}),r.appendChild(l),n.append(a,r),n}function Wi(e){return`${Math.round(e*100)}%`}function Gh(e,s,t){const n=Ae(),a=$r(),i=document.getElementById("runend-kicker"),o=document.getElementById("runend-title"),r=document.getElementById("runend-sub"),l=document.getElementById("runend-stats-rows"),c=document.getElementById("runend-unlocks-list"),d=document.getElementById("runend-inv-list"),u=document.getElementById("runend-item-tooltip"),f=document.getElementById("runend-restart"),m=document.getElementById("runend-copy"),h=document.getElementById("runend-quit");if(wr=t,Rr=e,!n||!a||!i||!o||!r||!l||!c||!d||!f||!h)return;if(A="runend",ke(),n.dataset.screen="runend",a.dataset.outcome=e,Je(),a.classList.remove("hidden"),e==="victory"?(i.textContent="The Great Work Holds",o.textContent="TRANSMUTATION COMPLETE"):e==="defeat"?(i.textContent="The Clay Splits",o.textContent="VESSEL SHATTERED"):(i.textContent="The Crucible Cools",o.textContent="VESSEL DISSOLVED"),r.textContent=s,l.replaceChildren(),t){const y=[["Vessel",t.survivor],["Chamber Reached",t.stage],["Rift Duration",Q(t.time)],["Level Attained",String(t.level)],["Dross Slain",String(t.kills??0)],["Bosses Slain",String(t.bosses)],["Damage Dealt",Math.round(t.damageDealt??0).toLocaleString("en-US")],["Damage Taken",Math.round(t.damageTaken??0).toLocaleString("en-US")],["Healing Done",Math.round(t.healingDone??0).toLocaleString("en-US")],["Essence Gathered",String(t.gemsCollected??0)]];for(const[b,x]of y){const k=document.createElement("div");k.className="summary-row";const C=document.createElement("span");C.textContent=b;const M=document.createElement("span");M.className="summary-v",M.textContent=x,k.append(C,M),l.appendChild(k)}}if(c.replaceChildren(),t?.newUnlocks&&t.newUnlocks.length>0)for(const y of t.newUnlocks){const b=document.createElement("div");if(b.className="runend-unlock-card",y.kind==="item"){const M=Xe(y.id,y.name,"runend-unlock-icon",32);M.addEventListener("error",()=>M.remove()),b.appendChild(M)}const x=document.createElement("div");x.className="runend-unlock-info";const k=document.createElement("span");k.className="runend-unlock-name",k.textContent=`${y.name} (Unlocked)`;const C=document.createElement("span");C.className="runend-unlock-desc",C.textContent=y.desc,x.append(k,C),b.appendChild(x),c.appendChild(b)}else{const y=document.createElement("div");y.className="runend-unlock-empty";const b=document.createElement("span");if(b.textContent="No new relics unsealed in this working.",y.appendChild(b),t?.unlockProgress){const x=document.createElement("span");x.className="runend-unlock-progress",y.appendChild(x)}c.appendChild(y)}d.replaceChildren(),u&&u.classList.add("hidden");const p=y=>{if(!u)return;let b;try{b=E.item(y.id)}catch{return}u.classList.remove("hidden");const x=document.createElement("div");x.className="tooltip-art-wrap";const k=Xe(b.id,b.name,"tooltip-item-icon",64);k.addEventListener("error",()=>k.remove()),x.appendChild(k);const C=document.createElement("h4");C.className="tooltip-item-name",C.textContent=y.stacks>1?`${b.name.toUpperCase()} ×${y.stacks}`:b.name.toUpperCase();const M=document.createElement("div");M.className="tooltip-item-hooks",M.append(...za(b,!1));const w=document.createElement("p");w.className="tooltip-item-lore",w.textContent=b.lore,u.replaceChildren(x,C,M,w)},g=(y,b)=>{if(!u)return;const x=16,k=12,C=u.getBoundingClientRect(),M=C.width||300,w=C.height||220;let R=y+x,D=b+x;R+M+k>window.innerWidth&&(R=Math.max(k,y-M-x)),D+w+k>window.innerHeight&&(D=Math.max(k,b-w-x)),u.style.left=`${Math.round(R)}px`,u.style.top=`${Math.round(D)}px`},v=()=>{u&&u.classList.add("hidden")};if(!t||t.items.length===0){const y=document.createElement("p");y.className="pause-inv-empty",y.textContent="No relics bound in this cycle.",d.appendChild(y)}else for(const y of t.items){const b=hn({id:y.id,name:y.name,stacks:y.stacks,rarity:y.rarity},"item-chip runend-chip");b.removeAttribute("title"),b.tabIndex=0,b.addEventListener("mouseenter",x=>{p(y),g(x.clientX,x.clientY)}),b.addEventListener("mousemove",x=>{g(x.clientX,x.clientY)}),b.addEventListener("mouseleave",v),b.addEventListener("focus",()=>{p(y);const x=b.getBoundingClientRect();g(x.right,x.top)}),b.addEventListener("blur",v),d.appendChild(b)}f.onclick=()=>{T("confirm"),X.onRestart()},m&&(m.onclick=()=>{Tr()}),h.onclick=()=>{T("close"),X.onQuit()},de(a),et(n),Te()}function Xa(){const e=H().survivorId,s=E.survivors.find(t=>t.id===e);return s&&ae(s)?s:E.survivor(E.world.defaultSurvivor)}function Oh(e,s){const t=e.skills[s];return t?E.skill(t):null}function Vh(e,s,t=!1,n="click"){const a=document.createElement("button");a.type="button",a.className=t?"plaque-btn action-primary":"plaque-btn",a.dataset.uiSprite="btn-plaque";const i=document.createElement("span");return i.className="plaque-label",i.textContent=e,a.appendChild(i),a.addEventListener("click",()=>{n&&T(n),s()}),a}function Te(){io(A==="pause"||A==="abandon"||A==="howto"&&J==="pause")}function et(e){e.classList.remove("hidden"),e.setAttribute("aria-hidden","false"),e.querySelector("#overlay > :not(.hidden) button, #overlay > :not(.hidden) input")?.focus({preventScroll:!0})}function Ae(){return document.getElementById("overlay")}function Lr(){return document.getElementById("main-menu")}function Nr(){return document.getElementById("hall")}function Fr(){return document.getElementById("archives")}function Br(){return document.getElementById("levelup-view")}function Hr(){return document.getElementById("pause-view")}function $r(){return document.getElementById("runend-view")}function _r(){return document.querySelector("#overlay .overlay-card")}function Ut(){return document.getElementById("settings-dialog")}function ke(){typeof document>"u"||(document.documentElement.dataset.overlay=A)}function Uh(e){const s=document.activeElement;s instanceof HTMLElement&&e.contains(s)&&s.blur()}function Wh(){return document.getElementById("overlay-kicker")}function zh(){return document.getElementById("overlay-title")}function Xh(){return document.getElementById("overlay-sub")}function Yh(){return document.getElementById("overlay-body")}function Kh(){return document.getElementById("overlay-choices")}function jh(){return document.getElementById("overlay-actions")}function Gr(){return document.getElementById("sting")}function qh(){return document.getElementById("prompt")}const Or=()=>({entities:{},items:[],skills:[],env:[],fx:[]});let I=Or();const re=new Map,ma=new Set;function vn(e){return e in I.entities?e:e==="ember-chaser"&&"ember-warden"in I.entities?"ember-warden":e==="ember-warden"&&"ember-chaser"in I.entities?"ember-chaser":e==="frost-chaser"&&"frost-warden"in I.entities?"frost-warden":e==="frost-warden"&&"frost-chaser"in I.entities?"frost-chaser":(e==="ember-mite"||e==="frost-mite")&&"mite"in I.entities?"mite":(e==="ember-spitter"||e==="frost-spitter")&&"spitter"in I.entities?"spitter":re.has(e)?e:e==="ember-chaser"&&re.has("ember-warden")?"ember-warden":e==="ember-warden"&&re.has("ember-chaser")?"ember-chaser":e==="frost-chaser"&&re.has("frost-warden")?"frost-warden":e==="frost-warden"&&re.has("frost-chaser")?"frost-chaser":(e==="ember-mite"||e==="frost-mite")&&re.has("mite")?"mite":(e==="ember-spitter"||e==="frost-spitter")&&re.has("spitter")?"spitter":e}function Z(e){return`entity-${vn(e)}`}function Tt(e,s){return`entity-${vn(e)}-${s}`}function Zh(e){return`sprites/fx/${e}.png`}function en(e){return`fx-${e}`}function Vr(e){return vn(e)in I.entities}function Ur(e){return ma.has(e)}function Ya(e){const s=vn(e);return I.entities[s]??re.get(s)}function Qh(){return I}function Jh(e,s){Vr(e)||re.has(e)||re.set(e,{src:"",...s})}function e0(e){I=c0(e),ma.clear();for(const s of I.fx)ma.add(s);return I}function t0(e){if(!e||typeof e!="object")return;const s=e,t=s.frames&&typeof s.frames=="object"&&!Array.isArray(s.frames)?s.frames:s,n={};for(const[a,i]of Object.entries(t)){const o=Ft(i);o&&(n[a]=o)}Object.keys(n).length>0&&(I.envAtlas={src:I.envAtlas?.src??"sprites/env/atlas.png",width:(typeof s.width=="number"?s.width:I.envAtlas?.width)??0,height:(typeof s.height=="number"?s.height:I.envAtlas?.height)??0,frames:{...I.envAtlas?.frames??{},...n}})}function s0(e){e.load.json("sprite-manifest","sprites/manifest.json"),e.load.json("env-atlas-json","sprites/env/atlas.json"),e.load.once("filecomplete-json-env-atlas-json",(s,t,n)=>{t0(n)}),e.load.once("filecomplete-json-sprite-manifest",(s,t,n)=>{e0(n);const a=new Set;for(const[i,o]of Object.entries(I.entities)){const r=Z(i);a.has(r)||(a.add(r),e.load.spritesheet(r,o.src,{frameWidth:o.frameWidth,frameHeight:o.frameHeight}))}for(const i of I.fx)e.load.image(en(i),Zh(i));I.envAtlas&&Object.keys(I.envAtlas.frames).length>0&&e.load.image("env-atlas",I.envAtlas.src);for(const i of I.env)I.envAtlas?.frames[i]||e.load.image(`env-${i}`,`sprites/env/${i}.png`);I.uiAtlas&&Object.keys(I.uiAtlas.frames).length>0&&e.load.image("ui-atlas",I.uiAtlas.src);for(const i of I.ui??[])I.uiAtlas?.frames[i]||e.load.image(`ui-${i}`,`sprites/ui/${i}.png`)})}function n0(e){if(!I.uiAtlas||!e.textures.exists("ui-atlas"))return;const s=e.textures.get("ui-atlas");for(const[t,n]of Object.entries(I.uiAtlas.frames))if(!s.has(t)){const a=n.idle??n;s.add(t,0,a.x,a.y,a.w,a.h)}}function zi(e,s,t){const n=e.scene;if(I.uiAtlas?.frames[s]&&n.textures.exists("ui-atlas")){const i=n.textures.get("ui-atlas");if(!i.has(s)){const o=I.uiAtlas.frames[s],r=o.idle??o;i.add(s,0,r.x,r.y,r.w,r.h)}if(i.has(s))return e.setTexture("ui-atlas",s),!0}const a=`ui-${s}`;return n.textures.exists(a)?(e.setTexture(a),!0):(n.textures.exists(t)&&e.setTexture(t),!1)}function a0(e){if(!I.envAtlas||!e.textures.exists("env-atlas"))return;const s=e.textures.get("env-atlas");for(const[t,n]of Object.entries(I.envAtlas.frames))s.has(t)||s.add(t,0,n.x,n.y,n.w,n.h)}function Xi(e,s){return I.envAtlas?.frames[s]&&e.textures.exists("env-atlas")&&e.textures.get("env-atlas").has(s)?!0:e.textures.exists(`env-${s}`)}function ks(e,s,t){const n=e.scene;if(I.envAtlas?.frames[s]&&n.textures.exists("env-atlas")&&n.textures.get("env-atlas").has(s))return e.setTexture("env-atlas",s),!0;const a=`env-${s}`;return n.textures.exists(a)?(e.setTexture(a),!0):(t&&n.textures.exists(t)&&e.setTexture(t),!1)}function Ss(e,s,t){const n=`${e}-${s}`;if(Xi(t,n))return n;if(e==="glacial"){const a=`rime-${s}`;if(Xi(t,a))return a}return null}function i0(){return I.envAtlas}function Yi(e){return I.envAtlas?.frames[e]}function o0(e){return e.textures.exists("env-atlas")&&e.textures.get("env-atlas").getSourceImage()||null}function r0(e){const s=new Set([...Object.keys(I.entities),...re.keys()]);for(const t of s){const n=Ya(t),a=Z(t);if(!(!n||!e.textures.exists(a)))for(const[i,o]of Object.entries(n.anims)){const r=Tt(t,i);if(e.anims.exists(r))continue;const l=i!=="idle"&&i!=="walk"&&!i.startsWith("idle-")&&!i.startsWith("walk-")&&!i.startsWith("channel"),d=Array.isArray(o.durations)&&o.durations.length===o.frames.length?o.frames.map((u,f)=>({key:a,frame:u,duration:o.durations[f]})):e.anims.generateFrameNumbers(a,{frames:o.frames});e.anims.create({key:r,frames:d,frameRate:o.frameRate,repeat:typeof o.repeat=="number"?o.repeat:l?0:-1})}}}function Ct(e,s,t,n=1){const a=Z(s);if(!e.scene.textures.exists(a))return;e.texture.key!==a&&e.setTexture(a);const i=Tt(s,t),o=Tt(s,"idle"),r=Tt(s,"walk"),l=Tt(s,"attack"),c=t!=="idle"&&t!=="walk",d=e.anims.animationManager.exists(i)?i:e.anims.animationManager.exists(l)?l:"",u=e.getData("activeAttackKey")??"",f=e.anims.currentAnim?.key??"",m=e.anims.isPlaying&&f!==""&&f!==o&&f!==r,h=e.getData("attackDone")===!0;if(c){if(d){if(u!==d){e.setData("activeAttackKey",d),e.setData("attackDone",!1),e.play(d),e.anims&&(e.anims.timeScale=1);return}if(m)return;if(h){const g=n>0&&e.anims.animationManager.exists(r)?r:e.anims.animationManager.exists(o)?o:"";g&&(e.play(g,!0),e.anims&&(e.anims.timeScale=g===r?Math.max(.1,n):1));return}if(!e.anims.isPlaying&&f===d){e.setData("attackDone",!0);const g=n>0&&e.anims.animationManager.exists(r)?r:e.anims.animationManager.exists(o)?o:"";g&&(e.play(g,!0),e.anims&&(e.anims.timeScale=g===r?Math.max(.1,n):1));return}e.setData("activeAttackKey",d),e.setData("attackDone",!1),e.play(d),e.anims&&(e.anims.timeScale=1);return}}else if(e.setData("attackDone",!1),e.setData("activeAttackKey",""),m)return;const p=e.anims.animationManager.exists(i)?i:e.anims.animationManager.exists(o)?o:"";p&&(e.play(p,!0),e.anims&&(e.anims.timeScale=t==="walk"?Math.max(.1,n):1))}function l0(e){const s=Ya(e);if(!s)return[];const t=[];for(const[n,a]of Object.entries(s.anims))!a.frames||a.frames.length===0||t.push({name:n,frames:a.frames.map(String),duration:a.frames.length/Math.max(1,a.frameRate)*1e3});return t}function Es(e,s){const n=Ya(e)?.anims[s];return!n||!n.frames||n.frames.length===0?null:{name:s,frames:n.frames.map(String),duration:n.frames.length/Math.max(1,n.frameRate)*1e3}}function c0(e){const s=Or();if(!e||typeof e!="object")return s;const t=e,n={};if(t.entities&&typeof t.entities=="object")for(const[o,r]of Object.entries(t.entities)){const l=f0(r);l&&(n[o]=l)}const a=u0(t.envAtlas),i=d0(t.uiAtlas);return{entities:n,items:Mt(t.items),skills:Mt(t.skills),env:Mt(t.env),fx:Mt(t.fx),ui:Mt(t.ui),...a?{envAtlas:a}:{},...i?{uiAtlas:i}:{}}}function Ft(e){if(!e||typeof e!="object")return null;const s=e;return typeof s.x=="number"&&typeof s.y=="number"&&typeof s.w=="number"&&typeof s.h=="number"&&s.w>0&&s.h>0?{x:s.x,y:s.y,w:s.w,h:s.h}:null}function d0(e){if(!e||typeof e!="object")return;const s=e;if(typeof s.src!="string"||typeof s.width!="number"||typeof s.height!="number")return;const t={};if(s.frames&&typeof s.frames=="object")for(const[n,a]of Object.entries(s.frames)){if(!a||typeof a!="object")continue;const i=a,o=i.idle&&typeof i.idle=="object"?i.idle:i,r=Ft(o);if(!r)continue;const l=(i.hover&&typeof i.hover=="object"?Ft(i.hover):null)??r,c=(i.active&&typeof i.active=="object"?Ft(i.active):null)??r;t[n]={idle:r,hover:l,active:c}}return{src:s.src,width:s.width,height:s.height,frames:t}}function u0(e){if(!e||typeof e!="object")return;const s=e;if(typeof s.src!="string"||typeof s.width!="number"||typeof s.height!="number")return;const t={};if(s.frames&&typeof s.frames=="object")for(const[n,a]of Object.entries(s.frames)){const i=Ft(a);i&&(t[n]=i)}return{src:s.src,width:s.width,height:s.height,frames:t}}function f0(e){if(!e||typeof e!="object")return null;const s=e;if(typeof s.src!="string"||typeof s.frameWidth!="number"||typeof s.frameHeight!="number")return null;const t={};if(s.anims&&typeof s.anims=="object")for(const[n,a]of Object.entries(s.anims)){if(!a||typeof a!="object")continue;const i=a;!Array.isArray(i.frames)||i.frames.some(o=>typeof o!="number")||(t[n]={frames:i.frames,frameRate:typeof i.frameRate=="number"&&i.frameRate>0?i.frameRate:8,repeat:typeof i.repeat=="number"?i.repeat:-1})}return t.idle||(t.idle={frames:[0],frameRate:1,repeat:-1}),{src:s.src,frameWidth:s.frameWidth,frameHeight:s.frameHeight,anims:t}}function Mt(e){return Array.isArray(e)?e.filter(s=>typeof s=="string"&&s.length>0):[]}const m0=48,Ki=.2,h0=.7,p0=6750088;function Ka(e,s){if(!Ur(s))return null;const t=en(s);return e.textures.exists(t)?t:null}function g0(e,s,t){return e===We?t==="cinder"?"cinder-spit":"frost-spit":(s&Yt)!==0?"skill-condemn-tether":(s&dn)!==0?"skill-aether-pierce":(s&Kt)!==0?"skill-censer-lob":"bolt"}function y0(e){return e===gt?null:e===fn?"skill-crucible-cull":null}function v0(e,s,t){return e===_e?"hit":e===ne?"hurt":e===we?s===p0?"noxious-pop":"death":e===Ge?"muzzle":e===At?Ur(t)?t:"dash":null}function b0(e,s=m0){const t=[];for(let n=0;n<s;n+=1)t.push(e.add.image(0,0,"px-spark").setVisible(!1).setDepth(6).setAlpha(0));return{sprites:t,life:new Float32Array(s),max:new Float32Array(s)}}function x0(e,s,t,n,a,i){if(H().reduceVfx)return!1;const o=Ka(e,t);if(!o)return!1;for(let r=0;r<s.sprites.length;r+=1){if(s.life[r]>0)continue;const l=s.sprites[r];return l.texture.key!==o&&l.setTexture(o),tn(l),l.setPosition(n,a),l.setRotation(i),l.setAlpha(1),l.setVisible(!0),s.life[r]=Ki,s.max[r]=Ki,!0}return!1}function k0(e,s){for(let t=0;t<e.sprites.length;t+=1){if(e.life[t]<=0){e.sprites[t].visible&&e.sprites[t].setVisible(!1);continue}e.life[t]-=s;const n=e.max[t]>0?Math.max(0,e.life[t]/e.max[t]):0;e.sprites[t].setAlpha(n),e.life[t]<=0&&e.sprites[t].setVisible(!1)}}function S0(e,s,t,n,a){const i=g0(t.team[n],t.flags[n],a),o=Ka(e,i);if(o){s.texture.key!==o&&s.setTexture(o),s.clearTint(),tn(s),s.setRotation(Math.atan2(t.vy[n],t.vx[n])),s.setVisible(!0),s.setPosition(t.x[n],t.y[n]);return}const r=C0(t.team[n],a);s.texture.key!==r&&s.setTexture(r),s.setRotation(0),M0(s,t.team[n],t.flags[n]),s.setVisible(!0),s.setPosition(t.x[n],t.y[n])}function E0(e,s,t){for(let n=0;n<s.length;n+=1){const a=s[n];if(t.alive[n]===0){a.setVisible(!1);continue}const i=y0(t.kind[n]),o=i?Ka(e,i):null;if(!i||!o){a.setVisible(!1);continue}if(a.texture.key!==o&&a.setTexture(o),a.clearTint(),a.setVisible(!0),a.setPosition(t.x[n],t.y[n]),t.kind[n]===fn){const r=Math.max(.25,1-t.remain[n]/h0);tn(a,r),a.setRotation(0)}else tn(a),a.setRotation(Math.atan2(t.dirY[n],t.dirX[n]))}}function tn(e,s=1){const t=e.frame?.width??32,n=e.frame?.height??29;e.setDisplaySize(t*s,n*s)}function C0(e,s){return e===We?s==="cinder"?"px-bolt-enemy-cinder":"px-bolt-enemy-rime":"px-bolt-player"}function M0(e,s,t){const n=e.frame?.width??8,a=e.frame?.height??8;if(s===We){e.clearTint(),e.setDisplaySize(n,a);return}if((t&Yt)!==0){e.setTint(12886106),e.setDisplaySize(n*1.6,a*1.6);return}if((t&dn)!==0){e.setTint(8978431),e.setDisplaySize(n*1.5,a*.7);return}if((t&Kt)!==0){e.setTint(16755285),e.setDisplaySize(n*1.3,a*1.3);return}e.clearTint(),e.setDisplaySize(n,a)}const w0=["cinder","rime","glacial"];function R0(e){a0(e),n0(e),om().forEach((o,r)=>sn(e,r,o));const{width:t,height:n}=E.world,a=o0(e),i=i0();for(const o of w0)sn(e,Ys(o),lm(o,t,n,a,i?.frames));T0(e,a,i?.frames),P0(e),I0(e)}function T0(e,s,t){if(!s||!t)return;const n=["cinder-hazard-0","rime-hazard-0"];for(const a of n){const i=t[a];if(!i||i.w===0||i.h===0)continue;const o=a.startsWith("rime")?"rime":"cinder",r=A0(s,i,o);r&&(sn(e,`env-blended-${a}`,r),a==="rime-hazard-0"&&sn(e,"env-blended-glacial-hazard-0",r))}}function A0(e,s,t){if(typeof document>"u")return null;const n=document.createElement("canvas");n.width=s.w,n.height=s.h;const a=n.getContext("2d");if(!a)return null;a.imageSmoothingEnabled=!1,a.drawImage(e,s.x,s.y,s.w,s.h,0,0,s.w,s.h);const i=a.getImageData(0,0,s.w,s.h),o=i.data,r=s.w*.5,l=s.h*.5;for(let c=0;c<s.h;c++)for(let d=0;d<s.w;d++){const u=(c*s.w+d)*4,f=o[u+3];if(f===0)continue;const m=o[u],h=o[u+1],p=o[u+2],g=(d-r+.5)/r,v=(c-l+.5)/l,y=Math.hypot(g,v),b=t==="rime"&&v<-.12&&h>140&&(m>120||p>140),C=Math.max(m,h,p)<72?.5:b?.72:.62,M=b?1.05:.95;let w=1;if(y>C){const R=Math.min(1,(y-C)/Math.max(.01,M-C));w=1-R*R*(3-2*R)}o[u+3]=Math.round(f*w)}return a.putImageData(i,0,0),n}function I0(e){for(const[s,t]of nm()){Jh(s,{frameWidth:t.frameWidth,frameHeight:t.frameHeight,anims:t.anims});const n=Z(s);e.textures.exists(n)||D0(e,n,t.canvas,t.frameWidth,t.frameHeight)}}function D0(e,s,t,n,a){if(e.textures.exists(s))return;const i=e.textures.createCanvas(s,t.width,t.height);if(!i)throw new Error(`Failed to create texture ${s}`);const o=i.getContext();o.imageSmoothingEnabled=!1,o.clearRect(0,0,t.width,t.height),o.drawImage(t,0,0),i.refresh();const r=Math.max(1,Math.floor(t.width/n)),l=Math.max(1,Math.floor(t.height/a));let c=0;for(let d=0;d<l;d+=1)for(let u=0;u<r;u+=1)i.add(c,0,u*n,d*a,n,a),c+=1}function sn(e,s,t){if(e.textures.exists(s))return;const n=e.textures.createCanvas(s,t.width,t.height);if(!n)throw new Error(`Failed to create texture ${s}`);const a=n.getContext();a.imageSmoothingEnabled=!1,a.clearRect(0,0,t.width,t.height),a.drawImage(t,0,0),n.refresh()}function P0(e){if(typeof document>"u")return;const s=Qh();if(s?.entities)for(const[t,n]of Object.entries(s.entities)){const a=Z(t);if(!e.textures.exists(a))continue;const i=e.textures.get(a),o=i.getSourceImage();if(!o||!o.width||!o.height)continue;const r=n.frameWidth||o.height,l=n.frameHeight||o.height,c=o.width,d=o.height,u=document.createElement("canvas");u.width=c,u.height=d;const f=u.getContext("2d",{willReadFrequently:!0});if(!f)continue;f.imageSmoothingEnabled=!1,f.drawImage(o,0,0);const m=f.getImageData(0,0,c,d),h=m.data,p=t==="runner"||t==="penitent",g=t.startsWith("cinder")||t.startsWith("ember"),v=p||g?255:190,y=p?236:g?175:230,b=p?180:g?110:255,x=p?115:g?90:80,k=Math.floor(c/r),C=Math.floor(d/l);for(let M=0;M<C;M++)for(let w=0;w<k;w++){const R=w*r,D=M*l;for(let L=0;L<l;L++)for(let U=0;U<r;U++){const _=R+U,G=D+L,N=(G*c+_)*4,Se=h[N+3];if(Se>128){const tt=U>0&&h[(G*c+(_-1))*4+3]>128,es=U<r-1&&h[(G*c+(_+1))*4+3]>128,Ie=L>0&&h[((G-1)*c+_)*4+3]>128,ts=L<l-1&&h[((G+1)*c+_)*4+3]>128;if(tt&&es&&Ie&&ts){const ss=.299*h[N]+.587*h[N+1]+.114*h[N+2];if(ss<72){const xt=Math.round((72-ss)*.35);h[N]=Math.min(255,h[N]+xt),h[N+1]=Math.min(255,h[N+1]+xt),h[N+2]=Math.min(255,h[N+2]+xt)}}}else Se<32&&U>0&&U<r-1&&L>0&&L<l-1&&(h[(G*c+(_-1))*4+3]>128||h[(G*c+(_+1))*4+3]>128||h[((G-1)*c+_)*4+3]>128||h[((G+1)*c+_)*4+3]>128)&&(h[N]=v,h[N+1]=y,h[N+2]=b,h[N+3]=x)}}f.putImageData(m,0,0),i.setSource(u)}}const L0=`
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

varying vec2 outTexCoord;

uniform float uTime;
uniform float uBiome;
uniform vec2 uViewOrigin;
uniform vec2 uViewSize;

float hash21(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}

vec2 hash22(vec2 p) {
  float n = hash21(p);
  return vec2(n, hash21(p + n + 19.19));
}

float valueNoise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
  float v = 0.0;
  v += 0.55 * valueNoise(p);
  v += 0.30 * valueNoise(p * 2.07 + vec2(13.1, 7.7));
  v += 0.15 * valueNoise(p * 4.13 + vec2(3.7, 29.3));
  return v;
}

float particleLayer(vec2 worldPos, float cellSize, vec2 vel, float radius, float seed, float pulseSpeed) {
  vec2 p = (worldPos + vel * uTime) / cellSize;
  vec2 cell = floor(p);
  vec2 local = fract(p) - 0.5;
  vec2 rnd = hash22(cell + seed);
  if (rnd.x < 0.68) return 0.0;
  vec2 offset = (rnd - 0.5) * 0.62;
  offset.x += sin(uTime * pulseSpeed + rnd.y * 6.2831) * 0.12;
  float d = length(local - offset);
  float core = smoothstep(radius, radius * 0.15, d);
  float twinkle = 0.65 + 0.35 * sin(uTime * (pulseSpeed * 1.4) + rnd.x * 12.0);
  return core * twinkle;
}

void main() {
  vec2 uv = vec2(outTexCoord.x, 1.0 - outTexCoord.y);
  vec2 worldPos = uViewOrigin + uv * uViewSize;

  vec2 qWorld = worldPos;

  // Ground mist / kiln smoke (FBM)
  vec2 mistDrift = uBiome < 0.5 ? vec2(-14.0, -9.0) : vec2(18.0, 11.0);
  float mist1 = fbm((qWorld + mistDrift * uTime) * 0.0045);
  float mist2 = fbm((qWorld - mistDrift * 0.6 * uTime + vec2(91.0, 43.0)) * 0.008);
  float mist = smoothstep(0.46, 0.78, mist1 * 0.65 + mist2 * 0.35);

  vec3 col = vec3(0.0);
  float alpha = 0.0;

  if (uBiome < 0.5) {
    // Cinder Yard: warm ash haze + drifting ash + rising glowing embers
    vec3 smokeCol = vec3(0.24, 0.11, 0.08);
    float smokeA = mist * 0.14;
    col += smokeCol * smokeA;
    alpha += smokeA;

    float ash = particleLayer(qWorld, 115.0, vec2(13.0, -11.0), 0.052, 11.3, 1.6)
              + particleLayer(qWorld, 165.0, vec2(9.0, -7.0), 0.042, 37.9, 1.2) * 0.65;
    vec3 ashCol = vec3(0.58, 0.49, 0.44);
    float ashA = clamp(ash, 0.0, 1.0) * 0.34;
    col += ashCol * ashA;
    alpha += ashA;

    float ember = particleLayer(qWorld, 140.0, vec2(5.0, 24.0), 0.060, 73.1, 3.2)
                + particleLayer(qWorld, 200.0, vec2(-7.0, 31.0), 0.050, 109.7, 2.7);
    float emberClamped = clamp(ember, 0.0, 1.0);
    vec3 emberCol = mix(vec3(1.0, 0.38, 0.12), vec3(1.0, 0.88, 0.45), emberClamped);
    float emberA = emberClamped * 0.62;
    col += emberCol * emberA;
    alpha += emberA;
  } else {
    // Rime Dock / Glacial Tomb: cold brine fog + wind-driven snow + ice glints
    vec3 fogCol = vec3(0.32, 0.62, 0.84);
    float fogA = mist * 0.16;
    col += fogCol * fogA;
    alpha += fogA;

    float snow1 = particleLayer(qWorld, 110.0, vec2(-22.0, -18.0), 0.052, 19.7, 1.8);
    float snow2 = particleLayer(qWorld, 160.0, vec2(-15.0, -13.0), 0.045, 53.4, 1.3);
    float snow = clamp(snow1 + snow2 * 0.8, 0.0, 1.0);
    vec3 snowCol = vec3(0.86, 0.95, 1.0);
    float snowA = snow * 0.42;
    col += snowCol * snowA;
    alpha += snowA;

    float glint = particleLayer(qWorld, 185.0, vec2(-9.0, -6.0), 0.040, 141.2, 4.0);
    vec3 glintCol = vec3(0.55, 0.92, 1.0);
    float glintA = clamp(glint, 0.0, 1.0) * 0.50;
    col += glintCol * glintA;
    alpha += glintA;
  }

  alpha = clamp(alpha, 0.0, 0.78);
  gl_FragColor = vec4(col, alpha);
}
`;class N0{constructor(s){S(this,"quad");S(this,"time",0);S(this,"biomeVal",0);S(this,"viewOrigin",[0,0]);S(this,"viewSize",[800,450]);this.quad=s.add.shader({name:"AmbientAtmosphereShader",shaderName:"AmbientAtmosphereShader",fragmentSource:L0,setupUniforms:t=>{t("uTime",this.time),t("uBiome",this.biomeVal),t("uViewOrigin",this.viewOrigin),t("uViewSize",this.viewSize)}},0,0,128,128).setDepth(8)}sync(s,t,n){const a=s.worldView,i=16,o=Math.max(64,a.width+i*2),r=Math.max(64,a.height+i*2);this.time=t,this.biomeVal=n==="cinder"?0:1,this.viewOrigin[0]=a.x-i,this.viewOrigin[1]=a.y-i,this.viewSize[0]=o,this.viewSize[1]=r,this.quad.setSize(o,r),this.quad.setOrigin(.5,.5),this.quad.setPosition(a.centerX,a.centerY)}}const F0=`
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

varying vec2 outTexCoord;

uniform float uTime;
uniform float uAttack;
uniform float uFacing;
uniform float uEnraged;

float hash21(vec2 p) {
  p = fract(p * vec2(127.1, 311.7));
  p += dot(p, p + 34.5);
  return fract(p.x * p.y);
}

float vnoise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
  return 0.58 * vnoise(p) + 0.28 * vnoise(p * 2.05 + vec2(7.3, 3.1)) + 0.14 * vnoise(p * 4.1 + vec2(11.7, 9.5));
}

void main() {
  // Quantize coordinates to exact 28x32 pixel grid matching boss sprite resolution (1:1)
  const vec2 GRID = vec2(28.0, 32.0);
  vec2 rawUv = vec2(outTexCoord.x, 1.0 - outTexCoord.y);
  vec2 uv = (floor(rawUv * GRID) + 0.5) / GRID;

  // Narrow, gentle plume geometry rising from top furnace vent
  float width = mix(0.14, 0.38, pow(clamp(uv.y, 0.0, 1.0), 0.75));
  float sway = sin(uv.y * 5.0 - uTime * (1.6 + uAttack * 0.8)) * 0.04;
  sway += uFacing * 0.02 * uv.y;

  float dx = abs(uv.x - 0.5 - sway);
  float cone = smoothstep(width, width * 0.25, dx);

  // Soft vertical fades: gentle release at bottom, evaporation at top
  float bottomFade = smoothstep(0.04, 0.18, uv.y);
  float topFade = smoothstep(0.96, 0.60, uv.y);
  float plumeMask = cone * bottomFade * topFade;

  if (plumeMask <= 0.02) {
    gl_FragColor = vec4(0.0);
    return;
  }

  // Gentle, slow upward smoke motion
  float riseSpeed = mix(1.2, 2.2, uAttack);
  vec2 flow = vec2(-sway * 1.2, -uTime * riseSpeed);
  vec2 p = vec2((uv.x - 0.5) * 3.4, uv.y * 2.8) + flow;

  float smokeNoise = fbm(p);

  // Discrete pixel-art opacity steps for light smoke
  float densityCut = mix(0.44, 0.36, uAttack);
  float rawDensity = smoothstep(densityCut, 0.78, smokeNoise) * plumeMask;
  if (rawDensity <= 0.04) {
    gl_FragColor = vec4(0.0);
    return;
  }

  // Resurrect 64 soot & cool chimney smoke palette
  // Dark kiln soot:   #181014 vec3(0.094, 0.063, 0.078)
  // Cool charcoal:    #2e222f vec3(0.180, 0.133, 0.184)
  // Ash smoke mid:    #3e3546 vec3(0.243, 0.208, 0.275)
  // Pale wisps:       #625565 vec3(0.384, 0.333, 0.396)
  vec3 sootDark = vec3(0.094, 0.063, 0.078);
  vec3 sootCharcoal = vec3(0.180, 0.133, 0.184);
  vec3 ashMid = vec3(0.243, 0.208, 0.275);
  vec3 wispLight = vec3(0.384, 0.333, 0.396);

  vec3 smokeCol = mix(sootCharcoal, ashMid, smokeNoise);
  smokeCol = mix(smokeCol, wispLight, smoothstep(width * 0.4, width, dx) * 0.45);

  // Subtle warm ember glow at very base of vent
  float emberBase = smoothstep(0.22, 0.04, uv.y) * (0.6 + 0.4 * uAttack);
  vec3 emberCol = vec3(0.969, 0.588, 0.090); // Resurrect 64 ember
  smokeCol = mix(smokeCol, emberCol, emberBase * 0.35);

  // Light, non-intrusive transparency
  float maxAlpha = mix(0.34, 0.52, uAttack + uEnraged * 0.12);
  float alpha = clamp(rawDensity * maxAlpha, 0.0, 0.60);

  gl_FragColor = vec4(smokeCol * alpha, alpha);
}
`;class B0{constructor(s){S(this,"quad");S(this,"time",0);S(this,"attackIntensity",0);S(this,"facing",1);S(this,"enraged",0);this.quad=s.add.shader({name:"CinderSmokeShader",shaderName:"CinderSmokeShader",fragmentSource:F0,setupUniforms:t=>{t("uTime",this.time),t("uAttack",this.attackIntensity),t("uFacing",this.facing),t("uEnraged",this.enraged)}},0,0,28,32).setOrigin(.5,.92).setDepth(3.05).setVisible(!1)}sync(s,t){const{boss:n,enemies:a}=s,i=n.enemyIndex;if(i<0||a.alive[i]===0){this.quad.setVisible(!1),this.attackIntensity=0;return}if(a.defId[i]!=="cinder-heart"){this.quad.setVisible(!1),this.attackIntensity=0;return}this.time=s.runTime,this.facing=a.facing[i]<0?-1:1,this.enraged=n.enraged?1:0;const r=Pt(s,i)||n.phase==="windup"||n.phase==="channel",l=r?1:0,c=r?8:3.5;this.attackIntensity+=(l-this.attackIntensity)*Math.min(1,t*c);const d=Math.round(a.x[i]),u=Math.round(a.y[i]-20),f=3.2+Math.max(0,Math.min(1,a.y[i]/2560))*1.6;this.quad.setPosition(d,u).setDepth(f+2e-4).setVisible(!0)}}const H0=`
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

varying vec2 outTexCoord;

uniform float uTime;
uniform float uKind;
uniform float uStyle;
uniform float uState;
uniform float uProgress;
uniform float uAngle;
uniform vec2 uDir;

float hash21(vec2 p) {
  p = fract(p * vec2(127.1, 311.7));
  p += dot(p, p + 34.5);
  return fract(p.x * p.y);
}

float vnoise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
  return 0.55 * vnoise(p) + 0.30 * vnoise(p * 2.1 + 11.3) + 0.15 * vnoise(p * 4.3 + 27.1);
}

vec2 hash22(vec2 p) {
  float n = hash21(p);
  return vec2(n, hash21(p + n + 19.19));
}

// Boiling pixelated bubble burst cell matching environmental hazard
float bubbleLayer(vec2 p, float speed, float scale, out float bubbleBody, out float bubbleRing, out float bubbleSpec) {
  vec2 sp = p * scale;
  vec2 cell = floor(sp);
  vec2 local = fract(sp) - 0.5;
  vec2 rnd = hash22(cell);

  float lifeTime = fract(uTime * speed + rnd.x * 6.28);
  float grow = sin(clamp(lifeTime / 0.88, 0.0, 1.0) * 3.14159);
  grow = pow(grow, 0.75);
  float radius = grow * (0.34 + rnd.y * 0.14);

  vec2 offset = (rnd - 0.5) * 0.28;
  vec2 diff = local - offset;
  float d = length(diff);

  float active = step(0.05, radius) * step(lifeTime, 0.94);
  bubbleBody = step(d, radius) * active;
  bubbleRing = step(radius - 0.09, d) * bubbleBody;
  
  float specDist = length(diff - vec2(-radius * 0.32, -radius * 0.32));
  bubbleSpec = step(specDist, max(0.04, radius * 0.25)) * bubbleBody * (1.0 - bubbleRing);
  return bubbleBody;
}

void main() {
  vec2 uv = vec2(outTexCoord.x, 1.0 - outTexCoord.y);
  vec2 p = (uv - 0.5) * 2.0;
  float r = length(p);
  float ang = atan(p.y, p.x);

  vec3 col = vec3(0.0);
  float alpha = 0.0;

  // 0: HAZ_METEOR (falling clinker / hailstone telegraph circle)
  if (uKind < 0.5) {
    if (r > 1.02) {
      gl_FragColor = vec4(0.0);
      return;
    }
    float outerRing = smoothstep(0.06, 0.0, abs(r - 0.96));
    float fillR = clamp(uProgress, 0.08, 1.0) * 0.96;
    float fillEdge = smoothstep(0.04, 0.0, abs(r - fillR));
    float cracks = fbm(p * 4.5 + vec2(uTime * 0.8, -uTime * 0.6));
    float innerFill = step(r, fillR) * (0.20 + 0.32 * uProgress + 0.25 * cracks);
    float urgent = uProgress > 0.72 ? (0.5 + 0.5 * sin(uTime * 28.0)) : 0.0;

    vec3 baseCol = uStyle < 0.5 ? vec3(1.0, 0.42, 0.12) : vec3(0.42, 0.82, 1.0);
    vec3 hotCol = uStyle < 0.5 ? vec3(1.0, 0.92, 0.65) : vec3(0.92, 0.98, 1.0);

    alpha = clamp(outerRing * 0.92 + fillEdge * 0.85 + innerFill, 0.0, 0.95);
    col = mix(baseCol, hotCol, clamp(outerRing + fillEdge * 0.7 + urgent * 0.5, 0.0, 1.0));
  }
  // 1: HAZ_POOL (bubbling lava or crystalline frost puddle)
  else if (uKind < 1.5) {
    float fade = 1.0 - smoothstep(0.75, 1.0, uProgress);
    if (uStyle < 0.5) {
      // Lava Pool from Cinder Heart meteor:
      // Resurrect 64 palette + slow movement + clean discrete magma crater
      const float GRID = 64.0;
      vec2 uvGrid = (floor(uv * GRID) + 0.5) / GRID;
      vec2 pGrid = (uvGrid - 0.5) * 2.0;
      float rGrid = length(pGrid);

      if (rGrid > 1.0) {
        gl_FragColor = vec4(0.0);
        return;
      }

      float boilSpeed = 0.14;
      float animTime = uTime * boilSpeed;

      float edgeNoise = fbm(pGrid * 2.5 + vec2(sin(animTime * 0.8), cos(animTime * 0.6)) * 0.35);
      float poolR = 0.86 + (edgeNoise - 0.5) * 0.14;
      float poolMask = smoothstep(poolR, poolR - 0.14, rGrid);

      if (poolMask <= 0.01) {
        gl_FragColor = vec4(0.0);
        return;
      }

      vec2 flow = vec2(
        fbm(pGrid * 1.6 + vec2(animTime * 0.2, -animTime * 0.16)),
        fbm(pGrid * 1.6 + vec2(-animTime * 0.16, animTime * 0.2))
      );
      float surface = fbm(pGrid * 2.4 + flow * 0.8);

      // Resurrect 64 lava palette:
      vec3 crust = vec3(0.180, 0.094, 0.082);      // #2e1815
      vec3 deepMagma = vec3(0.620, 0.157, 0.208);  // #9e2835
      vec3 magmaDeep = vec3(0.918, 0.310, 0.212);  // #ea4f36
      vec3 lavaEmber = vec3(0.969, 0.588, 0.090);  // #f79617
      vec3 lavaGlint = vec3(0.976, 0.761, 0.169);  // #f9c22b

      float heatVeins = step(0.48, surface);
      vec3 fluid = mix(crust, magmaDeep, surface);
      fluid = mix(fluid, deepMagma, (1.0 - surface) * 0.45);
      fluid = mix(fluid, lavaEmber, heatVeins * 0.65);

      // Fine micro-fissure sparks
      float sparkNoise = fbm(pGrid * 7.0 - vec2(animTime * 0.8, -animTime * 0.6));
      float sparkGlow = step(0.76, sparkNoise);
      fluid = mix(fluid, lavaGlint, sparkGlow * 0.8);

      col = fluid;
      alpha = clamp((0.40 + surface * 0.38 + sparkGlow * 0.2) * poolMask * fade * 0.92, 0.0, 0.92);
    } else {
      // Crystalline rime pool
      float n = fbm(p * 3.8 + vec2(uTime * 0.65, -uTime * 0.45));
      float edgeR = 0.88 + (n - 0.5) * 0.18;
      if (r > edgeR) {
        gl_FragColor = vec4(0.0);
        return;
      }
      float rim = smoothstep(edgeR, edgeR - 0.14, r);
      float veins = fbm(p * 7.2 - vec2(uTime * 1.1, uTime * 0.8));
      float shard = smoothstep(0.45, 0.75, veins);
      vec3 deepIce = vec3(0.16, 0.42, 0.68);
      vec3 rime = mix(vec3(0.45, 0.84, 1.0), vec3(0.92, 0.98, 1.0), shard);
      col = mix(deepIce, rime, shard);
      alpha = rim * fade * 0.68;
    }
  }
  // 2: HAZ_PRISON (Rime Prison closing ice ring + spikes)
  else if (uKind < 2.5) {
    if (r > 1.04) {
      gl_FragColor = vec4(0.0);
      return;
    }
    float teeth = 0.045 * cos(ang * 12.0 + uTime * 3.0);
    if (uState < 0.5) {
      float outerRing = smoothstep(0.05, 0.0, abs(r - 0.95));
      float closeR = max(0.14, (1.0 - uProgress * 0.82) * 0.95 + teeth);
      float closingRing = smoothstep(0.065, 0.0, abs(r - closeR));
      float frostWeb = step(closeR, r) * step(r, 0.95) * 0.22;
      float flash = uProgress > 0.75 ? (0.5 + 0.5 * sin(uTime * 30.0)) : 0.0;
      vec3 iceCol = mix(vec3(0.35, 0.82, 1.0), vec3(0.95, 0.99, 1.0), clamp(closingRing + flash * 0.5, 0.0, 1.0));
      alpha = clamp(outerRing * 0.85 + closingRing * 0.95 + frostWeb, 0.0, 0.95);
      col = iceCol;
    } else {
      // Snapped shut: jagged ice cage fade-out
      float fade = 1.0 - uProgress;
      float cage = smoothstep(0.08, 0.0, abs(r - (0.38 + teeth * 1.6))) + step(r, 0.38) * 0.45;
      col = vec3(0.82, 0.96, 1.0);
      alpha = clamp(cage * fade, 0.0, 0.9);
    }
  }
  // 3: HAZ_CONE (Glacial Sweep directional frost mist cone)
  else if (uKind < 3.5) {
    if (r > 1.0 || r < 0.04) {
      gl_FragColor = vec4(0.0);
      return;
    }
    vec2 dir = normalize(uDir);
    float cosHalf = cos(uAngle * 0.5);
    float dotDir = dot(p / r, dir);
    if (dotDir < cosHalf) {
      gl_FragColor = vec4(0.0);
      return;
    }
    float angFactor = clamp((dotDir - cosHalf) / max(0.001, 1.0 - cosHalf), 0.0, 1.0);
    float edgeBorder = smoothstep(0.08, 0.0, angFactor) + smoothstep(0.05, 0.0, abs(r - 0.97));
    float radialFlow = fbm(vec2(r * 5.0 - uTime * 3.6, ang * 3.5));

    if (uState < 0.5) {
      // Windup telegraph: sweeping frost lines + filling wedge
      float sweep = step(r, clamp(uProgress, 0.1, 1.0)) * (0.18 + 0.22 * radialFlow);
      col = mix(vec3(0.38, 0.82, 1.0), vec3(0.92, 0.98, 1.0), edgeBorder);
      alpha = clamp(edgeBorder * 0.78 + sweep, 0.0, 0.85);
    } else {
      // Active blizzard burst
      float fade = 1.0 - smoothstep(0.4, 1.0, uProgress);
      float radialFade = smoothstep(1.0, 0.72, r) * smoothstep(0.0, 0.18, angFactor);
      float cloud = (0.45 + 0.55 * radialFlow) * radialFade;
      col = mix(vec3(0.48, 0.86, 1.0), vec3(0.96, 0.99, 1.0), radialFlow);
      alpha = clamp(cloud * fade * 0.85, 0.0, 0.9);
    }
  }

  gl_FragColor = vec4(col * alpha, alpha);
}
`,$0=`
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

varying vec2 outTexCoord;

uniform float uTime;
uniform float uState;
uniform float uProgress;
uniform float uRadius;
uniform mat4 uPillars0;
uniform mat4 uPillars1;
uniform mat4 uPillars2;
uniform mat4 uPillars3;

bool rayBlockedByPillar(vec2 target, vec4 pil) {
  if (pil.w < 0.5) return false;
  float len = length(target);
  if (len < 1.0) return false;
  vec2 dir = target / len;
  float proj = dot(pil.xy, dir);
  if (proj <= 0.0 || proj >= len) return false;
  vec2 closest = dir * proj;
  float distSq = dot(pil.xy - closest, pil.xy - closest);
  return distSq <= pil.z * pil.z;
}

bool isShadowed(vec2 pos) {
  if (rayBlockedByPillar(pos, uPillars0[0])) return true;
  if (rayBlockedByPillar(pos, uPillars0[1])) return true;
  if (rayBlockedByPillar(pos, uPillars0[2])) return true;
  if (rayBlockedByPillar(pos, uPillars0[3])) return true;
  if (rayBlockedByPillar(pos, uPillars1[0])) return true;
  if (rayBlockedByPillar(pos, uPillars1[1])) return true;
  if (rayBlockedByPillar(pos, uPillars1[2])) return true;
  if (rayBlockedByPillar(pos, uPillars1[3])) return true;
  if (rayBlockedByPillar(pos, uPillars2[0])) return true;
  if (rayBlockedByPillar(pos, uPillars2[1])) return true;
  if (rayBlockedByPillar(pos, uPillars2[2])) return true;
  if (rayBlockedByPillar(pos, uPillars2[3])) return true;
  if (rayBlockedByPillar(pos, uPillars3[0])) return true;
  if (rayBlockedByPillar(pos, uPillars3[1])) return true;
  return false;
}

void main() {
  vec2 uv = vec2(outTexCoord.x, 1.0 - outTexCoord.y);
  vec2 p = (uv - 0.5) * 2.0;
  float r = length(p);
  if (r > 1.0) {
    gl_FragColor = vec4(0.0);
    return;
  }

  vec2 worldOffset = p * uRadius;
  bool shadowed = isShadowed(worldOffset);

  vec3 col = vec3(0.0);
  float alpha = 0.0;

  if (uState < 0.5) {
    float outerRing = smoothstep(0.015, 0.0, abs(r - 0.985));
    float waveR = clamp(uProgress, 0.05, 1.0) * 0.985;
    float waveEdge = smoothstep(0.025, 0.0, abs(r - waveR));
    float ripples = 0.5 + 0.5 * sin(r * 28.0 - uTime * 10.0);

    if (shadowed) {
      // Safe shelter shadow behind pillar: calm warm-emerald tint so player sees cover
      col = vec3(0.25, 0.85, 0.62);
      alpha = (0.10 + 0.06 * uProgress) * smoothstep(1.0, 0.85, r);
    } else {
      float dangerFill = (0.10 + 0.16 * uProgress + 0.06 * ripples) * smoothstep(1.0, 0.92, r);
      float flash = uProgress > 0.78 ? (0.5 + 0.5 * sin(uTime * 32.0)) : 0.0;
      col = mix(vec3(0.32, 0.76, 1.0), vec3(0.92, 0.98, 1.0), clamp(outerRing + waveEdge + flash * 0.45, 0.0, 1.0));
      alpha = clamp(outerRing * 0.85 + waveEdge * 0.75 + dangerFill, 0.0, 0.82);
    }
  } else {
    // Detonation shockwave
    if (shadowed) {
      gl_FragColor = vec4(0.0);
      return;
    }
    float fade = 1.0 - uProgress;
    float shockR = 0.25 + uProgress * 0.75;
    float ring = smoothstep(0.08, 0.0, abs(r - shockR));
    col = vec3(0.85, 0.97, 1.0);
    alpha = clamp((ring * 0.85 + 0.22) * fade, 0.0, 0.88);
  }

  gl_FragColor = vec4(col * alpha, alpha);
}
`,_0=`
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

varying vec2 outTexCoord;

uniform float uTime;
uniform float uChanneling;
uniform float uProgress;

void main() {
  vec2 uv = vec2(outTexCoord.x, 1.0 - outTexCoord.y);
  float along = uv.x;
  float across = (uv.y - 0.5) * 2.0;

  vec3 col = vec3(0.0);
  float alpha = 0.0;

  if (uChanneling < 0.5) {
    // Lock-on telegraph beam
    float width = mix(0.18, 0.06, uProgress);
    float line = smoothstep(width, 0.0, abs(across));
    float dash = step(0.35, fract(along * 14.0 - uTime * 6.0));
    float flash = uProgress > 0.7 ? (0.5 + 0.5 * sin(uTime * 34.0)) : 0.0;
    col = mix(vec3(0.45, 0.85, 1.0), vec3(1.0, 0.96, 1.0), flash);
    alpha = line * (0.45 + 0.45 * dash);
  } else {
    // Active Aether Laser beam: plasma core + dual helical arcs + end flare
    float wave1 = sin(along * 22.0 - uTime * 24.0) * 0.22;
    float wave2 = cos(along * 17.0 + uTime * 19.0) * 0.18;
    float core = smoothstep(0.28, 0.03, abs(across));
    float outerGlow = smoothstep(0.88, 0.12, abs(across)) * 0.55;
    float arc1 = smoothstep(0.11, 0.0, abs(across - wave1)) * 0.75;
    float arc2 = smoothstep(0.10, 0.0, abs(across - wave2)) * 0.65;

    float endDist = length(vec2((along - 0.96) * 6.5, across));
    float endFlare = smoothstep(0.85, 0.05, endDist);

    float intensity = clamp(core + outerGlow + arc1 + arc2 + endFlare, 0.0, 1.0);
    col = mix(vec3(0.28, 0.72, 1.0), vec3(0.95, 0.99, 1.0), clamp(core + endFlare * 0.7, 0.0, 1.0));
    alpha = clamp(intensity * 0.92, 0.0, 0.95);
  }

  gl_FragColor = vec4(col * alpha, alpha);
}
`,Xn=14;class G0{constructor(s){S(this,"time",0);S(this,"hazardSlots",[]);S(this,"pulseQuad");S(this,"pulseState",0);S(this,"pulseProgress",0);S(this,"pulseRadius",620);S(this,"pillars0",new Array(16).fill(0));S(this,"pillars1",new Array(16).fill(0));S(this,"pillars2",new Array(16).fill(0));S(this,"pillars3",new Array(16).fill(0));S(this,"laserQuad");S(this,"laserChanneling",0);S(this,"laserProgress",0);S(this,"cinderSmoke");for(let t=0;t<Xn;t+=1){const n={quad:null,kind:0,style:0,state:0,progress:0,angle:1,dir:[1,0]};n.quad=s.add.shader({name:"BossHazardShader",shaderName:"BossHazardShader",fragmentSource:H0,setupUniforms:a=>{a("uTime",this.time),a("uKind",n.kind),a("uStyle",n.style),a("uState",n.state),a("uProgress",n.progress),a("uAngle",n.angle),a("uDir",n.dir)}},0,0,64,64).setDepth(2).setVisible(!1),this.hazardSlots.push(n)}this.pulseQuad=s.add.shader({name:"BossPulseShader",shaderName:"BossPulseShader",fragmentSource:$0,setupUniforms:t=>{t("uTime",this.time),t("uState",this.pulseState),t("uProgress",this.pulseProgress),t("uRadius",this.pulseRadius),t("uPillars0",this.pillars0),t("uPillars1",this.pillars1),t("uPillars2",this.pillars2),t("uPillars3",this.pillars3)}},0,0,128,128).setDepth(2).setVisible(!1),this.laserQuad=s.add.shader({name:"BossLaserShader",shaderName:"BossLaserShader",fragmentSource:_0,setupUniforms:t=>{t("uTime",this.time),t("uChanneling",this.laserChanneling),t("uProgress",this.laserProgress)}},0,0,128,48).setDepth(5.5).setVisible(!1),this.cinderSmoke=new B0(s)}sync(s,t=1/60){this.time=s.runTime,this.cinderSmoke.sync(s,t);const n=s.bossHazards;let a=0,i=-1;for(let o=0;o<n.cap;o+=1){if(n.alive[o]===0)continue;if(n.kind[o]===Ia){i=o;continue}if(a>=Xn)continue;const r=this.hazardSlots[a];a+=1;const l=n.kind[o],c=n.radius[o],d=n.duration[o]>0?n.duration[o]:1;r.kind=l===Ra?0:l===Us?1:l===Ta?2:l===Aa?3:0,r.style=n.style[o],r.state=n.state[o],r.progress=Math.min(1,Math.max(0,n.elapsed[o]/d)),r.angle=n.angle[o],r.dir[0]=n.dirX[o],r.dir[1]=n.dirY[o];const u=c*2;r.quad.setVisible(!0).setSize(u,u).setOrigin(.5,.5).setPosition(Math.round(n.x[o]),Math.round(n.y[o]))}for(let o=a;o<Xn;o+=1)this.hazardSlots[o].quad.setVisible(!1);if(i>=0){const o=n.x[i],r=n.y[i],l=n.radius[i],c=n.duration[i]>0?n.duration[i]:1;this.pulseState=n.state[i],this.pulseProgress=Math.min(1,Math.max(0,n.elapsed[i]/c)),this.pulseRadius=l,this.fillPillarMatrices(s,o,r),this.pulseQuad.setVisible(!0).setSize(l*2,l*2).setOrigin(.5,.5).setPosition(Math.round(o),Math.round(r))}else this.pulseQuad.setVisible(!1);this.syncLaser(s)}syncLaser(s){const{boss:t,enemies:n}=s,a=t.enemyIndex;if(a<0||n.alive[a]===0||t.activeAttack<0||t.phase==="none"){this.laserQuad.setVisible(!1);return}const i=n.defId[a];if(!i){this.laserQuad.setVisible(!1);return}const o=s.catalog.entity(i).ai;if(o.type!=="boss"){this.laserQuad.setVisible(!1);return}const r=o.attacks[t.activeAttack];if(!r||r.type!=="laser"){this.laserQuad.setVisible(!1);return}const l=n.x[a],c=n.y[a],d=t.laserEndX,u=t.laserEndY,f=d-l,m=u-c,h=Math.max(24,Math.hypot(f,m)),p=Math.atan2(m,f),g=(l+d)*.5,v=(c+u)*.5,y=t.duration>0?t.duration:1;this.laserChanneling=t.phase==="channel"?1:0,this.laserProgress=Math.min(1,Math.max(0,t.elapsed/y)),this.laserQuad.setVisible(!0).setSize(h,r.hitRadius*3).setOrigin(.5,.5).setPosition(g,v).setRotation(p)}fillPillarMatrices(s,t,n){this.pillars0.fill(0),this.pillars1.fill(0),this.pillars2.fill(0),this.pillars3.fill(0);const a=[this.pillars0,this.pillars1,this.pillars2,this.pillars3],{obstacles:i}=s;let o=0;for(let r=0;r<i.cap&&o<14;r+=1){if(i.alive[r]===0)continue;const l=i.items[r];if(l.type!=="pillar")continue;const c=o>>2,d=(o&3)*4,u=a[c];u[d]=l.x-t,u[d+1]=l.y-n,u[d+2]=l.radius+Yo,u[d+3]=1,o+=1}}}const O0=`
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

varying vec2 outTexCoord;

uniform float uTime;
uniform float uProgress;
uniform float uLength;
uniform float uWidth;
uniform float uSeed;

float hash21(vec2 p) {
  p = fract(p * vec2(127.1, 311.7) + uSeed * 13.37);
  p += dot(p, p + 34.5);
  return fract(p.x * p.y);
}

float vnoise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
  return 0.54 * vnoise(p) + 0.30 * vnoise(p * 2.15 + vec2(7.3, 11.1)) + 0.16 * vnoise(p * 4.35 + vec2(13.7, 29.3));
}

void main() {
  vec2 uv = vec2(outTexCoord.x, 1.0 - outTexCoord.y);
  
  // Total dimensions including padding
  float totalLen = uLength + 24.0;
  float totalWidth = uWidth + 24.0;

  // Real pixel-space relative to line center
  vec2 rawPos = vec2((uv.x - 0.5) * totalLen, (uv.y - 0.5) * totalWidth);

  // Discrete 1px pixel art stepping
  vec2 p = floor(rawPos) + 0.5;

  float halfLen = uLength * 0.5;
  float halfWidth = uWidth * 0.5;

  // Ignition expansion from center to ends during initial 12% of duration
  float igniteReach = clamp(uProgress / 0.12, 0.0, 1.0) * (halfLen + 4.0);
  if (abs(p.x) > igniteReach) {
    gl_FragColor = vec4(0.0);
    return;
  }

  // End taper along the line ends
  float endTaper = 1.0 - smoothstep(halfLen - 6.0, halfLen + 4.0, abs(p.x));
  if (endTaper <= 0.01) {
    gl_FragColor = vec4(0.0);
    return;
  }

  // Burnout fade during final 22% of duration
  float fade = 1.0 - smoothstep(0.78, 1.0, uProgress);

  // Wavy seam center line (fissure path meandering slightly in Y)
  float seamOffset = (fbm(vec2(p.x * 0.045, uSeed * 3.1)) - 0.5) * 5.0;
  float distToSeam = abs(p.y - seamOffset);

  // Flame turbulence & licking tongues
  float t = uTime * 4.5;
  vec2 flameUv = vec2(p.x * 0.09 + sin(t * 0.5) * 0.4, p.y * 0.16 - t);
  float flameNoise = fbm(flameUv);
  float flameTurb = fbm(vec2(p.x * 0.18 - t * 0.8, p.y * 0.32 + t * 0.6));

  // Dynamic fiery width based on flame noise
  float activeWidth = (halfWidth + 2.0) * (0.65 + 0.55 * flameTurb) * endTaper;
  if (distToSeam > activeWidth + 4.0) {
    gl_FragColor = vec4(0.0);
    return;
  }

  // Seam core, inner flame, outer crust
  float coreRatio = clamp(1.0 - distToSeam / max(1.0, activeWidth * 0.35), 0.0, 1.0);
  float flameRatio = clamp(1.0 - distToSeam / max(1.0, activeWidth), 0.0, 1.0);

  // Discretize flame density into quantized stepped bands
  float heat = flameRatio * 0.5 + coreRatio * 0.5 + (flameNoise - 0.5) * 0.35;
  heat = clamp(heat * fade, 0.0, 1.0);

  if (heat <= 0.08) {
    gl_FragColor = vec4(0.0);
    return;
  }

  // Resurrect 64 Brimstone / Magma Palette:
  // Charred scorched crust:  #2e1815
  // Deep sulfur crimson:     #9e2835
  // Searing magma red:       #ea4f36
  // Intense sulfur orange:   #f79617
  // White-hot gold/yellow:   #f9c22b
  // Incandescent flare tip:  #fff4c8
  vec3 crustDark  = vec3(0.180, 0.094, 0.082);
  vec3 magmaDeep  = vec3(0.620, 0.157, 0.208);
  vec3 flameRed   = vec3(0.918, 0.310, 0.212);
  vec3 sulfurGold = vec3(0.969, 0.588, 0.090);
  vec3 coreHot    = vec3(0.976, 0.761, 0.169);
  vec3 tipFlare   = vec3(1.000, 0.957, 0.784);

  vec3 col = crustDark;
  float alpha = 0.0;

  if (heat > 0.78) {
    col = mix(coreHot, tipFlare, (heat - 0.78) / 0.22);
    alpha = 0.96;
  } else if (heat > 0.52) {
    col = mix(sulfurGold, coreHot, (heat - 0.52) / 0.26);
    alpha = 0.90;
  } else if (heat > 0.32) {
    col = mix(flameRed, sulfurGold, (heat - 0.32) / 0.20);
    alpha = 0.82;
  } else if (heat > 0.18) {
    col = mix(magmaDeep, flameRed, (heat - 0.18) / 0.14);
    alpha = 0.65;
  } else {
    col = mix(crustDark, magmaDeep, heat / 0.18);
    alpha = 0.45;
  }

  // Ignition flash along the leading edge
  float edgeDist = abs(abs(p.x) - igniteReach);
  if (uProgress < 0.15 && edgeDist < 6.0) {
    col = mix(col, tipFlare, 1.0 - edgeDist / 6.0);
    alpha = min(1.0, alpha + 0.35);
  }

  alpha *= endTaper * clamp(fade * 1.2, 0.0, 1.0);
  gl_FragColor = vec4(col * alpha, alpha);
}
`,Yn=8;class V0{constructor(s){S(this,"time",0);S(this,"slots",[]);for(let t=0;t<Yn;t+=1){const n={quad:null,progress:0,length:150,width:18,seed:t*7.73};n.quad=s.add.shader({name:"BrimstoneLineShader",shaderName:"BrimstoneLineShader",fragmentSource:O0,setupUniforms:a=>{a("uTime",this.time),a("uProgress",n.progress),a("uLength",n.length),a("uWidth",n.width),a("uSeed",n.seed)}},0,0,180,48).setDepth(2.05).setVisible(!1),this.slots.push(n)}}sync(s,t){if(this.time=t,H().reduceVfx){for(const a of this.slots)a.quad.setVisible(!1);return}let n=0;for(let a=0;a<s.cap&&n<Yn;a+=1){if(s.alive[a]===0||s.kind[a]!==gt)continue;const i=this.slots[n];n+=1;const o=s.duration[a]>0?s.duration[a]:2.4,r=Math.max(0,Math.min(1,1-s.remain[a]/o)),l=s.length[a],c=s.width[a];i.progress=r,i.length=l,i.width=c,i.seed=(a+1)*11.37;const d=Math.atan2(s.dirY[a],s.dirX[a]),u=l+24,f=c+24;i.quad.setSize(u,f).setOrigin(.5,.5).setPosition(Math.round(s.x[a]),Math.round(s.y[a])).setRotation(d).setVisible(!0)}for(let a=n;a<Yn;a+=1)this.slots[a].quad.setVisible(!1)}destroy(){for(const s of this.slots)s.quad.destroy()}}const U0=`
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

varying vec2 outTexCoord;

uniform float uTime;
uniform float uCharge;
uniform float uActive;
uniform vec2 uPlayerOffset; // player pos relative to circle center, normalized by radius (-1..1)
uniform float uStyle;       // 0 = Cinder ember/gold, 1 = Rime aether cyan

float hash21(vec2 p) {
  p = fract(p * vec2(127.1, 311.7));
  p += dot(p, p + 34.5);
  return fract(p.x * p.y);
}

float vnoise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
  return 0.55 * vnoise(p) + 0.30 * vnoise(p * 2.08 + 7.3) + 0.15 * vnoise(p * 4.15 + 19.1);
}

void main() {
  if (uActive <= 0.01) {
    gl_FragColor = vec4(0.0);
    return;
  }

  // Quantize coordinates to a discrete pixel-art grid matching 128x128 circle resolution
  const float GRID = 128.0;
  vec2 rawUv = vec2(outTexCoord.x, 1.0 - outTexCoord.y);
  vec2 uv = (floor(rawUv * GRID) + 0.5) / GRID;
  vec2 p = (uv - 0.5) * 2.0; // -1..1 from circle center
  float r = length(p);

  if (r > 1.05) {
    gl_FragColor = vec4(0.0);
    return;
  }

  // Segment from player position to circle center
  vec2 p0 = uPlayerOffset;
  vec2 p1 = vec2(0.0);
  vec2 seg = p1 - p0;
  float segLen = length(seg);

  if (segLen <= 0.08) {
    gl_FragColor = vec4(0.0);
    return;
  }

  vec2 dir = seg / segLen;
  vec2 normal = vec2(-dir.y, dir.x);

  // Projection of current pixel p onto segment
  vec2 toP = p - p0;
  float proj = dot(toP, dir);
  float t = proj / segLen; // 0 = at player, 1 = at circle center

  // Strict segment bounds: tether exists ONLY between player (t=0) and center (t=1)
  // If proj < 0 (behind player) or proj > segLen (past center), no effect.
  if (t < -0.02 || t > 1.02) {
    gl_FragColor = vec4(0.0);
    return;
  }

  // Organic wavy sway along the tether
  float sway = sin(t * 12.0 - uTime * 3.5) * 0.022 * sin(clamp(t, 0.0, 1.0) * 3.14159);
  float distToLine = abs(dot(toP, normal) - sway);

  // Tether width softly tapers from player to center
  float tetherWidth = mix(0.065, 0.038, clamp(t, 0.0, 1.0));
  float beam = smoothstep(tetherWidth, 0.0, distToLine);

  // Soft falloff at ends (fade near player and fade as it enters the center)
  float endFade = smoothstep(0.0, 0.08, t) * smoothstep(1.0, 0.92, t);

  // Slow transfer: pulses and particles drift gently from player (t=0) to center (t=1)
  float travel1 = fract(t * 2.5 - uTime * 0.45);
  float pulse1 = smoothstep(0.0, 0.4, travel1) * smoothstep(1.0, 0.5, travel1);

  float travel2 = fract(t * 3.8 - uTime * 0.65 + 0.5);
  float pulse2 = smoothstep(0.0, 0.35, travel2) * smoothstep(1.0, 0.55, travel2);

  float noiseWave = fbm(vec2(t * 6.0 - uTime * 0.8, distToLine * 14.0));

  float tetherMask = beam * endFade * (0.35 + 0.45 * pulse1 + 0.25 * pulse2 + 0.15 * noiseWave);
  float streamIntensity = clamp(t, 0.0, 1.0);

  // Tiny soft pooling right at the center terminus (radius < 0.08)
  float centerDist = length(p);
  float centerPool = smoothstep(0.08, 0.0, centerDist) * 0.35;

  float totalPattern = tetherMask + centerPool * tetherMask;
  if (totalPattern <= 0.01) {
    gl_FragColor = vec4(0.0);
    return;
  }

  // Color palettes (Dark Hermetic tokens)
  vec3 col = vec3(1.0);
  if (uStyle < 0.5) {
    // Cinder: Deep ruby/burnt ember -> molten amber -> hot gold
    vec3 emberDeep = vec3(0.62, 0.15, 0.08); // #9e2614
    vec3 amberMid  = vec3(0.97, 0.59, 0.09); // #f79617
    vec3 goldHot   = vec3(0.98, 0.88, 0.42); // #fae06b
    col = mix(emberDeep, amberMid, clamp(streamIntensity * 0.7 + tetherMask * 0.4, 0.0, 1.0));
    col = mix(col, goldHot, clamp(centerPool * 0.9 + tetherMask * 0.3, 0.0, 1.0));
  } else {
    // Rime: Deep cosmic azure -> bright aether cyan -> pale silver glint
    vec3 azureDeep = vec3(0.12, 0.32, 0.65);
    vec3 cyanMid   = vec3(0.32, 0.82, 1.0);
    vec3 silverHot = vec3(0.88, 0.96, 1.0);
    col = mix(azureDeep, cyanMid, clamp(streamIntensity * 0.7 + tetherMask * 0.4, 0.0, 1.0));
    col = mix(col, silverHot, clamp(centerPool * 0.9 + tetherMask * 0.3, 0.0, 1.0));
  }

  float alpha = clamp(totalPattern * uActive * 0.82, 0.0, 0.88);
  gl_FragColor = vec4(col * alpha, alpha);
}
`;class W0{constructor(s){S(this,"quad");S(this,"time",0);S(this,"charge",0);S(this,"active",0);S(this,"playerOffset",[0,0]);S(this,"style",0);this.quad=s.add.shader({name:"CircleChargeShader",shaderName:"CircleChargeShader",fragmentSource:U0,setupUniforms:t=>{t("uTime",this.time),t("uCharge",this.charge),t("uActive",this.active),t("uPlayerOffset",this.playerOffset),t("uStyle",this.style)}},0,0,256,256).setDepth(1.15).setVisible(!1)}sync(s,t,n,a,i,o,r,l,c,d,u){if(this.time=s,H().reduceVfx||!o){if(this.active=Math.max(0,this.active-u*4),this.active<=.01){this.quad.setVisible(!1);return}}else{const h=r?1:0;this.active+=(h-this.active)*Math.min(1,u*5)}if(this.active<=.01){this.quad.setVisible(!1);return}this.charge=i,this.style=d==="cinder"?0:1;const f=Math.max(1,a);this.playerOffset[0]=Math.max(-1,Math.min(1,(l-t)/f)),this.playerOffset[1]=Math.max(-1,Math.min(1,(c-n)/f));const m=Math.round(a*2.15);this.quad.setSize(m,m).setOrigin(.5,.5).setPosition(Math.round(t),Math.round(n)).setVisible(!0)}destroy(){this.quad.destroy()}}const z0=`
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

varying vec2 outTexCoord;

uniform float uTime;
uniform float uSeed;

float hash21(vec2 p) {
  p = fract(p * vec2(127.1, 311.7) + uSeed * 19.19);
  p += dot(p, p + 34.5);
  return fract(p.x * p.y);
}

void main() {
  vec2 uv = vec2(outTexCoord.x, 1.0 - outTexCoord.y);
  // Centered normalized coords: -1..1 in Y, -1..1 in X along lance flight direction (facing +X)
  vec2 p = (uv - 0.5) * 2.0;

  // Discrete 1px pixel art quantization
  p = floor(p * 24.0) / 24.0;

  // Spearhead: sharp triangle tip at x > 0.0, tapering to tip at x = 0.9
  float tipReach = 0.90;
  float lance = 0.0;
  if (p.x > 0.0 && p.x < tipReach) {
    float halfW = (tipReach - p.x) * 0.55;
    lance = step(abs(p.y), halfW);
  }

  // Trailing chain links behind lance head (x < 0.0)
  float chain = 0.0;
  if (p.x <= 0.0 && p.x > -0.95) {
    // Repeated link pattern along X
    float linkX = fract((p.x - uTime * 6.0) * 4.5);
    float linkRing = step(abs(p.y), 0.28) * (1.0 - step(abs(p.y), 0.12) * step(0.2, linkX) * (1.0 - step(0.8, linkX)));
    chain = linkRing;
  }

  // Searing fiery aura
  float aura = clamp(1.0 - length(vec2(p.x * 0.8, p.y * 2.2)), 0.0, 1.0);

  if (lance < 0.5 && chain < 0.5 && aura < 0.45) {
    gl_FragColor = vec4(0.0);
    return;
  }

  // Hermetic gold & crimson fire palette
  vec3 tipWhite = vec3(1.0, 0.98, 0.85);
  vec3 goldHot  = vec3(0.976, 0.761, 0.169); // #f9c22b
  vec3 amberMid = vec3(0.969, 0.588, 0.090); // #f79617
  vec3 ironRust = vec3(0.48, 0.16, 0.12);

  vec3 col = mix(ironRust, amberMid, chain);
  col = mix(col, goldHot, lance);
  if (p.x > 0.65 && abs(p.y) < 0.15) {
    col = tipWhite;
  }
  col = mix(col, amberMid, aura * 0.4);

  float alpha = clamp(lance * 0.98 + chain * 0.92 + aura * 0.65, 0.0, 0.96);
  gl_FragColor = vec4(col * alpha, alpha);
}
`,X0=`
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

varying vec2 outTexCoord;

uniform float uTime;
uniform float uProgress; // normalized 0..1 along root duration
uniform float uLength;   // pixel length of chain
uniform float uWidth;    // quad height / 2
uniform float uSeed;

float hash21(vec2 p) {
  p = fract(p * vec2(127.1, 311.7) + uSeed * 13.37);
  p += dot(p, p + 34.5);
  return fract(p.x * p.y);
}

void main() {
  vec2 uv = vec2(outTexCoord.x, 1.0 - outTexCoord.y);

  // Position relative to quad center in pixels
  vec2 p = vec2((uv.x - 0.5) * (uLength + 24.0), (uv.y - 0.5) * (uWidth + 20.0));

  // Discrete 1px pixel stepping
  p = floor(p) + 0.5;

  float halfLen = uLength * 0.5;
  if (abs(p.x) > halfLen + 4.0) {
    gl_FragColor = vec4(0.0);
    return;
  }

  // Taut harmonic vibration along the chain
  float vib = sin(p.x * 0.12 - uTime * 14.0) * cos(p.x * 0.04) * 2.2;
  float distToChain = abs(p.y - vib);

  // Interlocking heavy chain links: periodic pattern every 14 pixels
  float linkU = fract((p.x + uTime * 12.0) / 14.0);
  float isOuterLink = step(distToChain, 4.5);
  float isInnerHole = step(distToChain, 1.8) * step(0.24, linkU) * (1.0 - step(0.76, linkU));
  float chainBody = isOuterLink * (1.0 - isInnerHole);

  // Flame / searing sparks along chain
  float flamePulse = sin(p.x * 0.25 - uTime * 8.0) * 0.5 + 0.5;
  float flameGlow = smoothstep(8.5, 0.0, distToChain) * (0.35 + 0.45 * flamePulse);

  if (chainBody < 0.5 && flameGlow < 0.12) {
    gl_FragColor = vec4(0.0);
    return;
  }

  // Dark hermetic glowing brass & iron palette
  vec3 coreGlint = vec3(1.000, 0.980, 0.820);
  vec3 moltenGold = vec3(0.976, 0.761, 0.169); // #f9c22b
  vec3 sulfurFire = vec3(0.969, 0.588, 0.090); // #f79617
  vec3 bloodSlag  = vec3(0.580, 0.120, 0.140);
  vec3 darkIron   = vec3(0.220, 0.160, 0.140);

  vec3 col = darkIron;
  if (chainBody > 0.5) {
    col = mix(bloodSlag, moltenGold, step(0.65, flamePulse));
    if (distToChain < 1.0) {
      col = mix(moltenGold, coreGlint, 0.8);
    }
  }
  col = mix(col, sulfurFire, flameGlow * 0.65);

  float alpha = clamp(chainBody * 0.96 + flameGlow * 0.85, 0.0, 0.95);
  gl_FragColor = vec4(col * alpha, alpha);
}
`,Y0=`
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

varying vec2 outTexCoord;

uniform float uTime;
uniform float uProgress; // normalized 0..1 along root duration
uniform float uRadius;

void main() {
  vec2 uv = vec2(outTexCoord.x, 1.0 - outTexCoord.y);
  vec2 p = (uv - 0.5) * 2.0;
  float r = length(p);

  if (r > 1.02) {
    gl_FragColor = vec4(0.0);
    return;
  }

  // Discrete 1px pixel stepping for pixel-art aesthetic
  p = floor(p * 32.0) / 32.0;
  float ang = atan(p.y, p.x);

  // Slowly rotating octagonal condemnation seal
  float rotAng = ang + uTime * 1.5;
  float oct = cos(rotAng * 8.0);
  float octRing = smoothstep(0.08, 0.0, abs(r - 0.76 - oct * 0.06));

  // Inner ring
  float innerRing = smoothstep(0.06, 0.0, abs(r - 0.48));

  // 4 Cardinal binding stakes
  float stakes = smoothstep(0.06, 0.0, abs(sin(rotAng * 2.0))) * step(r, 0.88) * (1.0 - step(r, 0.35));

  // Pulsing center rune core
  float centerPulse = (0.5 + 0.5 * sin(uTime * 6.0)) * smoothstep(0.38, 0.0, r);

  float fade = 1.0 - smoothstep(0.85, 1.0, uProgress);
  float mask = clamp(octRing + innerRing * 0.75 + stakes * 0.8 + centerPulse * 0.6, 0.0, 1.0) * fade;

  if (mask <= 0.02) {
    gl_FragColor = vec4(0.0);
    return;
  }

  vec3 sealGold   = vec3(0.976, 0.761, 0.169); // #f9c22b
  vec3 sulfurFire = vec3(0.969, 0.588, 0.090); // #f79617
  vec3 bloodCrim  = vec3(0.720, 0.140, 0.180);
  vec3 flareWhite = vec3(1.000, 0.980, 0.880);

  vec3 col = mix(bloodCrim, sulfurFire, octRing);
  col = mix(col, sealGold, innerRing + stakes * 0.7);
  col = mix(col, flareWhite, centerPulse * 0.8);

  float alpha = clamp(mask * 0.88, 0.0, 0.92);
  gl_FragColor = vec4(col * alpha, alpha);
}
`,Kn=4,jn=8,qn=8;class K0{constructor(s){S(this,"time",0);S(this,"lanceSlots",[]);S(this,"chainSlots",[]);S(this,"sealSlots",[]);for(let t=0;t<Kn;t+=1){const n=s.add.shader({name:"CondemnTetherLanceShader",shaderName:"CondemnTetherLanceShader",fragmentSource:z0,setupUniforms:a=>{a("uTime",this.time),a("uSeed",(t+1)*7.73)}},0,0,48,24).setDepth(5.25).setVisible(!1);this.lanceSlots.push({quad:n})}for(let t=0;t<jn;t+=1){const n={quad:null,progress:0,length:200,width:32,seed:(t+1)*11.37};n.quad=s.add.shader({name:"CondemnTetherChainShader",shaderName:"CondemnTetherChainShader",fragmentSource:X0,setupUniforms:a=>{a("uTime",this.time),a("uProgress",n.progress),a("uLength",n.length),a("uWidth",n.width),a("uSeed",n.seed)}},0,0,220,44).setDepth(2.15).setVisible(!1),this.chainSlots.push(n)}for(let t=0;t<qn;t+=1){const n={quad:null,progress:0,radius:36};n.quad=s.add.shader({name:"CondemnTetherSealShader",shaderName:"CondemnTetherSealShader",fragmentSource:Y0,setupUniforms:a=>{a("uTime",this.time),a("uProgress",n.progress),a("uRadius",n.radius)}},0,0,80,80).setDepth(2.12).setVisible(!1),this.sealSlots.push(n)}}sync(s,t,n,a,i){if(this.time=s,H().reduceVfx){for(const c of this.lanceSlots)c.quad.setVisible(!1);for(const c of this.chainSlots)c.quad.setVisible(!1);for(const c of this.sealSlots)c.quad.setVisible(!1);return}let o=0;for(let c=0;c<t.alive.length&&o<Kn;c+=1){if(t.alive[c]===0||(t.flags[c]&Yt)===0)continue;const d=this.lanceSlots[o];o+=1;const u=Math.atan2(t.vy[c],t.vx[c]);d.quad.setSize(52,28).setOrigin(.5,.5).setPosition(Math.round(t.x[c]),Math.round(t.y[c])).setRotation(u).setVisible(!0)}for(let c=o;c<Kn;c+=1)this.lanceSlots[c].quad.setVisible(!1);let r=0,l=0;for(let c=0;c<n.cap;c+=1){if(n.alive[c]===0||n.rootRemain[c]<=0||n.tetherDps[c]<=0||n.role[c]!==O&&n.role[c]!==j)continue;const d=n.x[c],u=n.y[c],f=n.radius[c],m=n.rootDuration[c]>0?n.rootDuration[c]:2.5,h=Math.max(0,Math.min(1,1-n.rootRemain[c]/m));if(r<jn){const p=this.chainSlots[r];r+=1;const g=d-a,v=u-i,y=Math.hypot(g,v),b=Math.atan2(v,g),x=(a+d)*.5,k=(i+u)*.5;p.progress=h,p.length=y,p.width=36,p.seed=(c+1)*7.73,p.quad.setSize(Math.round(y+24),44).setOrigin(.5,.5).setPosition(Math.round(x),Math.round(k)).setRotation(b).setVisible(!0)}if(l<qn){const p=this.sealSlots[l];l+=1,p.progress=h,p.radius=f;const g=Math.round(Math.max(48,f*2.8));p.quad.setSize(g,g).setOrigin(.5,.5).setPosition(Math.round(d),Math.round(u)).setVisible(!0)}}for(let c=r;c<jn;c+=1)this.chainSlots[c].quad.setVisible(!1);for(let c=l;c<qn;c+=1)this.sealSlots[c].quad.setVisible(!1)}destroy(){for(const s of this.lanceSlots)s.quad.destroy();for(const s of this.chainSlots)s.quad.destroy();for(const s of this.sealSlots)s.quad.destroy();this.lanceSlots.length=0,this.chainSlots.length=0,this.sealSlots.length=0}}const j0=`
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

varying vec2 outTexCoord;

uniform float uTime;
uniform float uProgress;
uniform float uStyle;
uniform float uAngle;

float hash21(vec2 p) {
  p = fract(p * vec2(127.1, 311.7));
  p += dot(p, p + 34.5);
  return fract(p.x * p.y);
}

void main() {
  vec2 uv = vec2(outTexCoord.x, 1.0 - outTexCoord.y);
  vec2 p = (uv - 0.5) * 2.0;
  float r = length(p);
  if (r > 1.02) {
    gl_FragColor = vec4(0.0);
    return;
  }

  float ang = atan(p.y, p.x) + uAngle;

  // Expanding shockwave ring
  float waveR = clamp(uProgress, 0.05, 1.0) * 0.94;
  float ringThickness = 0.11 * (1.0 - uProgress * 0.55);
  float ring = smoothstep(ringThickness, 0.0, abs(r - waveR));

  // Core blast glow fading with expansion
  float coreGlow = smoothstep(waveR, 0.0, r) * (1.0 - uProgress) * 0.48;

  // Angular radial slash lines / sparks
  float spikes = pow(max(0.0, cos(ang * 5.0 + uProgress * 2.0)), 5.0) * smoothstep(0.96, 0.04, r);

  // Overall fade out
  float fade = 1.0 - smoothstep(0.32, 1.0, uProgress);

  vec3 col = vec3(1.0);
  if (uStyle < 0.5) {
    // Style 0: Normal kinetic enemy hit (Solar gold / amber)
    vec3 baseCol = vec3(1.0, 0.52, 0.12);
    vec3 hotCol = vec3(1.0, 0.96, 0.78);
    col = mix(baseCol, hotCol, clamp(ring * 1.1 + coreGlow * 1.6, 0.0, 1.0));
  } else if (uStyle < 1.5) {
    // Style 1: Critical enemy hit (Crimson-violet energy flare)
    vec3 baseCol = vec3(0.95, 0.10, 0.32);
    vec3 hotCol = vec3(1.0, 0.95, 1.0);
    col = mix(baseCol, hotCol, clamp(ring * 1.3 + spikes * 0.85, 0.0, 1.0));
  } else {
    // Style 2: Player hurt (Visceral scarlet rip)
    vec3 baseCol = vec3(0.85, 0.05, 0.12);
    vec3 hotCol = vec3(1.0, 0.82, 0.82);
    col = mix(baseCol, hotCol, clamp(ring + coreGlow * 1.2, 0.0, 1.0));
  }

  float alpha = clamp((ring * 0.95 + coreGlow + spikes * 0.65) * fade, 0.0, 0.95);
  gl_FragColor = vec4(col * alpha, alpha);
}
`,q0=16,ji=.2;class Z0{constructor(s){S(this,"time",0);S(this,"playerHurtCd",0);S(this,"slots",[]);for(let t=0;t<q0;t+=1){const n={quad:null,active:!1,progress:0,duration:ji,style:0,angle:0};n.quad=s.add.shader({name:"DamageFxShader",shaderName:"DamageFxShader",fragmentSource:j0,setupUniforms:a=>{a("uTime",this.time),a("uProgress",n.progress),a("uStyle",n.style),a("uAngle",n.angle)}},0,0,72,72).setDepth(4.5).setVisible(!1),this.slots.push(n)}}spawn(s,t,n,a=72){if(n>=1.5){if(this.playerHurtCd>0)return;this.playerHurtCd=.22}let i=-1,o=-1;for(let l=0;l<this.slots.length;l+=1){const c=this.slots[l];if(!c.active){i=l;break}c.progress>o&&(o=c.progress,i=l)}if(i<0)return;const r=this.slots[i];r.active=!0,r.progress=0,r.duration=ji,r.style=n,r.angle=Math.random()*Math.PI*2,r.quad.setSize(a,a).setOrigin(.5,.5).setPosition(Math.round(s),Math.round(t)).setVisible(!0)}sync(s,t){this.time=t,this.playerHurtCd>0&&(this.playerHurtCd=Math.max(0,this.playerHurtCd-s));for(let n=0;n<this.slots.length;n+=1){const a=this.slots[n];a.active&&(a.progress+=s/a.duration,a.progress>=1&&(a.active=!1,a.quad.setVisible(!1)))}}}const Q0=`
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

varying vec2 outTexCoord;

uniform sampler2D uMainSampler;
uniform float uTime;
uniform float uAffix;        // 1 = Shielder outline, 2 = Noxious overlay
uniform float uShieldActive; // 1 = shield present, 0 = broken / recharging
uniform float uCorpse;       // 1 = dying / exploding corpse
uniform vec4 uFrameRect;     // u0, v0, u1, v1 in texture atlas space
uniform vec2 uFramePixels;   // pixel width and height of sprite frame
uniform float uFlipX;        // 1 = flipped horizontally, 0 = normal

void main() {
  // Map incoming quad UV (0..1) into the sprite sheet frame rect
  vec2 localUv = vec2(outTexCoord.x, 1.0 - outTexCoord.y);
  if (uFlipX > 0.5) {
    localUv.x = 1.0 - localUv.x;
  }

  // Margin accounts for the 2px padding on all sides of the quad
  vec2 pad = vec2(2.0) / (uFramePixels + 4.0);
  vec2 innerUv = (localUv - pad) / (vec2(1.0) - 2.0 * pad);

  // If outside frame area, render transparent unless outline reaches here
  bool insideFrame = innerUv.x >= 0.0 && innerUv.x <= 1.0 && innerUv.y >= 0.0 && innerUv.y <= 1.0;

  vec2 atlasUv = mix(uFrameRect.xy, uFrameRect.zw, clamp(innerUv, 0.0, 1.0));
  vec4 centerTex = insideFrame ? texture2D(uMainSampler, atlasUv) : vec4(0.0);

  vec2 texel = (uFrameRect.zw - uFrameRect.xy) / uFramePixels;

  if (uAffix < 1.5) {
    // -------------------------------------------------------------------------
    // 1. SHIELDER: Blue outline around sprite silhouette (Resurrect 64 blue tones)
    // Resurrect 64 blues:
    // #3060e6 - vec3(0.188, 0.376, 0.902)
    // #4d9be6 - vec3(0.302, 0.608, 0.902) [Resurrect 64 active shield blue]
    // #8fd3ff - vec3(0.561, 0.828, 1.0)   [Resurrect 64 light shield rim]
    // #484a77 - vec3(0.282, 0.290, 0.467) [Resurrect 64 broken shield dusk]
    // -------------------------------------------------------------------------
    if (centerTex.a > 0.35) {
      // Don't draw over the interior of the sprite for outline-only
      gl_FragColor = vec4(0.0);
      return;
    }

    // Sample immediate 4-connected 1px neighbors on sprite boundary
    float aL = texture2D(uMainSampler, atlasUv - vec2(texel.x, 0.0)).a;
    float aR = texture2D(uMainSampler, atlasUv + vec2(texel.x, 0.0)).a;
    float aD = texture2D(uMainSampler, atlasUv - vec2(0.0, texel.y)).a;
    float aU = texture2D(uMainSampler, atlasUv + vec2(0.0, texel.y)).a;

    float neighborAlpha = max(max(aL, aR), max(aD, aU));
    if (neighborAlpha <= 0.35) {
      gl_FragColor = vec4(0.0);
      return;
    }

    // Active shield vs broken shield
    vec3 brightBlue = vec3(0.302, 0.608, 0.902); // #4d9be6
    vec3 lightBlue  = vec3(0.561, 0.828, 1.0);   // #8fd3ff
    vec3 brokenBlue = vec3(0.282, 0.290, 0.467); // #484a77

    float wave = 0.5 + 0.5 * sin(uTime * 5.0 + innerUv.y * 14.0);
    vec3 activeCol = mix(brightBlue, lightBlue, wave * 0.6);

    vec3 outlineCol = uShieldActive > 0.5 ? activeCol : brokenBlue;
    float outlineAlpha = uShieldActive > 0.5 ? 0.95 : 0.45;

    gl_FragColor = vec4(outlineCol * outlineAlpha, outlineAlpha);
    return;
  } else {
    // -------------------------------------------------------------------------
    // 2. NOXIOUS: Greenish overlay shader over the entire sprite
    // Resurrect 64 green tones:
    // #1ebc73 - vec3(0.118, 0.737, 0.451) [Resurrect 64 noxious emerald]
    // #91db69 - vec3(0.569, 0.859, 0.412) [Resurrect 64 toxic lime]
    // #239063 - vec3(0.137, 0.565, 0.388) [Resurrect 64 deep caustic green]
    // -------------------------------------------------------------------------
    if (centerTex.a <= 0.2) {
      gl_FragColor = vec4(0.0);
      return;
    }

    vec3 emerald = vec3(0.118, 0.737, 0.451);
    vec3 toxicLime = vec3(0.569, 0.859, 0.412);
    vec3 deepGreen = vec3(0.137, 0.565, 0.388);

    // Subtle toxic pixel turbulence flowing over the sprite body
    float pulseSpeed = uCorpse > 0.5 ? 14.0 : 4.0;
    float wave = sin(innerUv.y * 16.0 - uTime * pulseSpeed + innerUv.x * 10.0);
    float glow = 0.5 + 0.5 * wave;

    vec3 noxiousCol = mix(deepGreen, emerald, glow);
    noxiousCol = mix(noxiousCol, toxicLime, smoothstep(0.7, 1.0, glow));

    // Semi-transparent overlay preserving underlying pixel silhouette
    float overlayAlpha = (uCorpse > 0.5 ? 0.65 : 0.42 + 0.12 * glow) * centerTex.a;

    gl_FragColor = vec4(noxiousCol * overlayAlpha, overlayAlpha);
    return;
  }
}
`,J0=6;class ep{constructor(s){S(this,"time",0);S(this,"slots",[]);for(let t=0;t<J0;t+=1){const n={quad:null,affix:1,shieldActive:1,corpse:0,frameRect:[0,0,1,1],framePixels:[48,48],flipX:0};n.quad=s.add.shader({name:"EliteAffixShader",shaderName:"EliteAffixShader",fragmentSource:Q0,setupUniforms:a=>{a("uMainSampler",0),a("uTime",this.time),a("uAffix",n.affix),a("uShieldActive",n.shieldActive),a("uCorpse",n.corpse),a("uFrameRect",n.frameRect),a("uFramePixels",n.framePixels),a("uFlipX",n.flipX)}},0,0,64,64).setDepth(3.05).setVisible(!1),this.slots.push(n)}}sync(s,t,n){this.time=s;for(let a=0;a<this.slots.length;a+=1){const i=this.slots[a],o=t[a],r=n[a];if(!r||!r.active||!o||!o.visible){i.quad.setVisible(!1);continue}const l=o.frame;if(!l||!o.texture){i.quad.setVisible(!1);continue}(i.quad.textures.length===0||i.quad.textures[0]!==o.texture)&&i.quad.setTextures([o.texture]),i.affix=r.isShielder?1:r.isNoxious?2:1,i.shieldActive=r.shieldActive?1:0,i.corpse=r.isCorpse?1:0,i.flipX=o.flipX?1:0,i.frameRect[0]=l.u0,i.frameRect[1]=l.v0,i.frameRect[2]=l.u1,i.frameRect[3]=l.v1;const c=l.cutWidth||l.width||48,d=l.cutHeight||l.height||48;i.framePixels[0]=c,i.framePixels[1]=d;const u=Math.abs(o.scaleX)||1,f=Math.abs(o.scaleY)||1,m=(c+4)*u,h=(d+4)*f;i.quad.setSize(m,h).setOrigin(o.originX,o.originY).setPosition(o.x,o.y).setDepth(o.depth+2e-4).setVisible(!0)}}destroy(){for(const s of this.slots)s.quad.destroy();this.slots.length=0}}const tp=`
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

varying vec2 outTexCoord;

uniform sampler2D uMainSampler;
uniform float uTime;
uniform float uStyle;
uniform float uPlayerIn;
uniform float uSeed;
uniform float uFade;
uniform vec4 uFrameRect; // u0, v0, u1, v1
uniform float uHasTex;

float hash21(vec2 p) {
  p = fract(p * vec2(127.1, 311.7) + uSeed * 17.31);
  p += dot(p, p + 34.5);
  return fract(p.x * p.y);
}

vec2 hash22(vec2 p) {
  float n = hash21(p);
  return vec2(n, hash21(p + n + 19.19));
}

float vnoise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
  float v = 0.0;
  v += 0.52 * vnoise(p);
  v += 0.31 * vnoise(p * 2.08 + vec2(13.1, 7.7));
  v += 0.17 * vnoise(p * 4.15 + vec2(3.7, 29.3));
  return v;
}

// Micro-bubble cell confined inside fluid channels
float microBubble(vec2 p, float speed, float scale) {
  vec2 sp = p * scale;
  vec2 cell = floor(sp);
  vec2 local = fract(sp) - 0.5;
  vec2 rnd = hash22(cell);

  float lifeTime = fract(uTime * speed + rnd.x * 6.28);
  float grow = sin(clamp(lifeTime / 0.85, 0.0, 1.0) * 3.14159);
  float radius = grow * (0.16 + rnd.y * 0.12);

  vec2 offset = (rnd - 0.5) * 0.35;
  float d = length(local - offset);
  return step(d, radius) * step(0.04, radius) * step(lifeTime, 0.92);
}

void main() {
  // Discrete 64x64 grid matching native pixel art resolution
  const float GRID = 64.0;
  vec2 rawUv = vec2(outTexCoord.x, 1.0 - outTexCoord.y);
  vec2 uv = (floor(rawUv * GRID) + 0.5) / GRID;
  vec2 p = (uv - 0.5) * 2.0;
  float r = length(p);

  vec2 atlasUv = mix(uFrameRect.xy, uFrameRect.zw, clamp(uv, 0.0, 1.0));
  vec4 baseTex = uHasTex > 0.5 ? texture2D(uMainSampler, atlasUv) : vec4(0.0);

  // If we have an authored sprite, isolate ONLY the molten/liquid interior
  // Dark rocky rim, cracks in stone, and exterior transparent pixels must stay 100% unaffected.
  float liquidMask = 0.0;
  if (uHasTex > 0.5) {
    if (baseTex.a < 0.2) {
      gl_FragColor = vec4(0.0);
      return;
    }
    if (uStyle < 0.5) {
      // Cinder molten core: strong red/orange, low blue, not dark rock
      float warmth = baseTex.r - baseTex.b;
      float brightness = max(baseTex.r, baseTex.g);
      liquidMask = smoothstep(0.20, 0.42, warmth) * step(0.26, brightness);
    } else {
      // Rime / Acid green-cyan pool: green dominance over red
      float greenHue = baseTex.g - baseTex.r * 0.75;
      liquidMask = smoothstep(0.08, 0.28, greenHue) * step(0.24, baseTex.g);
    }
  } else {
    // Procedural fallback mask if no texture attached
    float edgeNoise = fbm(p * 2.2);
    liquidMask = smoothstep(0.78, 0.62, r + (edgeNoise - 0.5) * 0.15);
  }

  if (liquidMask <= 0.02) {
    gl_FragColor = vec4(0.0);
    return;
  }

  // Slow, subtle surface flow
  float flowSpeed = mix(0.12, 0.22, uPlayerIn);
  vec2 flow = vec2(
    fbm(p * 2.0 + vec2(uTime * flowSpeed, -uTime * flowSpeed * 0.8)),
    fbm(p * 2.0 + vec2(-uTime * flowSpeed * 0.8, uTime * flowSpeed))
  );
  float surface = fbm(p * 3.0 + flow * 0.8);

  // Tiny discrete 1-2px boiling specks / micro-bubbles
  float micro1 = microBubble(p + flow * 0.1, mix(0.18, 0.32, uPlayerIn), 7.0);
  float micro2 = microBubble(p - flow * 0.12 + vec2(13.7, 29.1), mix(0.22, 0.38, uPlayerIn), 9.0);
  float microTotal = clamp(micro1 + micro2, 0.0, 1.0);

  vec3 col = vec3(0.0);
  float alpha = 0.0;

  if (uStyle > 1.5) {
    // Style 2: Glacial Crevasse (Freezing cyan brine + crystalline ice glints)
    vec3 deepCyan = vec3(0.12, 0.55, 0.85);
    vec3 brightCyan = vec3(0.45, 0.92, 1.0);
    vec3 hotGlint = vec3(0.92, 0.98, 1.0);

    vec3 fluid = mix(deepCyan, brightCyan, surface);
    fluid = mix(fluid, hotGlint, microTotal * 0.85);

    col = fluid;
    alpha = clamp((0.35 + surface * 0.30 + microTotal * 0.35) * liquidMask, 0.0, 0.65);
  } else if (uStyle > 0.5) {
    // Style 1: Rime Caustic Acid Pool (Bubbling toxic emerald & lime)
    vec3 causticGreen = vec3(0.118, 0.737, 0.451); // #1ebc73
    vec3 neonAcid = vec3(0.569, 0.859, 0.412);     // #91db69
    vec3 acidSpec = vec3(0.804, 0.875, 0.424);     // #cdff82

    vec3 fluid = mix(causticGreen, neonAcid, surface);
    fluid = mix(fluid, acidSpec, microTotal * 0.9);

    float sizzle = uPlayerIn * (0.5 + 0.5 * sin(uTime * 3.5)) * 0.20;
    col = fluid + acidSpec * sizzle;
    alpha = clamp((0.38 + surface * 0.30 + microTotal * 0.32 + sizzle) * liquidMask, 0.0, 0.68);
  } else {
    // Style 0: Cinder Molten Core (Warm glowing lava veins + golden micro-sparks)
    vec3 magmaDeep = vec3(0.918, 0.310, 0.212);  // #ea4f36
    vec3 lavaEmber = vec3(0.969, 0.588, 0.090);  // #f79617
    vec3 lavaGlint = vec3(0.976, 0.761, 0.169);  // #f9c22b

    vec3 fluid = mix(magmaDeep, lavaEmber, surface);
    fluid = mix(fluid, lavaGlint, microTotal * 0.85);

    float simmer = uPlayerIn * (0.5 + 0.5 * sin(uTime * 3.2)) * 0.18;
    col = fluid + lavaGlint * simmer;
    alpha = clamp((0.36 + surface * 0.32 + microTotal * 0.32 + simmer) * liquidMask, 0.0, 0.68);
  }

  alpha *= clamp(uFade, 0.0, 1.0);
  gl_FragColor = vec4(col * alpha, alpha);
}
`,Zn=16;class sp{constructor(s){S(this,"time",0);S(this,"slots",[]);for(let t=0;t<Zn;t+=1){const n={quad:null,style:0,playerIn:0,seed:t*7.13,fade:1,frameRect:[0,0,1,1],hasTex:0};n.quad=s.add.shader({name:"EnvHazardShader",shaderName:"EnvHazardShader",fragmentSource:tp,setupUniforms:a=>{a("uMainSampler",0),a("uTime",this.time),a("uStyle",n.style),a("uPlayerIn",n.playerIn),a("uSeed",n.seed),a("uFade",n.fade),a("uFrameRect",n.frameRect),a("uHasTex",n.hasTex)}},0,0,128,128).setDepth(1.1).setVisible(!1),this.slots.push(n)}}sync(s,t,n,a,i,o,r,l,c){if(this.time=l,H().reduceVfx){for(const f of this.slots)f.quad.setVisible(!1);return}const d=r==="glacial"?2:o==="rime"?1:0;let u=0;for(let f=0;f<s.cap&&u<Zn;f+=1){if(s.alive[f]===0)continue;const m=s.items[f];if(m.type!=="hazard")continue;const h=this.slots[u],p=t[f];u+=1;const v=Math.hypot(n-m.x,a-m.y)<=m.radius+i,y=(m.timer??0)>0;h.style=y?1:d,h.fade=y?Math.min(1,(m.timer??1)/1):1,h.seed=(f+1)*13.37;const b=v?1:0;h.playerIn+=(b-h.playerIn)*Math.min(1,c*8),p&&p.texture&&p.frame?((h.quad.textures.length===0||h.quad.textures[0]!==p.texture)&&h.quad.setTextures([p.texture]),h.hasTex=1,h.frameRect[0]=p.frame.u0,h.frameRect[1]=p.frame.v0,h.frameRect[2]=p.frame.u1,h.frameRect[3]=p.frame.v1):h.hasTex=0;const x=Math.round(m.radius*2);h.quad.setSize(x,x).setOrigin(.5,.5).setPosition(Math.round(m.x),Math.round(m.y)).setVisible(!0)}for(let f=u;f<Zn;f+=1)this.slots[f].quad.setVisible(!1),this.slots[f].playerIn=0,this.slots[f].fade=1}}const np=`
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

varying vec2 outTexCoord;

uniform float uTime;
uniform float uIntensity;
uniform float uHpPct;

void main() {
  vec2 uv = vec2(outTexCoord.x, 1.0 - outTexCoord.y);
  vec2 p = (uv - 0.5) * 2.0;
  float r = length(p);

  // Organic irregular edge noise for visceral rim
  float noise = sin(p.x * 10.0 + uTime * 7.0) * cos(p.y * 10.0 - uTime * 6.0) * 0.07;
  float edge = smoothstep(0.72 + noise, 1.38, r);

  // Heartbeat warning when at critical health
  float heartbeat = 0.0;
  if (uHpPct < 0.28) {
    float pulse = pow(sin(uTime * 6.0) * 0.5 + 0.5, 4.0);
    heartbeat = pulse * (1.0 - uHpPct / 0.28) * 0.42;
  }

  float totalVignette = clamp(edge * (uIntensity * 0.88 + heartbeat), 0.0, 0.88);
  if (totalVignette <= 0.001) {
    gl_FragColor = vec4(0.0);
    return;
  }

  vec3 deepBlood = vec3(0.72, 0.04, 0.10);
  vec3 hotScarlet = vec3(1.0, 0.22, 0.28);
  vec3 col = mix(deepBlood, hotScarlet, uIntensity * 0.5);

  gl_FragColor = vec4(col * totalVignette, totalVignette);
}
`;class ap{constructor(s){S(this,"quad");S(this,"time",0);S(this,"intensity",0);S(this,"hpPct",1);S(this,"triggerCd",0);this.quad=s.add.shader({name:"PlayerHurtShader",shaderName:"PlayerHurtShader",fragmentSource:np,setupUniforms:t=>{t("uTime",this.time),t("uIntensity",this.intensity),t("uHpPct",this.hpPct)}},0,0,128,128).setDepth(8.5).setVisible(!1)}trigger(s=.85){this.triggerCd>0||(this.triggerCd=.22,this.intensity=Math.min(1,this.intensity+s),this.quad.setVisible(!0))}sync(s,t,n,a,i){if(this.time=t,this.triggerCd=Math.max(0,this.triggerCd-i),this.hpPct=a>0?Math.max(0,Math.min(1,n/a)):1,this.intensity>0&&(this.intensity=Math.max(0,this.intensity-i*3.4)),!(this.intensity>.01||this.hpPct<.28)){this.quad.setVisible(!1);return}const r=s.worldView,l=16,c=Math.max(64,r.width+l*2),d=Math.max(64,r.height+l*2);this.quad.setSize(c,d).setOrigin(.5,.5).setPosition(r.centerX,r.centerY).setVisible(!0)}}const ip=`
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

varying vec2 outTexCoord;

uniform float uTime;
uniform float uProgress;
uniform float uKind;    // 0 = Censer Lob impact, 1 = Crucible Cull impact, 2 = Tether Latch burst
uniform float uIsCrit;  // 0 = normal, 1 = crit
uniform float uRadius;  // gameplay AoE radius in world pixels
uniform float uSeed;

float hash21(vec2 p) {
  p = fract(p * vec2(127.1, 311.7) + uSeed * 17.31);
  p += dot(p, p + 34.5);
  return fract(p.x * p.y);
}

float vnoise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
  return 0.55 * vnoise(p) + 0.30 * vnoise(p * 2.15 + vec2(7.3, 11.1)) + 0.15 * vnoise(p * 4.35 + vec2(13.7, 29.3));
}

void main() {
  vec2 uv = vec2(outTexCoord.x, 1.0 - outTexCoord.y);

  // Normalized coordinate in [-1..1] from center
  vec2 p = (uv - 0.5) * 2.0;
  float r = length(p);
  if (r > 1.04) {
    gl_FragColor = vec4(0.0);
    return;
  }

  float ang = atan(p.y, p.x);
  vec3 col = vec3(0.0);
  float alpha = 0.0;

  // =========================================================================
  // 0: CENSER LOB IMPACT (Shattering vessel, sacred ember burst, incense smoke)
  // =========================================================================
  if (uKind < 0.5) {
    float fade = 1.0 - smoothstep(0.68, 1.0, uProgress);
    if (fade <= 0.01) {
      gl_FragColor = vec4(0.0);
      return;
    }

    // Expanding shockwave of sacred flame
    float waveR = clamp(uProgress / 0.85, 0.05, 1.0) * 0.82;
    float ringThickness = 0.12 * (1.0 - uProgress * 0.45);
    float ring = smoothstep(ringThickness, 0.0, abs(r - waveR));

    // Hot interior core scorch
    float core = smoothstep(waveR * 0.72, 0.0, r) * (1.0 - uProgress * 0.88);

    // Shattering glass/brass vessel shards (8 fragments flying outward)
    float shardCount = 8.0;
    float shardIdx = floor((ang + 3.14159) / (6.28318 / shardCount));
    float shardRand = hash21(vec2(shardIdx, uSeed));
    float shardSpeed = 0.45 + 0.50 * shardRand;
    float shardDist = uProgress * shardSpeed * 0.85;
    vec2 shardCenter = vec2(
      cos((shardIdx + 0.5) * (6.28318 / shardCount)),
      sin((shardIdx + 0.5) * (6.28318 / shardCount))
    ) * shardDist;
    float shardDistToP = length(p - shardCenter);
    float shard = step(shardDistToP, 0.042 * (1.0 - uProgress * 0.55));

    // Billowing incense smoke turbulence
    float smokeN = fbm(p * 4.2 - vec2(cos(ang), sin(ang)) * uProgress * 1.4 + uSeed * 3.3);
    float smoke = smoothstep(0.42, 0.76, smokeN) * step(r, waveR + 0.12) * (1.0 - uProgress * 0.82);

    // Resurrect 64 Dark Hermetic Palettes
    vec3 flareHot  = vec3(1.000, 0.957, 0.784); // #fff4c8 (Incandescent tip)
    vec3 sulfurGold = vec3(0.969, 0.588, 0.090); // #f79617 (Sulfur amber)
    vec3 flameRed   = vec3(0.918, 0.310, 0.212); // #ea4f36 (Searing flame)
    vec3 smokeAsh   = vec3(0.243, 0.208, 0.275); // #3e3546 (Dark incense ash)
    vec3 shardBrass = vec3(0.976, 0.761, 0.169); // #f9c22b (Brass censer shard)

    // Critical overcharge: searing crimson-violet
    vec3 critHot = vec3(1.000, 0.880, 0.920);
    vec3 critMid = vec3(1.000, 0.133, 0.320);

    vec3 hot = mix(flareHot, critHot, uIsCrit);
    vec3 mid = mix(sulfurGold, critMid, uIsCrit);

    col = mix(flameRed, mid, ring);
    col = mix(col, hot, clamp(core * 1.5 + ring * 0.8, 0.0, 1.0));
    col = mix(col, shardBrass, shard * 0.9);
    col = mix(col, smokeAsh, smoke * 0.45);

    alpha = clamp((ring * 0.95 + core * 0.85 + shard * 0.98 + smoke * 0.42) * fade, 0.0, 0.95);
  }
  // =========================================================================
  // 1: CRUCIBLE CULL IMPACT (Alchemical sky-hammer, hexagram fissures, slag shockwave)
  // =========================================================================
  else if (uKind < 1.5) {
    float fade = 1.0 - smoothstep(0.72, 1.0, uProgress);
    if (fade <= 0.01) {
      gl_FragColor = vec4(0.0);
      return;
    }

    // 1. Initial celestial anvil hammerfall flash (descending light column)
    float beamActive = step(uProgress, 0.30);
    float beamFade = 1.0 - uProgress / 0.30;
    float beamW = mix(0.16, 0.02, uProgress / 0.30);
    float beam = smoothstep(beamW, 0.0, abs(p.x)) * beamFade * beamActive;

    // 2. Transmutation double shockwave with 6-fold alchemical facet symmetry
    float waveR = clamp(uProgress / 0.86, 0.05, 1.0) * 0.90;
    float ringW = 0.13 * (1.0 - uProgress * 0.48);
    float ring1 = smoothstep(ringW, 0.0, abs(r - waveR));

    float waveR2 = waveR * 0.60;
    float ring2 = smoothstep(0.08 * (1.0 - uProgress * 0.3), 0.0, abs(r - waveR2)) * (1.0 - uProgress * 0.7);

    // 6-fold alchemical hexagram faceting along the shockwave
    float hex = cos(ang * 6.0);
    float hexFacets = smoothstep(0.09, 0.0, abs(r - waveR * (0.90 + 0.10 * hex))) * 0.8;

    // 3. Molten ground fissures / crucible slag fractures
    float crackN = fbm(p * 5.2 + vec2(uSeed * 4.3, -uSeed * 3.1));
    float crack = smoothstep(0.52, 0.78, crackN) * step(r, waveR + 0.06) * (1.0 - uProgress * 0.65);

    // 4. White-hot center crucible melt pool
    float centerMelt = smoothstep(waveR * 0.50, 0.0, r) * (1.0 - uProgress * 0.92);

    // Palette:
    vec3 tipWhite   = vec3(1.000, 0.965, 0.860); // #fff4c8 (Incandescent white-gold)
    vec3 sulfurGold = vec3(0.976, 0.761, 0.169); // #f9c22b (Molten solar gold)
    vec3 amberFire  = vec3(0.969, 0.588, 0.090); // #f79617 (Sulfur flame)
    vec3 deepMagma  = vec3(0.918, 0.310, 0.212); // #ea4f36 (Searing red)
    vec3 crucibleRed= vec3(0.620, 0.157, 0.208); // #9e2835 (Deep crucible crimson)
    vec3 crustSlag  = vec3(0.180, 0.094, 0.082); // #2e1815 (Scorched crust)

    // Crit variant: blazing crimson-magenta overcharge
    vec3 critCore = vec3(1.000, 0.900, 0.950);
    vec3 critFire = vec3(1.000, 0.180, 0.350);

    vec3 coreHot = mix(tipWhite, critCore, uIsCrit);
    vec3 fireMid = mix(amberFire, critFire, uIsCrit);

    col = mix(crustSlag, crucibleRed, crack);
    col = mix(col, deepMagma, ring1 * 0.7);
    col = mix(col, fireMid, clamp(ring1 + ring2 + hexFacets * 0.7 + crack * 0.9, 0.0, 1.0));
    col = mix(col, sulfurGold, clamp(ring2 * 0.8 + centerMelt * 0.9, 0.0, 1.0));
    col = mix(col, coreHot, clamp(centerMelt * 1.4 + beam * 1.6, 0.0, 1.0));

    float intensity = ring1 * 0.95 + ring2 * 0.82 + hexFacets * 0.65 + crack * 0.88 + centerMelt * 0.95 + beam * 0.98;
    alpha = clamp(intensity * fade, 0.0, 0.96);
  }
  // =========================================================================
  // 2: CONDEMNATION TETHER LATCH BURST (Snapping chain lock, hermetic shackle flash)
  // =========================================================================
  else {
    float fade = 1.0 - smoothstep(0.60, 1.0, uProgress);
    if (fade <= 0.01) {
      gl_FragColor = vec4(0.0);
      return;
    }

    // Inward-clamping shackle ring locking onto target center
    float shackleR = mix(0.95, 0.40, clamp(uProgress / 0.45, 0.0, 1.0));
    float ringThickness = mix(0.12, 0.05, uProgress);
    float shackleRing = smoothstep(ringThickness, 0.0, abs(r - shackleR));

    // 8-spoke radiating chain lock teeth
    float lockTeeth = cos(ang * 8.0);
    float teethPattern = smoothstep(0.10, 0.0, abs(r - shackleR * (1.0 + 0.12 * lockTeeth)));

    // Central flash at moment of latch (first 30% of lifetime)
    float coreFlash = smoothstep(0.35, 0.0, r) * (1.0 - uProgress / 0.35) * step(uProgress, 0.35);

    // Searing hermetic sigil embers
    float sparkNoise = fbm(p * 8.0 + vec2(uSeed * 2.1, uTime * 3.0));
    float sparks = smoothstep(0.55, 0.85, sparkNoise) * step(r, 0.85) * (1.0 - uProgress * 0.7);

    vec3 ironGold  = vec3(0.976, 0.761, 0.169); // #f9c22b
    vec3 sulfurMid = vec3(0.969, 0.588, 0.090); // #f79617
    vec3 bloodDeep = vec3(0.720, 0.140, 0.180); // #b8242e
    vec3 whiteHot  = vec3(1.000, 0.965, 0.880);

    vec3 critMid  = vec3(1.000, 0.150, 0.300);
    vec3 midColor = mix(sulfurMid, critMid, uIsCrit);

    col = mix(bloodDeep, midColor, shackleRing);
    col = mix(col, ironGold, teethPattern * 0.85);
    col = mix(col, whiteHot, coreFlash * 1.5 + sparks * 0.7);

    alpha = clamp((shackleRing * 0.95 + teethPattern * 0.85 + coreFlash * 0.95 + sparks * 0.5) * fade, 0.0, 0.95);
  }

  gl_FragColor = vec4(col * alpha, alpha);
}
`,op=12,qi=.34,rp=.5,lp=.38;class cp{constructor(s){S(this,"time",0);S(this,"slots",[]);for(let t=0;t<op;t+=1){const n={quad:null,active:!1,progress:0,duration:qi,kind:0,isCrit:0,radius:30,seed:t*7.73};n.quad=s.add.shader({name:"SkillImpactShader",shaderName:"SkillImpactShader",fragmentSource:ip,setupUniforms:a=>{a("uTime",this.time),a("uProgress",n.progress),a("uKind",n.kind),a("uIsCrit",n.isCrit),a("uRadius",n.radius),a("uSeed",n.seed)}},0,0,84,84).setDepth(4.4).setVisible(!1),this.slots.push(n)}}spawnCenser(s,t,n=30,a=!1){if(H().reduceVfx)return;const i=Math.max(16,n),o=Math.round(i*2.8);this.spawn(s,t,0,i,o,qi,a)}spawnCrucible(s,t,n=45,a=!1){if(H().reduceVfx)return;const i=Math.max(24,n),o=Math.round(i*2.6);this.spawn(s,t,1,i,o,rp,a)}spawnTetherLatch(s,t,n=24,a=!1){if(H().reduceVfx)return;const i=Math.max(20,n),o=Math.round(i*2.8);this.spawn(s,t,2,i,o,lp,a)}spawn(s,t,n,a,i,o,r){let l=-1,c=-1;for(let u=0;u<this.slots.length;u+=1){const f=this.slots[u];if(!f.active){l=u;break}f.progress>c&&(c=f.progress,l=u)}if(l<0)return;const d=this.slots[l];d.active=!0,d.progress=0,d.duration=o,d.kind=n,d.isCrit=r?1:0,d.radius=a,d.seed=(l+1)*11.37+Math.random()*99,d.quad.setSize(i,i).setOrigin(.5,.5).setPosition(Math.round(s),Math.round(t)).setVisible(!0)}sync(s,t){if(this.time=t,H().reduceVfx){for(const n of this.slots)n.active&&(n.active=!1,n.quad.setVisible(!1));return}for(let n=0;n<this.slots.length;n+=1){const a=this.slots[n];a.active&&(a.progress+=s/a.duration,a.progress>=1&&(a.active=!1,a.quad.setVisible(!1)))}}destroy(){for(const s of this.slots)s.quad.destroy();this.slots.length=0}}const Ee=10,Zi=80,Cs=52,Ms=40;class dp extends P.Scene{constructor(){super({key:"arena"});S(this,"world");S(this,"inputFrame",gd());S(this,"playerSprite");S(this,"playerEyes");S(this,"playerGlow");S(this,"eliteSprites",[]);S(this,"eliteAffixShaders");S(this,"bossSprite");S(this,"obstacleSprites",[]);S(this,"volatileGlows",[]);S(this,"floor");S(this,"circleSprite");S(this,"circleChargeShader");S(this,"circleGlowFilter");S(this,"portalSprite");S(this,"telGlow");S(this,"crosshair");S(this,"waypoint");S(this,"shots",[]);S(this,"zoneFx",[]);S(this,"fxStills");S(this,"ghosts",[]);S(this,"ghostLife",new Float32Array(Ee));S(this,"ghostMaxLife",new Float32Array(Ee));S(this,"ghostInitAlpha",new Float32Array(Ee));S(this,"ghostCd",0);S(this,"shakeTrauma",0);S(this,"shakeTime",0);S(this,"ambientShader");S(this,"bossShaders");S(this,"brimstoneLineShaders");S(this,"condemnTetherShaders");S(this,"damageFx");S(this,"envHazardShaders");S(this,"playerHurtShader");S(this,"skillImpactShaders");S(this,"playerTrail1");S(this,"playerTrail2");S(this,"fodderLayers",new Map);S(this,"enemyGlowLayer");S(this,"enemyPrevX",new Float32Array(0));S(this,"enemyPrevY",new Float32Array(0));S(this,"enemyAliveLast",new Uint8Array(0));S(this,"playerPrevX",0);S(this,"playerPrevY",0);S(this,"gemLayer");S(this,"loreSprites",[]);S(this,"loreGlows",[]);S(this,"sparkLayer");S(this,"sparks",[]);S(this,"zoneGfx");S(this,"telegraphGfx");S(this,"gpuMember",{x:0,y:0,scaleX:0,scaleY:0,alpha:0,tintBlend:.7,tintBottomLeft:16777215,tintTopLeft:16777215,tintBottomRight:16777215,tintTopRight:16777215});S(this,"fodderShown");S(this,"fodderAnimName",new Map);S(this,"fodderAnimStart",new Map);S(this,"fodderAttackPlayed",new Map);S(this,"gemShown");S(this,"sparkShown");S(this,"cursors");S(this,"wasd");S(this,"shift");S(this,"space");S(this,"qKey");S(this,"decoySprite");S(this,"utilityWasDown",!1);S(this,"secondaryWasDown",!1);S(this,"specialWasDown",!1);S(this,"lastStageGen",-1);S(this,"lastPhase","play");S(this,"lastStageIndex",0);S(this,"lastBossSpawned",!1);S(this,"bossMusicActive",!1);S(this,"shownOffer",null);S(this,"walkPhase",0);S(this,"lastCircleKey","");S(this,"lastFacing","right");S(this,"initialUnlockedItems",new Set);S(this,"initialUnlockedSurvivors",new Set)}preload(){s0(this)}create(){const t=$();this.initialUnlockedItems=St(t),this.initialUnlockedSurvivors=new Set(E.survivors.filter(m=>ae(m,t)).map(m=>m.id));const n=vt();this.world=cu(dt()?"runner":pp(),{unlockedItems:this.initialUnlockedItems,collectedLores:Hm(t)}),n&&dt()&&Zu(this.world,n),it(this.world);const{width:a,height:i,maxProjectiles:o}=E.world,r=E.loop;R0(this),r0(this);const l=this.biome(),c=this.envTheme(),d=this.vesselId();if(this.floor=this.add.image(a/2,i/2,Ys(c)).setDepth(0),this.circleSprite=this.add.image(0,0,"").setVisible(!1).setDepth(1),typeof this.circleSprite.enableFilters=="function")try{this.circleSprite.enableFilters();const m=this.circleSprite.filters;m?.internal?.addGlow&&(this.circleGlowFilter=m.internal.addGlow(16755251,8,0,0),this.circleGlowFilter.setActive(!1))}catch{}this.portalSprite=this.add.image(0,0,"").setVisible(!1).setDepth(1),this.zoneGfx=this.add.graphics().setDepth(1),this.telegraphGfx=this.add.graphics().setDepth(3),this.fodderLayers=new Map,this.fodderShown={};for(const m of E.entities){if(m.role==="boss")continue;const h=Z(m.id);if(!this.textures.exists(h))continue;const p=this.add.spriteGPULayer(h,this.world.enemies.cap).setDepth(2);p.setAnimationEnabled("Linear",!0);const g=l0(m.id);g.length>0&&p.setAnimations(g),this.fodderLayers.set(m.id,p),this.fodderShown[m.id]=new Uint8Array(this.world.enemies.cap),this.fodderAnimName.set(m.id,new Array(this.world.enemies.cap).fill("")),this.fodderAnimStart.set(m.id,new Float64Array(this.world.enemies.cap)),this.fodderAttackPlayed.set(m.id,new Uint8Array(this.world.enemies.cap))}const u=this.textures.exists(en("gem"))?en("gem"):"px-gem";this.gemLayer=this.add.spriteGPULayer(u,r.maxGems).setDepth(2),this.sparkLayer=this.add.spriteGPULayer("px-spark",os).setDepth(6),this.gemShown=new Uint8Array(r.maxGems),this.sparkShown=new Uint8Array(os);for(const m of this.fodderLayers.values())ws(m,this.world.enemies.cap,this.gpuMember);this.enemyGlowLayer=this.add.spriteGPULayer("px-glow",this.world.enemies.cap).setDepth(1.85),this.enemyGlowLayer.setBlendMode(P.BlendModes.ADD),ws(this.enemyGlowLayer,this.world.enemies.cap,this.gpuMember),ws(this.gemLayer,r.maxGems,this.gpuMember),ws(this.sparkLayer,os,this.gpuMember),this.enemyPrevX=new Float32Array(this.world.enemies.cap),this.enemyPrevY=new Float32Array(this.world.enemies.cap),this.enemyAliveLast=new Uint8Array(this.world.enemies.cap),this.playerPrevX=this.world.player.x,this.playerPrevY=this.world.player.y,this.loreSprites=[],this.loreGlows=[];for(let m=0;m<Sa;m+=1){const h=this.add.image(0,0,"px-glow").setVisible(!1).setDepth(2.4).setAlpha(.32).setScale(1.6).setTint(16765786);h.setBlendMode(P.BlendModes.ADD),this.loreGlows.push(h),this.loreSprites.push(this.add.image(0,0,"px-lore").setVisible(!1).setDepth(2.5).setScale(1.5))}this.sparks=[];for(let m=0;m<os;m+=1)this.sparks.push({life:0,max:.2,x:0,y:0,vx:0,vy:0,size:1,tint:16777215});this.playerGlow=this.add.image(0,0,"px-player-halo").setDepth(4).setAlpha(.48).setScale(1.8),this.playerGlow.setBlendMode(P.BlendModes.ADD),this.playerTrail1=this.add.sprite(this.world.player.x,this.world.player.y,Z(d)).setVisible(!1).setDepth(4.8),this.fitBody(this.playerTrail1),this.playerTrail2=this.add.sprite(this.world.player.x,this.world.player.y,Z(d)).setVisible(!1).setDepth(4.7),this.fitBody(this.playerTrail2),this.playerSprite=this.add.sprite(this.world.player.x,this.world.player.y,Z(d)).setDepth(5),Ct(this.playerSprite,d,"idle"),this.fitBody(this.playerSprite),this.playerEyes=this.add.image(0,0,this.eyesKey(l)).setDepth(6),this.decoySprite=this.add.sprite(0,0,Z(d)).setVisible(!1).setDepth(4).setAlpha(.45).setTint(12886106),this.fitBody(this.decoySprite),this.eliteSprites=[];for(let m=0;m<r.maxElites;m+=1){const h=this.add.sprite(0,0,Z("ember-chaser")).setVisible(!1).setDepth(3);this.eliteSprites.push(h)}this.bossSprite=this.add.sprite(0,0,Z("cinder-heart")).setVisible(!1).setDepth(3),this.obstacleSprites=[],this.volatileGlows=[];for(let m=0;m<this.world.obstacles.cap;m+=1)this.obstacleSprites.push(this.add.image(0,0,Xs(l)).setVisible(!1).setDepth(2)),this.volatileGlows.push(this.add.image(0,0,"px-glow").setVisible(!1).setDepth(1).setAlpha(.2).setScale(3.2)),this.volatileGlows[m].setBlendMode(P.BlendModes.ADD);this.telGlow=this.add.image(0,0,"px-glow").setDepth(1).setAlpha(0).setScale(6),this.telGlow.setBlendMode(P.BlendModes.ADD),this.crosshair=this.add.image(this.world.aimX,this.world.aimY,this.crosshairKey()).setDepth(10),this.waypoint=this.add.image(0,0,"px-waypoint").setVisible(!1).setDepth(11),zi(this.waypoint,"nav-arrow","px-waypoint")?this.waypoint.setScale(1):this.waypoint.setScale(1.2),this.shots=[];for(let m=0;m<o;m+=1)this.shots.push(this.add.image(0,0,"px-bolt-player").setVisible(!1).setDepth(5.2));this.zoneFx=[];for(let m=0;m<this.world.zones.cap;m+=1)this.zoneFx.push(this.add.image(0,0,"px-bolt-player").setVisible(!1).setDepth(3));this.fxStills=b0(this),this.ghosts=[],this.ghostLife=new Float32Array(Ee),this.ghostMaxLife=new Float32Array(Ee),this.ghostInitAlpha=new Float32Array(Ee);for(let m=0;m<Ee;m+=1){const h=this.add.sprite(0,0,Z(d)).setVisible(!1).setDepth(4.7).setAlpha(0);this.fitBody(h),this.ghosts.push(h)}if(this.ambientShader=new N0(this),this.bossShaders=new G0(this),this.brimstoneLineShaders=new V0(this),this.circleChargeShader=new W0(this),this.condemnTetherShaders=new K0(this),this.damageFx=new Z0(this),this.eliteAffixShaders=new ep(this),this.envHazardShaders=new sp(this),this.playerHurtShader=new ap(this),this.skillImpactShaders=new cp(this),this.cameras.main.setBounds(0,0,a,i),this.cameras.main.setZoom(E.world.viewZoom),this.cameras.main.centerOn(this.world.player.x,this.world.player.y),!this.input.keyboard)throw new Error("Keyboard plugin missing");this.input.keyboard.addCapture([P.Input.Keyboard.KeyCodes.W,P.Input.Keyboard.KeyCodes.A,P.Input.Keyboard.KeyCodes.S,P.Input.Keyboard.KeyCodes.D,P.Input.Keyboard.KeyCodes.UP,P.Input.Keyboard.KeyCodes.DOWN,P.Input.Keyboard.KeyCodes.LEFT,P.Input.Keyboard.KeyCodes.RIGHT,P.Input.Keyboard.KeyCodes.SPACE,P.Input.Keyboard.KeyCodes.SHIFT,P.Input.Keyboard.KeyCodes.Q]),this.cursors=this.input.keyboard.createCursorKeys(),this.wasd=this.input.keyboard.addKeys("W,A,S,D"),this.shift=this.input.keyboard.addKey(P.Input.Keyboard.KeyCodes.SHIFT),this.space=this.input.keyboard.addKey(P.Input.Keyboard.KeyCodes.SPACE),this.qKey=this.input.keyboard.addKey(P.Input.Keyboard.KeyCodes.Q),this.input.mouse?.disableContextMenu(),mt(),Vt(),Js({visible:!1,title:"",detail:"",pct:0,outside:!1}),this.lastPhase="play",this.lastStageIndex=this.world.stageIndex,this.lastBossSpawned=this.world.bossSpawned,this.bossMusicActive=this.world.bossSpawned&&this.world.counts.boss>0,this.shownOffer=null,Ar({onPick:m=>{const h=this.world.offer?.[m];h&&Fm(h.id),ad(this.world,m)},onRestart:()=>{this.world.phase!=="victory"&&this.world.phase!=="defeat"&&gs(this.world,"abandon"),mt(),this.scene.restart()},onAbandon:()=>{gs(this.world,"abandon"),Vn("abandon",`${K(this.world).name} · ${Q(this.world.runTime)}`,this.runRecap())},onPause:()=>{this.world.phase==="play"&&(it(this.world),Oi()==="hidden"&&Wa())}});const f=this.game.renderer instanceof P.Renderer.WebGL.WebGLRenderer;_f(f?"webgl":"canvas"),lt({kind:"stage",stageId:K(this.world).id}),n&&dt()&&_s()}update(t,n){const a=n/1e3;this.readInput(),Qu(this.world,this.inputFrame,this.time.now/1e3),ph()||du(this.world,this.inputFrame,a),this.syncView(a),this.syncHud(),this.syncOverlay(),this.syncStings(),this.syncHoldPrompt(),nr(this.game.loop.actualFps)}syncHud(){const t=K(this.world),n=Tn(this.world),a=this.world.teleporter,i=this.world.portal,o=this.world.player,r=a.state==="charging"&&Math.hypot(o.x-a.x,o.y-a.y)<=a.radius,l=a.state==="charging"&&!r,c=i.open&&Math.hypot(o.x-i.x,o.y-i.y)>this.world.catalog.loop.portalRadius;let d="";l?d="The seal cools · Return to the Transmutation Circle":c&&(d="Stand in the gate to descend");const u=gp(n,d);Gf({stage:t.name,biome:this.biome(),playerHp:this.world.player.hp,playerMax:this.world.player.maxHp,level:this.world.level,xp:this.world.xp,xpNeed:this.world.xpNeed,runTime:this.world.runTime,coefficient:this.world.coefficient,bosses:this.world.bossesDefeated,kills:this.world.kills.total,damageDealt:Math.round(this.world.damageDealt),iframe:this.world.player.iframeRemain>0,objectiveKicker:u.kicker,objective:u.label,objectiveDetail:u.detail,objectivePct:n.pct,objectiveSub:u.sub,outside:l||c,holding:r,boss:this.world.focus.kind==="boss",skills:hp(this.world),items:this.world.inventory.map(f=>{const m=this.world.catalog.item(f.id);return{id:f.id,name:m.name,stacks:f.stacks,rarity:m.rarity}})})}biome(){return Kf(K(this.world).id)}envTheme(){return jf(K(this.world).id)}vesselId(){return this.world.survivor.id}playerScale(){const t=this.world?.survivor?.stats?.radius||14,n=this.world?.player?.radius??t,a=t>0?n/t:1;return Math.max(vo,Math.min(bo,a))}fitBody(t,n=this.playerScale()){const a=t.frame?.width??Ms,i=t.frame?.height??Ms;if(a===i){t.setDisplaySize(Ms*n,Ms*n);return}t.setDisplaySize(a*n,i*n)}ySortDepth(t,n=0){const a=E.world.height||2560;return 3.2+Math.max(0,Math.min(1,t/a))*1.6+n}eyesKey(t){return Ha(t,this.vesselId())}crosshairKey(){const t=this.vesselId(),n=E.survivors.find(a=>a.id===t);return or(n?.crosshair||t)}readInput(){if(gh()){this.inputFrame.moveX=0,this.inputFrame.moveY=0,this.inputFrame.held.primary=!1,this.inputFrame.held.secondary=!1,this.inputFrame.held.utility=!1,this.inputFrame.held.special=!1,this.inputFrame.pressed.primary=!1,this.inputFrame.pressed.secondary=!1,this.inputFrame.pressed.utility=!1,this.inputFrame.pressed.special=!1,this.utilityWasDown=this.shift.isDown||this.space.isDown,this.secondaryWasDown=this.input.activePointer.rightButtonDown(),this.specialWasDown=this.qKey.isDown;return}const t=this.cursors.left.isDown||this.wasd.A.isDown,n=this.cursors.right.isDown||this.wasd.D.isDown,a=this.cursors.up.isDown||this.wasd.W.isDown,i=this.cursors.down.isDown||this.wasd.S.isDown;this.inputFrame.moveX=(n?1:0)-(t?1:0),this.inputFrame.moveY=(i?1:0)-(a?1:0);const o=this.input.activePointer,r=this.cameras.main.getWorldPoint(o.x,o.y);this.inputFrame.aimX=r.x,this.inputFrame.aimY=r.y;const l=this.shift.isDown||this.space.isDown,c=o.rightButtonDown(),d=this.qKey.isDown;this.inputFrame.held.primary=o.leftButtonDown(),this.inputFrame.held.secondary=c,this.inputFrame.held.utility=l,this.inputFrame.held.special=d,this.inputFrame.pressed.primary=!1,this.inputFrame.pressed.secondary=c&&!this.secondaryWasDown,this.inputFrame.pressed.utility=l&&!this.utilityWasDown,this.inputFrame.pressed.special=d&&!this.specialWasDown,this.utilityWasDown=l,this.secondaryWasDown=c,this.specialWasDown=d}syncView(t){const{player:n,projectiles:a}=this.world,i=this.biome(),o=this.envTheme();this.lastStageGen!==this.world.stageGen&&(this.lastStageGen=this.world.stageGen,this.floor.setTexture(Ys(o)),this.playerEyes.setTexture(this.eyesKey(i)),this.crosshair.setTexture(this.crosshairKey()),this.lastCircleKey=""),this.syncPlayer(t,i),this.crosshair.setPosition(this.world.aimX,this.world.aimY);const r=H();let l=0,c=0;if(this.shakeTrauma>0)if(r.screenshake&&!r.reduceVfx){this.shakeTrauma=Math.max(0,this.shakeTrauma-2.8*t),this.shakeTime+=t*32;const h=this.shakeTrauma*this.shakeTrauma,p=9;l=Math.sin(this.shakeTime*1.7)*p*h,c=Math.cos(this.shakeTime*2.3)*p*h}else this.shakeTrauma=0;const{width:d,height:u}=E.world,f=Math.max(0,Math.min(d,n.x+l)),m=Math.max(0,Math.min(u,n.y+c));this.cameras.main.centerOn(f,m),this.syncObstacles(i,o),this.syncEnemies(i),this.syncGems(),this.syncLores(),this.drawZones(t),this.bossShaders.sync(this.world,t),this.brimstoneLineShaders.sync(this.world.zones,this.world.runTime),this.condemnTetherShaders.sync(this.world.runTime,a,this.world.enemies,n.x,n.y),this.syncBrimstoneSparks(t),this.drawTelegraphs(i),this.syncWaypoint(),E0(this,this.zoneFx,this.world.zones),this.consumeFx(),k0(this.fxStills,t),this.stepSparks(t),this.stepGhosts(t),this.ambientShader.sync(this.cameras.main,this.world.runTime,i),this.envHazardShaders.sync(this.world.obstacles,this.obstacleSprites,n.x,n.y,n.radius,i,o,this.world.runTime,t),this.damageFx.sync(t,this.world.runTime),this.skillImpactShaders.sync(t,this.world.runTime),this.playerHurtShader.sync(this.cameras.main,this.world.runTime,n.hp,n.maxHp,t);for(let h=0;h<this.shots.length;h+=1){const p=this.shots[h];if(a.alive[h]===0){p.setVisible(!1);continue}S0(this,p,a,h,i)}}syncPlayer(t,n){const{player:a}=this.world,i=this.vesselId(),o=this.playerScale(),r=this.inputFrame.moveX!==0||this.inputFrame.moveY!==0,l=this.world.survivor.stats.speed,c=Math.min(1,Math.hypot(this.inputFrame.moveX,this.inputFrame.moveY)),d=r&&a.dashRemain<=0?this.world.stats.speed*Do(this.world)*c:0,u=l>0?d/l:1;r&&a.dashRemain<=0&&(this.walkPhase+=t*8*u);const f=Math.sin(this.walkPhase)*1.5*o;this.lastFacing=Jf(Qf(this.inputFrame.moveX,this.inputFrame.moveY),this.lastFacing);const m=this.lastFacing==="left";Ct(this.playerSprite,i,r&&a.dashRemain<=0?"walk":"idle",u),this.fitBody(this.playerSprite,o),this.playerSprite.setFlipX(m),this.playerEyes.setVisible(!Vr(i));const h=mu(this.world),p=a.x,g=a.y+f,v=this.ySortDepth(a.y,2e-4);this.playerSprite.setPosition(p,g),this.playerSprite.setDepth(v),this.playerSprite.setAlpha(a.iframeRemain>0?.45:1),a.hurtRemain>0?this.playerSprite.setTint(16733542).setTintMode(P.TintModes.MULTIPLY):this.playerSprite.clearTint(),this.playerTrail1.setVisible(!1),this.playerTrail2.setVisible(!1),this.world.decoy.active?(Ct(this.decoySprite,i,"idle"),this.fitBody(this.decoySprite,o),this.decoySprite.setFlipX(m),this.decoySprite.setVisible(!0),this.decoySprite.setPosition(this.world.decoy.x,this.world.decoy.y),this.decoySprite.setDepth(this.ySortDepth(this.world.decoy.y)),this.decoySprite.setAlpha(.3+.2*Math.sin(this.world.runTime*8))):this.decoySprite.setVisible(!1),this.playerGlow.setPosition(p,g),this.playerGlow.setScale(1.8*o),this.playerGlow.setAlpha(n==="cinder"?.48:.32),this.playerGlow.setTint(n==="cinder"?16768912:12120319),this.playerGlow.setDepth(v-.001),this.playerEyes.setScale(o),this.playerEyes.setDepth(v+2e-4),this.playerEyes.setPosition(p+Math.cos(h)*2*o,g-6*o+Math.sin(h)*1*o)}syncObstacles(t,n){const{obstacles:a,player:i}=this.world,o=Math.floor(this.world.runTime/.45)%2===0?0:1,r=Math.floor(this.world.runTime*16)%2===0;for(let l=0;l<a.cap;l+=1){const c=this.obstacleSprites[l],d=this.volatileGlows[l];if(a.alive[l]===0){c.setVisible(!1),d.setVisible(!1);continue}const u=a.items[l];let f=Xs(t),m="pillar";u.type==="hazard"?(f=_t(t,o),m=`hazard-${o}`):u.type==="volatile"&&(f=$a(t),m="volatile");const h=u.type==="hazard"&&u.timer>0,p=h?"rime":n,g=h?"rime":t,v=Ss(p,m,this);if(u.type==="hazard"){const y=v??(o===1?Ss(p,"hazard-0",this):null),b=y?`env-blended-${y}`:"";b&&this.textures.exists(b)?c.setTexture(b):y&&ks(c,y,f)||c.setTexture(_t(g,o))}else v?ks(c,v,f):c.setTexture(f);if(c.setVisible(!0),c.setPosition(Math.round(u.x),Math.round(u.y)),u.type==="pillar"){if(v){const y=Yi(v);if(y){c.setDisplaySize(y.w,y.h);const b=y.h>u.radius*2?(y.h-u.radius)/y.h:.5;c.setOrigin(.5,b)}else c.setScale(1),c.setOrigin(.5,.5)}else{const y=u.radius*2/c.width;c.setScale(y),c.setOrigin(.5,.5)}c.setDepth(this.ySortDepth(u.y))}else if(u.type==="volatile"){if(v){const y=Yi(v);y?c.setDisplaySize(y.w,y.h):c.setScale(1)}else{const y=u.radius*2/c.width;c.setScale(y)}c.setOrigin(.5,.5),c.setDepth(this.ySortDepth(u.y,-1e-4))}else if(u.type==="hazard"){const y=u.radius*2;c.setDisplaySize(y,y),c.setOrigin(.5,.5),c.setDepth(1.05)}else{const y=u.radius*2/c.width;c.setScale(y),c.setOrigin(.5,.5),c.setDepth(this.ySortDepth(u.y))}if(u.type==="hazard"){const y=u.timer>0,b=y?Math.min(1,u.timer/1):1;c.clearTint(),c.setAlpha(b),d.setVisible(!0),d.setPosition(u.x,u.y),d.setTint(y?2683024:t==="cinder"?16729105:2683024),d.setAlpha((.1+.03*Math.sin(this.world.runTime*3+l))*b),d.setScale(u.radius*1.65/32)}else if(u.type==="pillar"){c.setAlpha(1);const y=Math.hypot(i.x-u.x,i.y-u.y)<170;c.setTint(y?16771280:16777215),d.setVisible(!1)}else u.type==="volatile"&&u.state==="primed"?(c.setAlpha(1),c.setTint(r?16777215:16724770),d.setVisible(!0),d.setPosition(u.x,u.y),d.setTint(16724770),d.setAlpha(.2),d.setScale(3.2),d.setDepth(this.ySortDepth(u.y,-2e-4))):(c.setAlpha(1),c.clearTint(),d.setVisible(!1))}}syncEnemies(t){const{enemies:n}=this.world;let a=0,i=!1;const o=[];for(let r=0;r<n.cap;r+=1){const l=n.alive[r]!==0,c=l&&n.role[r]===pe,d=n.defId[r];if(this.hideFodderSlot(r,c?d:null),c&&d){const g=this.fodderLayers.get(d);if(g){const v=d==="enemy-astral-sniper"?11827967:16777215,y=An(this.world,r),b=this.world.catalog.entity(d).stats.speed,x=b>0?y/b:1,k=n.facing[r]<0;this.gpuMember.x=n.x[r],this.gpuMember.y=n.y[r],this.gpuMember.scaleX=k?-1:1,this.gpuMember.scaleY=1,this.gpuMember.alpha=1,this.gpuMember.frame=0;const C=Pt(this.world,r),M=In(this.world,r),w=Es(d,M)??Es(d,"attack"),R=Es(d,"walk"),D=Es(d,"idle"),L=this.fodderAttackPlayed.get(d),U=this.fodderAnimName.get(d),_=this.fodderAnimStart.get(d);let G="",N=0;C&&w?L&&L[r]===1?(_?g.timeElapsed-_[r]:w.duration)<w.duration?(G=w.name,N=w.duration):R&&y>0?(G=R.name,N=R.duration/Math.max(.1,x)):D&&D.frames.length>1&&(G=D.name,N=D.duration):(L&&(L[r]=1),U&&_&&(U[r]=w.name,_[r]=g.timeElapsed),G=w.name,N=w.duration):(L&&(L[r]=0),R&&y>0?(G=R.name,N=R.duration/Math.max(.1,x)):D&&D.frames.length>1&&(G=D.name,N=D.duration)),G?(U&&_?(U[r]!==G&&(U[r]=G,_[r]=g.timeElapsed),this.gpuMember.creationTime=_[r]):this.gpuMember.creationTime=g.timeElapsed,this.gpuMember.animation={base:G,duration:N}):(U&&(U[r]=""),this.gpuMember.animation=void 0,this.gpuMember.creationTime=g.timeElapsed,this.gpuMember.frame=D&&Number(D.frames[0])||0),n.hurtRemain[r]>0?(this.gpuMember.tintMode=P.TintModes.MULTIPLY,this.gpuMember.tintBlend=.7,this.gpuMember.tintBottomLeft=16733542,this.gpuMember.tintTopLeft=16733542,this.gpuMember.tintBottomRight=16733542,this.gpuMember.tintTopRight=16733542):(this.gpuMember.tintMode=P.TintModes.MULTIPLY,this.gpuMember.tintBlend=d==="enemy-astral-sniper"?.55:0,this.gpuMember.tintBottomLeft=v,this.gpuMember.tintTopLeft=v,this.gpuMember.tintBottomRight=v,this.gpuMember.tintTopRight=v),g.editMember(r,this.gpuMember),this.fodderShown[d][r]=1}}if(!l||!d){Rs(this.enemyGlowLayer,this.gpuMember,r),this.enemyPrevX[r]=n.x[r],this.enemyPrevY[r]=n.y[r],this.enemyAliveLast[r]=0;continue}const u=n.role[r]===j,f=n.role[r]===O,m=u?2.4:f?1.45:1,h=t==="cinder"?u?.44:f?.36:.28:u?.36:f?.28:.2,p=t==="cinder"?16742963:6344959;if(Bt(this.gpuMember),this.gpuMember.x=n.x[r],this.gpuMember.y=n.y[r]+(u?10:4),this.gpuMember.scaleX=m,this.gpuMember.scaleY=m*.72,this.gpuMember.alpha=h,this.gpuMember.tintBlend=.7,this.gpuMember.tintBottomLeft=p,this.gpuMember.tintTopLeft=p,this.gpuMember.tintBottomRight=p,this.gpuMember.tintTopRight=p,this.gpuMember.frame=0,this.enemyGlowLayer.editMember(r,this.gpuMember),n.role[r]===j){const g=An(this.world,r),v=this.world.catalog.entity(d).stats.speed,y=v>0?g/v:1,b=Pt(this.world,r),x=In(this.world,r);Ct(this.bossSprite,d,b?x:g>0?"walk":"idle",y);const k=this.ySortDepth(n.y[r]);this.bossSprite.setPosition(n.x[r],n.y[r]),this.bossSprite.setDepth(k),this.bossSprite.setFlipX(n.facing[r]<0),this.bossSprite.setVisible(!0),n.hurtRemain[r]>0?this.bossSprite.setTint(16733542).setTintMode(P.TintModes.MULTIPLY):this.world.boss.enraged?this.bossSprite.setTint(d==="cinder-heart"?16759688:12120319).setTintMode(P.TintModes.MULTIPLY):this.bossSprite.clearTint(),i=!0}else if(n.role[r]===O&&a<this.eliteSprites.length){const g=this.eliteSprites[a],v=An(this.world,r),y=this.world.catalog.entity(d).stats.speed,b=y>0?v/y:1,x=Pt(this.world,r),k=In(this.world,r),C=this.world.catalog.loop.elite.radiusMul;Ct(g,d,x?k:v>0?"walk":"idle",b);const M=this.ySortDepth(n.y[r]);if(g.setScale(C),g.setPosition(n.x[r],n.y[r]),g.setDepth(M),g.setFlipX(n.facing[r]<0),g.setVisible(!0),o.push({active:!0,isShielder:n.shielder[r]!==0,shieldActive:n.shieldHp[r]>0,isNoxious:n.noxious[r]!==0,isCorpse:n.corpseRemain[r]>0}),n.hurtRemain[r]>0)g.setTint(16733542).setTintMode(P.TintModes.MULTIPLY);else if(n.corpseRemain[r]>0){const w=Math.floor(this.world.runTime*16)%2===0;g.setTint(w?8978346:2254404).setTintMode(P.TintModes.MULTIPLY)}else d==="enemy-astral-sniper"?g.setTint(11827967).setTintMode(P.TintModes.MULTIPLY):g.clearTint();a+=1}this.enemyPrevX[r]=n.x[r],this.enemyPrevY[r]=n.y[r],this.enemyAliveLast[r]=l?1:0}for(let r=a;r<this.eliteSprites.length;r+=1)this.eliteSprites[r].setVisible(!1),this.eliteSprites[r].setData("attackDone",!1);this.eliteAffixShaders.sync(this.world.runTime,this.eliteSprites,o),i||(this.bossSprite.setVisible(!1),this.bossSprite.setData("attackDone",!1),this.bossSprite.setData("activeAttackKey",""))}hideFodderSlot(t,n){for(const[a,i]of this.fodderLayers){if(a===n||this.fodderShown[a][t]===0)continue;Rs(i,this.gpuMember,t),this.fodderShown[a][t]=0;const o=this.fodderAnimName.get(a);o&&(o[t]="");const r=this.fodderAttackPlayed.get(a);r&&(r[t]=0)}}syncGems(){const{gems:t}=this.world;for(let n=0;n<t.cap;n+=1)t.alive[n]!==0?(Bt(this.gpuMember),this.gpuMember.x=t.x[n],this.gpuMember.y=t.y[n],this.gpuMember.scaleX=1,this.gpuMember.scaleY=1,this.gpuMember.alpha=1,this.gpuMember.tintBlend=0,this.gpuMember.tintBottomLeft=16777215,this.gpuMember.tintTopLeft=16777215,this.gpuMember.tintBottomRight=16777215,this.gpuMember.tintTopRight=16777215,this.gemLayer.editMember(n,this.gpuMember),this.gemShown[n]=1):this.gemShown[n]!==0&&(Rs(this.gemLayer,this.gpuMember,n),this.gemShown[n]=0)}syncLores(){const{lores:t,newlyCollectedLores:n}=this.world;for(let a=0;a<this.loreSprites.length;a+=1){const i=this.loreSprites[a],o=this.loreGlows[a];if(a>=t.cap||t.alive[a]===0){i.setVisible(!1),o.setVisible(!1);continue}const r=Math.sin(this.world.runTime*5+a)*2.5,l=Math.round(t.x[a]),c=Math.round(t.y[a]+r);i.setPosition(l,c).setVisible(!0),o.setPosition(l,c).setVisible(!0).setAlpha(.28+.12*Math.sin(this.world.runTime*6+a))}if(n.length>0)for(;n.length>0;){const a=n.shift();if(!a)continue;if(Bm(a)&&(T("confirm"),!Vi())){const o=this.world.catalog.entity(a);Un({kicker:"Apocrypha Recovered",title:`${o.name} Treatise`,sub:"Inscribed in The Archives"},1800)}}}syncOverlay(){const{phase:t,offer:n}=this.world;if(Oi()==="pause"){this.lastPhase=t;return}if(t==="levelup"&&n&&this.shownOffer!==n){const a=it(this.world);this.world.unlockedItems=St(a),this.shownOffer=n,xh(n)}else t==="victory"&&this.lastPhase!=="victory"?(gs(this.world,"victory"),Vn("victory",`The last seal holds · ${Q(this.world.runTime)}`,this.runRecap())):t==="defeat"&&this.lastPhase!=="defeat"?(gs(this.world,"defeat"),Vn("defeat",`${K(this.world).name} · ${Q(this.world.runTime)}`,this.runRecap())):t==="play"&&this.lastPhase!=="play"&&(mt(),this.shownOffer=null);this.lastPhase=t}syncStings(){if(this.world.stageIndex!==this.lastStageIndex){this.lastStageIndex=this.world.stageIndex,this.enemyAliveLast.fill(0),this.playerPrevX=this.world.player.x,this.playerPrevY=this.world.player.y,this.lastBossSpawned=!1,this.bossMusicActive=!1;const t=it(this.world);this.world.unlockedItems=St(t);const n=K(this.world);lt({kind:"stage",stageId:n.id}),Un({kicker:"The Rift yields",title:n.name,sub:"A colder chamber. The working continues."},1400)}if(this.world.bossSpawned&&!this.lastBossSpawned){this.lastBossSpawned=!0,this.bossMusicActive=!0;const t=K(this.world);lt({kind:"boss",bossId:t.boss,stageId:t.id});const n=this.world.focus.name||Tn(this.world).name||"the seal";Un({kicker:"The seal breaks",title:n,sub:K(this.world).name},2e3)}if(this.bossMusicActive&&this.world.counts.boss===0&&this.world.portal.open){this.bossMusicActive=!1;const t=it(this.world);this.world.unlockedItems=St(t);const n=K(this.world);lt({kind:"stage",stageId:n.id})}Vi()&&Math.abs(this.inputFrame.moveX)+Math.abs(this.inputFrame.moveY)>0&&Vt()}syncHoldPrompt(){Js({visible:!1,title:"",detail:"",pct:0,outside:!1})}runRecap(){const t=$(),n=E.items.filter(l=>!this.initialUnlockedItems.has(l.id)&&Sr(l,t)),a=E.survivors.filter(l=>!this.initialUnlockedSurvivors.has(l.id)&&ae(l,t)),i=[...n.map(l=>({kind:"item",id:l.id,name:l.name,rarity:l.rarity,desc:l.unlock?.label?`Condition Met: ${ua(l.unlock,t)}`:"New Relic Unlocked"})),...a.map(l=>({kind:"survivor",id:l.id,name:l.name,desc:l.unlock?.label?`Condition Met: ${ua(l.unlock,t)}`:"New Vessel Unsealed"}))],o=St(t),r=E.survivors.filter(l=>ae(l,t));return{survivor:this.world.survivor.name,survivorId:this.world.survivor.id,stage:K(this.world).name,time:this.world.runTime,level:this.world.level,coefficient:this.world.coefficient,bosses:this.world.bossesDefeated,kills:this.world.kills.total,damageDealt:Math.round(this.world.damageDealt),damageTaken:Math.round(this.world.damageTaken),healingDone:Math.round(this.world.healingDone),gemsCollected:this.world.gemsCollected,items:this.world.inventory.map(l=>{const c=this.world.catalog.item(l.id);return{id:l.id,name:c.name,stacks:l.stacks,rarity:c.rarity,lore:c.lore}}),newUnlocks:i,unlockProgress:{itemsUnlocked:o.size,totalItems:E.items.length,survivorsUnlocked:r.length,totalSurvivors:E.survivors.length}}}drawZones(t){const n=this.zoneGfx,a=this.world.teleporter,i=this.biome(),o=this.envTheme(),r=a.state!=="hidden"&&Math.hypot(this.world.player.x-a.x,this.world.player.y-a.y)<=a.radius,l=a.hold>0?Math.min(1,a.charge/a.hold):0;if(this.circleChargeShader.sync(this.world.runTime,a.x,a.y,a.radius,l,a.state==="charging",r,this.world.player.x,this.world.player.y,i,t),this.circleGlowFilter)if(a.state==="charging"){this.circleGlowFilter.setActive(!0),this.circleGlowFilter.color=i==="cinder"?16755251:5636095;const p=.5+.5*Math.sin(this.world.runTime*4);this.circleGlowFilter.outerStrength=r?1.2+2*l+p*1.2:.6+p*.4,this.circleGlowFilter.innerStrength=r?.2+.6*l:0}else this.circleGlowFilter.setActive(!1);const c=Ss(o,"circle",this),d=!!c&&a.state!=="hidden";d&&c?(ks(this.circleSprite,c),this.circleSprite.setVisible(!0).setPosition(a.x,a.y).setDisplaySize(a.radius*2,a.radius*2)):this.circleSprite.setVisible(!1);const u=Ss(o,"portal",this),f=!!u&&this.world.portal.open;if(f&&u){ks(this.portalSprite,u);const p=this.world.catalog.loop.portalRadius,g=this.world.catalog.loop.portalHold,v=g>0?Math.min(1,this.world.portal.hold/g):0,y=.75+.15*Math.sin(this.world.runTime*7)+.1*v;this.portalSprite.setVisible(!0).setPosition(this.world.portal.x,this.world.portal.y).setDisplaySize(p*2,p*2).setAlpha(y)}else this.portalSprite.setVisible(!1);const m=this.world.portal.open?Math.floor(this.world.runTime*8):0,h=`${this.world.stageGen}|${a.state}|${r?1:0}|${Math.round(l*50)}|${this.world.portal.open?1:0}|${Math.round(this.world.portal.hold*10)}|${m}`;if(h===this.lastCircleKey){this.telGlow.setAlpha(a.state==="charging"?r?.22:.08:0);return}if(this.lastCircleKey=h,n.clear(),a.state!=="hidden"?(mp(n,a.x,a.y,a.radius,l,r,i,a.state==="charging",d),this.telGlow.setPosition(a.x,a.y),this.telGlow.setAlpha(a.state==="charging"?r?.22:.08:0)):this.telGlow.setAlpha(0),this.world.portal.open&&!f){const p=i==="cinder"?16757575:14677759,g=this.world.catalog.loop.portalRadius,v=this.world.catalog.loop.portalHold,y=v>0?Math.min(1,this.world.portal.hold/v):0,b=.16+.1*Math.sin(this.world.runTime*7)+.18*y;n.lineStyle(3,p,1),n.strokeCircle(this.world.portal.x,this.world.portal.y,g),n.fillStyle(p,b),n.fillCircle(this.world.portal.x,this.world.portal.y,g)}}drawTelegraphs(t){const n=this.telegraphGfx;n.clear();const{enemies:a}=this.world,i=Math.floor(this.world.runTime*12)%2===0,o=i?16777215:t==="cinder"?16742970:5636095;for(let c=0;c<a.cap;c+=1){if(a.alive[c]===0)continue;if(a.corpseRemain[c]>0){const h=this.world.catalog.loop.noxious.popRadius;n.lineStyle(2,i?13434845:3394662,.95),n.strokeCircle(Math.round(a.x[c]),Math.round(a.y[c]),h)}if(a.rootRemain[c]>0&&H().reduceVfx&&(n.lineStyle(2,12886106,.85),n.lineBetween(Math.round(this.world.player.x),Math.round(this.world.player.y),Math.round(a.x[c]),Math.round(a.y[c]))),a.windup[c]<=0)continue;const d=a.defId[c],u=d?this.world.catalog.entity(d).ai:null;if(u?.type==="sniper"){const h=i?16720452:4491519,p=a.aimX[c]-a.x[c],g=a.aimY[c]-a.y[c],v=Math.hypot(p,g)||1,y=980;Ts(n,a.x[c],a.y[c],a.x[c]+p/v*y,a.y[c]+g/v*y,h),n.lineStyle(2,h,.55),n.lineBetween(Math.round(a.x[c]),Math.round(a.y[c]),Math.round(a.x[c]+p/v*y),Math.round(a.y[c]+g/v*y));continue}if(u?.type==="boss"){const{boss:h}=this.world,p=h.activeAttack>=0?u.attacks[h.activeAttack]:null;if(p&&h.phase==="windup"){const g=h.duration>0?Math.min(1,h.elapsed/h.duration):1;if(p.type==="fan"){const v=Math.atan2(h.aimY-a.y[c],h.aimX-a.x[c]),y=p.spread*Math.PI/180,b=Math.min(340,p.projectile.speed*p.projectile.lifetime*.65),x=Math.max(1,p.count);for(let k=0;k<x;k+=1){const C=x===1?0:k/(x-1)-.5,M=v+C*y;Ts(n,a.x[c],a.y[c],a.x[c]+Math.cos(M)*b,a.y[c]+Math.sin(M)*b,o)}n.lineStyle(2,o,.9),n.strokeCircle(Math.round(a.x[c]),Math.round(a.y[c]),Math.round(16+g*22))}else p.type==="bolt"?(Ts(n,a.x[c],a.y[c],h.aimX,h.aimY,o),n.lineStyle(2,o,.9),n.strokeCircle(Math.round(a.x[c]),Math.round(a.y[c]),Math.round(14+g*20))):p.type==="summon"&&(n.lineStyle(2,i?16777215:o,.9),n.strokeCircle(Math.round(a.x[c]),Math.round(a.y[c]),Math.round(a.radius[c]+10+g*18)))}continue}const f=u&&u.type==="ranged"?u.windup:.4,m=f>0?1-a.windup[c]/f:1;Ts(n,a.x[c],a.y[c],a.aimX[c],a.aimY[c],o),n.lineStyle(1,o,.9),n.strokeCircle(a.x[c],a.y[c],Math.round(10+m*16))}this.world.player.rootRemain>0&&(n.lineStyle(2,i?16777215:6744319,.95),n.strokeCircle(Math.round(this.world.player.x),Math.round(this.world.player.y),this.world.player.radius+8));const{obstacles:r}=this.world;for(let c=0;c<r.cap;c+=1){if(r.alive[c]===0)continue;const d=r.items[c];if(d.type!=="volatile"||d.state!=="primed")continue;const u=this.world.catalog.obstacles.volatile.explosionRadius;n.lineStyle(1,i?16777215:16724770,.95),n.strokeCircle(Math.round(d.x),Math.round(d.y),u)}const{zones:l}=this.world;for(let c=0;c<l.cap;c+=1)if(l.alive[c]!==0){if(l.kind[c]===fn){const d=Math.max(.25,1-l.remain[c]/.7);n.lineStyle(2,i?16774344:16755251,.95),n.strokeCircle(Math.round(l.x[c]),Math.round(l.y[c]),Math.round(l.radius[c]*d))}else if(l.kind[c]===gt&&H().reduceVfx){const d=l.length[c]*.5,u=l.x[c]-l.dirX[c]*d,f=l.y[c]-l.dirY[c]*d,m=l.x[c]+l.dirX[c]*d,h=l.y[c]+l.dirY[c]*d;n.lineStyle(Math.max(2,l.width[c]*.35),i?16764006:16733474,.8),n.lineBetween(Math.round(u),Math.round(f),Math.round(m),Math.round(h))}}}syncWaypoint(){const t=Tn(this.world);if(!t.hasTarget){this.waypoint.setVisible(!1);return}const a=this.cameras.main.worldView;if(t.targetX>a.x+Cs&&t.targetX<a.x+a.width-Cs&&t.targetY>a.y+Cs&&t.targetY<a.y+a.height-Cs){this.waypoint.setVisible(!1);return}const o=t.targetX-this.world.player.x,r=t.targetY-this.world.player.y,l=Math.hypot(o,r);if(l<1){this.waypoint.setVisible(!1);return}this.waypoint.texture.key!=="ui-atlas"&&this.waypoint.texture.key!=="ui-nav-arrow"&&zi(this.waypoint,"nav-arrow","px-waypoint")&&this.waypoint.setScale(1),this.waypoint.setVisible(!0),this.waypoint.setPosition(this.world.player.x+o/l*Zi,this.world.player.y+r/l*Zi);const d=this.waypoint.frame?.name==="nav-arrow"||this.waypoint.texture?.key==="ui-nav-arrow"?-Math.PI/2:0;this.waypoint.setRotation(Math.atan2(r,o)+d)}consumeFx(){const{fx:t,player:n}=this.world,a=this.world.survivor.skills.utility??"",i=Math.atan2(n.dashVy,n.dashVx);for(let o=0;o<t.count;o+=1){const r=t.kind[o],l=t.x[o],c=t.y[o],d=t.radius[o],u=t.tint[o]||16777215,f=u===16729122,m=v0(r,u,a),h=r===At?i:0,p=m?x0(this,this.fxStills,m,l,c,h):!1;r===_e?(this.damageFx.spawn(l,c,f?1:0),f&&this.addTrauma(.18)):r===ne?(this.damageFx.spawn(l,c,2,88),this.playerHurtShader.trigger(1),this.addTrauma(.55)):r===It?(this.skillImpactShaders.spawnCenser(l,c,d,f),this.addTrauma(f?.35:.22)):r===Dt?(this.skillImpactShaders.spawnCrucible(l,c,d,f),this.addTrauma(f?.5:.38)):r===ba?(this.skillImpactShaders.spawnTetherLatch(l,c,d,f),this.addTrauma(f?.28:.18)):r===Oe?this.addTrauma(.35):r===we&&u===16746564&&this.addTrauma(.48),p||(r===_e?ge(this.sparks,l,c,u,4,90,.18):r===ne?ge(this.sparks,l,c,u,4,90,.18):r===we?ge(this.sparks,l,c,u,10,140,.28):r===Ge?ge(this.sparks,l,c,u,3,70,.14):r===At?ge(this.sparks,l,c,u,6,110,.2):r===Oe?ge(this.sparks,l,c,u,14,160,.32):r===Gs?ge(this.sparks,l,c,u,3,70,.15):r===It?ge(this.sparks,l,c,u,8,120,.25):r===Dt&&ge(this.sparks,l,c,u,14,160,.32)),r===_e||r===It?T("hit"):r===ne?T("hurt"):r===we?T(u===16746564?"break":"death"):r===Ge?T("muzzle"):r===At?T("dash"):r===Oe||r===Dt?T("strike"):r===Gs&&T("gem")}t.count=0}addTrauma(t){const n=H();!n.screenshake||n.reduceVfx||(this.shakeTrauma=Math.min(1,this.shakeTrauma+t))}stepSparks(t){for(let n=0;n<this.sparks.length;n+=1){const a=this.sparks[n];if(a.life<=0){this.sparkShown[n]!==0&&(Rs(this.sparkLayer,this.gpuMember,n),this.sparkShown[n]=0);continue}a.life-=t,a.x+=a.vx*t,a.y+=a.vy*t;const i=a.max>0?Math.max(0,a.life/a.max):0;Bt(this.gpuMember),this.gpuMember.x=a.x,this.gpuMember.y=a.y,this.gpuMember.scaleX=a.size*(.4+.8*i),this.gpuMember.scaleY=a.size*(.4+.8*i),this.gpuMember.alpha=i,this.gpuMember.tintBlend=.85,this.gpuMember.tintBottomLeft=a.tint,this.gpuMember.tintTopLeft=a.tint,this.gpuMember.tintBottomRight=a.tint,this.gpuMember.tintTopRight=a.tint,this.sparkLayer.editMember(n,this.gpuMember),this.sparkShown[n]=1}}stepGhosts(t){const{player:n}=this.world,a=this.inputFrame.moveX!==0||this.inputFrame.moveY!==0,i=n.dashRemain>0,o=Math.hypot(n.x-this.playerPrevX,n.y-this.playerPrevY),r=t>0?o/t:0,l=H().reduceVfx;if(this.ghostCd=Math.max(0,this.ghostCd-t),!l&&(i&&this.ghostCd<=0||a&&(r>18||i)&&this.ghostCd<=0)){this.ghostCd=i?.04:.055;const d=fp(this.ghostLife);if(d>=0){const u=i?.24:.16,f=i?.55:.38;this.ghostLife[d]=u,this.ghostMaxLife[d]=u,this.ghostInitAlpha[d]=f;const m=this.ghosts[d];m.setTexture(this.playerSprite.texture.key,this.playerSprite.frame.name),this.fitBody(m,this.playerScale()),m.setFlipX(this.playerSprite.flipX),m.setPosition(this.playerSprite.x,this.playerSprite.y),m.setDepth(this.playerSprite.depth-2e-4),m.setVisible(!0),m.setAlpha(f);const h=this.biome(),p=this.world.survivor.id==="penitent"?16763e3:h==="cinder"?16752736:7916799;m.setTint(p)}}for(let d=0;d<Ee;d+=1){if(this.ghostLife[d]<=0){this.ghosts[d].setVisible(!1);continue}this.ghostLife[d]-=t;const u=this.ghostMaxLife[d]>0?Math.max(0,this.ghostLife[d]/this.ghostMaxLife[d]):0;this.ghosts[d].setAlpha(u*this.ghostInitAlpha[d]),this.ghostLife[d]<=0&&this.ghosts[d].setVisible(!1)}this.playerPrevX=n.x,this.playerPrevY=n.y}syncBrimstoneSparks(t){if(H().reduceVfx)return;const{zones:n}=this.world;for(let a=0;a<n.cap;a+=1)if(!(n.alive[a]===0||n.kind[a]!==gt)&&Math.random()<t*26){const i=n.length[a]*.46,o=(Math.random()*2-1)*i,r=(Math.random()*2-1)*(n.width[a]*.3),l=-n.dirY[a],c=n.dirX[a],d=n.x[a]+n.dirX[a]*o+l*r,u=n.y[a]+n.dirY[a]*o+c*r,f=Math.random()<.65?16368171:16225815;up(this.sparks,d,u,f,(Math.random()-.5)*22,-30-Math.random()*45,.22+Math.random()*.18)}}}function ws(e,s,t){Bt(t),t.x=0,t.y=0,t.scaleX=0,t.scaleY=0,t.alpha=0;for(let n=0;n<s;n+=1)e.addMember(t)}function Bt(e){e.animation=void 0,e.frame=void 0,e.creationTime=void 0}function Rs(e,s,t){Bt(s),s.x=0,s.y=0,s.scaleX=0,s.scaleY=0,s.alpha=0,e.editMember(t,s)}function ge(e,s,t,n,a,i,o){if(H().reduceVfx)return;let r=0;for(let l=0;l<e.length&&r<a;l+=1){if(e[l].life>0)continue;const c=Math.random()*Math.PI*2,d=i*(.35+Math.random()*.65);e[l].life=o,e[l].max=o,e[l].x=s,e[l].y=t,e[l].vx=Math.cos(c)*d,e[l].vy=Math.sin(c)*d,e[l].size=.7+Math.random()*.6,e[l].tint=n,r+=1}}function up(e,s,t,n,a,i,o){for(let r=0;r<e.length;r+=1)if(!(e[r].life>0)){e[r].life=o,e[r].max=o,e[r].x=s,e[r].y=t,e[r].vx=a,e[r].vy=i,e[r].size=.6+Math.random()*.5,e[r].tint=n;return}}function fp(e){for(let s=0;s<e.length;s+=1)if(e[s]<=0)return s;return 0}function mp(e,s,t,n,a,i,o,r,l=!1){const c=Math.round(s),d=Math.round(t),u=Math.round(n),f=o==="cinder"?16755251:5636095,h=r&&i?f:o==="cinder"?5910576:2768984;if(!l){e.lineStyle(2,h,r?.95:.35),e.strokeCircle(c,d,u),e.lineStyle(1,h,.7),e.strokeCircle(c,d,Math.round(u*.62));const p=Math.round(u*.72);for(let g=0;g<6;g+=1){const v=g*Math.PI/3-Math.PI/2,y=(g+2)*Math.PI/3-Math.PI/2;e.lineBetween(Math.round(c+Math.cos(v)*p),Math.round(d+Math.sin(v)*p),Math.round(c+Math.cos(y)*p),Math.round(d+Math.sin(y)*p))}for(let g=0;g<6;g+=1){const v=g*Math.PI/3-Math.PI/2,y=Math.round(c+Math.cos(v)*u),b=Math.round(d+Math.sin(v)*u);e.fillStyle(h,.9),e.fillRect(y-2,b-2,4,4)}}if(r&&a>0){e.lineStyle(3,f,i?1:.45);const p=Math.max(1,Math.round(48*a));let g=c,v=d-u;for(let y=1;y<=p;y+=1){const b=-Math.PI/2+Math.PI*2*a*y/p,x=Math.round(c+Math.cos(b)*u),k=Math.round(d+Math.sin(b)*u);e.lineBetween(g,v,x,k),g=x,v=k}}}function Ts(e,s,t,n,a,i){const o=n-s,r=a-t,l=Math.hypot(o,r);if(l<1)return;const c=o/l,d=r/l;e.lineStyle(1,i,.95);let u=0;for(;u<l;){const f=u,m=Math.min(l,u+5);e.lineBetween(Math.round(s+c*f),Math.round(t+d*f),Math.round(s+c*m),Math.round(t+d*m)),u+=9}}function hp(e){const s=["primary","secondary","utility","special"],t=["I","II","III","IV"];return s.map((n,a)=>{const i=e.survivor.skills[n];if(!i)return{slot:n,id:"",name:"",glyph:t[a],cd:0,max:0,empty:!0,iframe:!1};const o=e.catalog.skill(i);return{slot:n,id:i,name:o.name,glyph:t[a],cd:e.player.skillCd[n],max:o.cooldown*e.stats.cooldownMul,empty:!1,iframe:n==="utility"&&e.player.iframeRemain>0}})}function pp(){const e=H().survivorId,s=E.survivors.find(t=>t.id===e);return s&&ae(s)?s.id:E.world.defaultSurvivor}function gp(e,s=""){return e.kind==="wait"?{kicker:"",label:"The Seal Manifests",detail:`${Math.round(e.pct*100)}%`}:e.kind==="hold"?{kicker:"",label:"Channel the Transmutation Circle",detail:`${Math.round(e.pct*100)}%`,sub:s}:e.kind==="boss"?{kicker:"Seal Guardian",label:`Slay the ${e.name||"Boss"}`,detail:`${Math.round(e.pct*100)}%`}:{kicker:"",label:"Descend the Rift",detail:`${Math.round(e.pct*100)}%`,sub:s}}class yp extends P.Scene{constructor(){super({key:"smoke"});S(this,"judged",!1)}create(){this.createDotTexture(),this.populateGpuDots();const t=this.game.renderer instanceof P.Renderer.WebGL.WebGLRenderer;$f(t?"webgl":"canvas"),this.time.delayedCall(Al,()=>{this.judged=!0,zs(Of(this.game.loop.actualFps))})}update(){nr(this.game.loop.actualFps),this.judged||zs("warmup")}createDotTexture(){const n=this.textures.createCanvas("dot",16,16);if(!n)throw new Error("Failed to create dot canvas texture");const a=n.getContext();a.clearRect(0,0,16,16);const i=a.createRadialGradient(8,8,1,8,8,7);i.addColorStop(0,"#e8fbff"),i.addColorStop(.55,"#5ad4ff"),i.addColorStop(1,"rgba(90, 212, 255, 0)"),a.fillStyle=i,a.beginPath(),a.arc(8,8,7,0,Math.PI*2),a.fill(),n.refresh()}populateGpuDots(){const t=this.add.spriteGPULayer("dot",ta);t.setAnimationEnabled("Sine",!0);const n={x:0,y:0,scaleX:1,scaleY:1,alpha:1,tintBlend:0,tintBottomLeft:16777215,tintTopLeft:16777215,tintBottomRight:16777215,tintTopRight:16777215};for(let a=0;a<ta;a+=1){const i=5952767-a%40*262656;n.x=Qi(Math.random()*po,10+Math.random()*28),n.y=Qi(Math.random()*go,8+Math.random()*22),n.scaleX=.7+Math.random()*.8,n.scaleY=n.scaleX,n.alpha=.55+Math.random()*.45,n.tintBlend=.15,n.tintBottomLeft=i,n.tintTopLeft=i,n.tintBottomRight=i,n.tintTopRight=i,t.addMember(n)}}}function Qi(e,s){return{base:e,amplitude:s,duration:1400+Math.random()*2200,delay:Math.random()*1200,ease:"Sine",yoyo:!0,loop:!0}}function vp(e,s){return new P.Game({type:P.WEBGL,parent:e,width:po,height:go,backgroundColor:"#0c0a0d",banner:!1,audio:{noAudio:!0},pixelArt:!0,roundPixels:!1,scale:{mode:P.Scale.FIT,autoCenter:P.Scale.CENTER_BOTH},render:{antialias:!1,failIfMajorPerformanceCaveat:!0},scene:s?[yp]:[dp]})}const bp=630,Wt="/sprites/env/atlas.png",nn=572,an=1603,ha="/sprites/entities/penitent.png",Wr="/sprites/entities/cinder-heart.png",zr="/sprites/entities/ember-mite.png",Ls="/sprites/fx/bolt.png",Xr="/sprites/fx/dash.png",xp=[Wt,ha,Wr,zr,Ls,Xr],kp={t0:{x:5,y:5},t1:{x:75,y:5},t2:{x:145,y:5},r0:{x:5,y:75},r1:{x:75,y:75},r2:{x:145,y:75},r3:{x:215,y:75}},Ji=[["t0","t1","t2","t0","r1","t2"],["t1","r0","t0","t2","t1","t0"],["t2","t0","r2","t1","t0","t2"],["t0","t2","t1","r3","t2","t0"],["t1","t0","t2","t0","r0","t1"]];function Sp(){document.getElementById("cover-compose")||(document.body.appendChild(Ep()),Rp())}function Ep(){const e=ve("div","cover-compose"),s=ve("div","cover-stage");s.id="cover-stage",s.setAttribute("aria-hidden","true"),Cp(s),s.appendChild(Ns({src:Wt,sheetW:nn,sheetH:an,x:5,y:370,w:128,h:128,scale:2,left:470,top:340,z:1})),s.appendChild(Ns({src:Wt,sheetW:nn,sheetH:an,x:5,y:720,w:320,h:315,scale:2,left:-5,top:36,z:2})),s.appendChild(ve("div","cover-glow"));for(const t of Mp())s.appendChild(Ns(t));return s.appendChild(ve("div","cover-vignette")),s.appendChild(wp()),e.appendChild(s),e}function Cp(e){for(let n=0;n<Ji.length;n+=1){const a=Ji[n];if(a)for(let i=0;i<a.length;i+=1){const o=a[i];if(!o)continue;const r=kp[o];r&&e.appendChild(Ns({src:Wt,sheetW:nn,sheetH:an,x:r.x,y:r.y,w:64,h:64,scale:2,left:-32+i*128,top:-24+n*128,z:0}))}}}function Mp(){return[As(4,188,318,5),As(1,348,392,5),As(2,92,286,5),As(0,412,268,5),{src:Wr,sheetW:516,sheetH:86,x:430,y:0,w:86,h:86,scale:5,left:272,top:98,z:6},{src:ha,sheetW:240,sheetH:48,x:192,y:0,w:48,h:48,scale:8,left:-52,top:168,z:7,opacity:.22,className:"cover-afterimage"},{src:ha,sheetW:240,sheetH:48,x:192,y:0,w:48,h:48,scale:8,left:10,top:136,z:8},{src:Xr,sheetW:32,sheetH:29,x:0,y:0,w:32,h:29,scale:4,left:78,top:378,z:9,rotate:28,opacity:.9},{src:Ls,sheetW:32,sheetH:29,x:0,y:0,w:32,h:29,scale:4,left:196,top:214,z:9,rotate:-32},{src:Ls,sheetW:32,sheetH:29,x:0,y:0,w:32,h:29,scale:4,left:238,top:168,z:9,rotate:-40},{src:Ls,sheetW:32,sheetH:29,x:0,y:0,w:32,h:29,scale:4,left:274,top:206,z:9,rotate:-22},wt(96,92,4),wt(520,140,4),wt(430,60,5),wt(300,430,4),wt(40,360,3)]}function As(e,s,t,n){return{src:zr,sheetW:144,sheetH:24,x:e*24,y:0,w:24,h:24,scale:3,left:s,top:t,z:n}}function wt(e,s,t){return{src:Wt,sheetW:nn,sheetH:an,x:15,y:1600,w:8,h:8,scale:t,left:e,top:s,z:10,opacity:.85}}function wp(){const e=ve("div","cover-title");e.style.width=ye(bp);const s=ve("div","cover-brand");return s.appendChild(ve("span","","HERMETIC")),s.appendChild(ve("span","","RIFTS")),e.appendChild(s),e}function Ns(e){const s=ve("div",`cover-spr${e.className?` ${e.className}`:""}`),t=e.scale;s.style.width=ye(e.w*t),s.style.height=ye(e.h*t),s.style.left=ye(e.left),s.style.top=ye(e.top),s.style.zIndex=String(e.z),s.style.backgroundImage=`url("${e.src}")`,s.style.backgroundSize=`${ye(e.sheetW*t)} ${ye(e.sheetH*t)}`,s.style.backgroundPosition=`-${ye(e.x*t)} -${ye(e.y*t)}`;const n=[];return e.rotate&&n.push(`rotate(${e.rotate}deg)`),e.flip&&n.push("scaleX(-1)"),n.length>0&&(s.style.transform=n.join(" ")),e.opacity!=null&&(s.style.opacity=String(e.opacity)),s}function ve(e,s,t){const n=document.createElement(e);return s&&(n.className=s),t&&(n.textContent=t),n}function ye(e){return`${e}px`}async function Rp(){try{await document.fonts.load("700 48px BillJilly"),await document.fonts.ready,await Promise.all(xp.map(Tp))}catch{}requestAnimationFrame(()=>{requestAnimationFrame(()=>_s())})}function Tp(e){const s=new Image;return s.src=e,s.decode()}const Ap=["ANGLE_instanced_arrays","OES_vertex_array_object"];function eo(e,s){if(!e)return s?"software":"missing";for(const t of Ap)if(!e.getExtension(t))return"incomplete";return"ok"}function to(e){const s=document.createElement("canvas");let t=null;try{const n={alpha:!1,antialias:!1,depth:!1,stencil:!1,failIfMajorPerformanceCaveat:e};t=s.getContext("webgl",n)??s.getContext("experimental-webgl",n)}catch{t=null}return{canvas:s,gl:t}}function Qn(e,s){s?.getExtension("WEBGL_lose_context")?.loseContext(),e.width=0,e.height=0}function Ip(){if(typeof document>"u")return"missing";const e=to(!0);if(e.gl){const n=eo(e.gl,!1);return Qn(e.canvas,e.gl),n}Qn(e.canvas,null);const s=to(!1),t=eo(null,!!s.gl);return Qn(s.canvas,s.gl),t}let Ve=null,Yr=!1;document.addEventListener("DOMContentLoaded",()=>{if(va(),Cl(),Ar({onStart:so,onResume:mt,onQuit:Pp}),xe("nowebgl")){yt("missing");return}const e=Ip();if(e!=="ok"){yt(e);return}if(Yr=!0,xe("smoke")){Kr(!0);return}wl(),gn();const s=vt();if(mo()){so();return}if(s==="cover"){Sp();return}if(s==="hall"||s==="banner"){yn(),s==="banner"&&Ju(),_s();return}if(s==="archives"){Ua("menu","entities"),_s();return}Jt()});function so(){Ve||Kr(!1)}function Kr(e){if(!Yr){yt("missing");return}mt(),Vt(),Js({visible:!1,title:"",detail:"",pct:0,outside:!1});try{Ve=vp("game-container",e)}catch{yt("missing");return}Dp(Ve)}function Dp(e){const s=e.renderer;if(!(s instanceof P.Renderer.WebGL.WebGLRenderer)){pa(),yt("missing");return}s.once(P.Renderer.Events.LOSE_WEBGL,()=>{Ve===e&&(pa(),yt("lost"))})}function pa(){if(!Ve)return;const e=Ve;Ve=null;try{e.destroy(!0)}catch{}}function Pp(){pa(),gn(),mt(),Vt(),Js({visible:!1,title:"",detail:"",pct:0,outside:!1}),Jt()}
